----------------------------
-- LIST BATCH HISTORY TIMES
-- Use @batch to get currently running batch_id's
-- 12/03/01 SJ
----------------------------


col Batch_Name format a40

select * from 
  ( select /*+ full(a) full(b) use_hash(b) */ a.id, a.batch_id, a.batch_num, a.status,
to_char(u2sql(a.time_created),'MM/DD/YY HH24:MI') "Start(24H:MI)", 
b.time_created-a.time_created "Time_taken(Secs)", a.command_line Batch_Name from wbatch_log a , wbatch_log b
where a.batch_id=&batch_id
and a.status='S'
and a.id=b.parent_id(+) 
order by a.time_created desc)    where rownum < 8 ;
