select
       substr(DF.Name,1,19) file_system,
       sum(FS.Phyblkrd) Blocks_Read,
       sum(FS.Phyblkwrt) Blocks_Written,
       sum(FS.Phyblkrd+FS.Phyblkwrt) Total_IOs,
       sum( ((FS.Phyblkrd+FS.Phyblkwrt)/ab.tot)*100 )  Percent_IO
  from V$FILESTAT FS, V$DATAFILE DF, dba_data_files DB,
       ( Select sum(f.phyblkrd + f.phyblkwrt) tot
         from v$filestat f, v$datafile d
         where f.file#=d.file# ) ab
 where DF.File#=FS.File#
       and DF.file# = DB.file_id
 group by substr(DF.Name,1,19)
/
