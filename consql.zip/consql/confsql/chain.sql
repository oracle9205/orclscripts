col table_name format a24
col tablespace_name format a24
col owner format a18

select owner, table_name, tablespace_name, num_rows, chain_cnt, round((chain_cnt/num_rows)*100,2) pct_chained , pct_free, pct_used from dba_tables where num_rows != 0 and chain_cnt != 0 order by pct_chained desc;
