select inst_id,service_name,count(*) from gv$session where SERVICE_NAME not like 'SYS%' group by inst_id,service_name
/
