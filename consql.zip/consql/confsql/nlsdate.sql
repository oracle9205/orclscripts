alter session set nls_date_format='YY/MM/DD HH24:MI'
/
