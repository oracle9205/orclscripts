#!/bin/sh
#create the spool file
TMPFILE=/tmp/mutex.sql
> /tmp/mutex.lst
> $TMPFILE
sqlplus -s '/ as sysdba' <<EOF
set head off
set pagesize 0
set feedback off
spool /tmp/mutex.lst
select spid
from v\$process p,v\$session s
where s.paddr=p.addr
and s.sid in (
select blocking_session from v\$session where event in (
'cursor: pin S wait on X',
'cursor: pin S',
'cursor: pin X',
'cursor: mutex S' ,
'cursor: mutex X',
'library cache: mutex X'));
spool off;
EOF
echo "sqlplus '/ as sysdba' <<EOF"    >> $TMPFILE
for i in `cat /tmp/mutex.lst`
do
echo "oradebug setospid $i;"          >> $TMPFILE
echo "oradebug unlimit;"          >> $TMPFILE
echo "oradebug dump errorstack 10;"   >> $TMPFILE
echo "oradebug tracefile_name;"       >> $TMPFILE
done
echo "EOF"                            >> $TMPFILE
chmod 755 $TMPFILE
echo "Collecting errorstack for FIRST time and running the script $TMPFILE"
$TMPFILE
#echo "Collecting errorstack for SECOND time and running the script $TMPFILE"
#$TMPFILE
#echo "Collecting errorstack for THIRD time and running the script $TMPFILE"
#$TMPFILE
