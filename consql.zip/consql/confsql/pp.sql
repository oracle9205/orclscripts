REM pool_str.sql
REM  Shared Pool Structures
REM
set pagesize 60 heading off termout off echo off verify off
ttitle off
REM
REM  The results from each query are assigned to
REM   variables via the new_value column option.
REM
col val1 new_val x_sp_size noprint
select Value val1
  from V$PARAMETER
 where Name='shared_pool_size'
/

col val2 new_val x_sp_used noprint
select SUM(Sharable_Mem+Persistent_Mem+Runtime_Mem) val2
  from V$SQLAREA
/

col val3 new_val x_sp_used_shr noprint
col val4 new_val x_sp_used_per noprint
col val5 new_val x_sp_used_run noprint
col val6 new_val x_sp_no_stmts noprint
select SUM(Sharable_Mem) val3,
       SUM(Persistent_Mem) val4,
       SUM(Runtime_Mem) val5,
       COUNT(*) val6
  from V$SQLAREA
/

col val7 new_val x_sp_no_obj noprint
select COUNT(*) val7
  from V$DB_OBJECT_CACHE 
/

col val8 new_val x_sp_avail noprint
select &x_sp_size-&x_sp_used val8
  from DUAL
/

col val9 new_val x_sp_no_pins noprint
select COUNT(*) val9
  from V$SESSION A, V$SQLTEXT B
 where A.SQL_Address||A.SQL_Hash_Value = B.Address||B.Hash_Value
/

col val10 new_val x_sp_sz_pins noprint
select SUM(Sharable_Mem+Persistent_Mem+Runtime_Mem) val10
  from V$SESSION A,
       V$SQLTEXT B,
       V$SQLAREA C
 where A.SQL_Address||A.SQL_Hash_Value = 
         B.Address||B.Hash_Value 
   and B.Address||B.Hash_Value = C.Address||C.Hash_Value
/

set termout on
ttitle -
  center  'Shared Pool Library Cache Information' skip 2

select  'Size                                         : '
  ||&x_sp_size sp_size,
        'Used (total)                                 : '
  ||&x_sp_used,
        '     sharable                                : '
  ||&x_sp_used_shr sp_used_shr,
        '     persistent                              : '
  ||&x_sp_used_per sp_used_per,
        '     runtime                                 : '
  ||&x_sp_used_run sp_used_run,
        'Available                                    : '
  ||&x_sp_avail sp_avail,
        'Number of SQL statements                     : '
  ||&x_sp_no_stmts sp_no_stmts,
        'Number of programatic constructs             : '
  ||&x_sp_no_obj sp_no_obj,
        'Pinned statements                            : '
  ||&x_sp_no_pins sp_no_pins,
        'Pinned statements size                       : '
  ||&x_sp_sz_pins sp_sz_pins
  from DUAL
/


