var email_upper varchar2(128);
var max_res varchar2(32);
var f_name varchar2(128);
var l_name varchar2(128);

exec :email_upper := 'S.BARRETT@%';
exec :f_name := 'LINDA';
exec :l_name := 'BARRETT';
exec :max_res := '100';

SELECT wuser.account_number 
FROM wuser 
WHERE wuser.first_name_upper = :f_name 
   AND wuser.last_name_upper = :l_name 
   AND wuser.account_number IN 
      (SELECT /*+ INDEX (WUSER_ALIAS WUSER_ALIAS_ALIAS_UPPER) */ wuser_alias.account_number 
       FROM wuser_alias 
       WHERE wuser_alias.alias_upper LIKE :email_upper) 
   AND ROWNUM <= :max_res
/
