select
	wua1.alias|| decode(sign(amount),1,'<- ','->')|| nvl(wua2.alias,'#### Type '||xact.type) parties,
        amount / 100 amount,to_char(udate.u2sql(xact.time_created),'MM/DD/YY HH24:MI'),xact.type, xact.id
from
	wtransaction xact,
        wuser_alias wua1,
        wuser_alias wua2
where
xact.account_number=&account_number
and wua1.account_number = xact.account_number      and bitand(wua1.flags,1)=1
and wua2.account_number (+) = xact.counterparty     and bitand(nvl(wua2.flags,1),1)=1
order by xact.time_created desc
/
