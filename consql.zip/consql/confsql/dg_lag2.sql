REM Script to report RTA lag of physical standby
REM Sai => 12/13/2011

set numwidth 20
col scn_time for a35
col la1 for a30

select current_scn, scn_to_timestamp(current_scn) scn_time, sysdate-scn_to_timestamp(current_scn) la1 from v$database;
