column changes_per_log format 999999999.99
select to_char(first_time,'MM/DD HH24')||':00' hour, 
count(*) num_logs,sum(switch_change#-first_change#) changes, 
sum(switch_change#-first_change#)*1.0/count(*)*1.0 changes_per_log
from v$loghist
where to_char(first_time,'HH24') = to_char(sysdate-1/24,'HH24') 
group by to_char(first_time,'MM/DD HH24')
/
