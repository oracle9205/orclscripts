column sample_time format a25
column event format a30
column maxtime format a10
column avgtime format a10
set linesize 200
--spool 12012008_11ash.txt
select SAMPLE_TIME, sample_id, event, count(*), round(max(TIME_WAITED)/1000,2)||' ms' maxtime, round(avg(TIME_WAITED)/1000,2)||' ms' avgtime
from v$active_session_history
where event not in ('SQL*Net more data from client')
group by SAMPLE_TIME, sample_id, event
having round(max(TIME_WAITED)/100,2)>1 and count(*)> 100
order by 1
/

