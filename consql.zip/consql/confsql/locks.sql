column "Holder" format a15
column "Waiter" format a15
column "Wait time" format 99999
column "Hold time" format 99999
column "Lock Type" format a10


select distinct o.name ,
        decode(lh.lmode, 1, 'null', 2,
              'row share', 3, 'row exclusive', 4,  'share',
              5, 'share row exclusive' , 6, 'exclusive')  "Lock Type"
	      ,lw.ctime "Wait time",lh.ctime "Hold time"
  from sys.obj$ o,  v$lock lw,  v$lock lh
 where lh.id1  = o.obj#
  and  lh.id1  = lw.id1
  and  lh.type = 'TM'
  and  lw.type = 'TM'
/
