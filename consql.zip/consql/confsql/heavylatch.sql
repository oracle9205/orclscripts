
column hit_ratio format 999.99
select latch#,name,round(100.0*gets/(decode(gets+misses,0,1,gets+misses)*1.0)) hit_ratio,gets,spin_gets,misses,sleeps,sleep1,sleep2,sleep3,sleep4
from v$latch
where latch# in ( 37, 26, 31, 60, 59 ) order by sleeps asc
/
