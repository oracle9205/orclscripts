CREATE OR REPLACE PACKAGE                                                                                                                                                           
OPS$ORACLE.waitinfo is                                                                                                                                                              
	function segbyblock (f# in number,b# in number) return varchar2;                                                                                                                   
	PRAGMA RESTRICT_REFERENCES(segbyblock,WNDS,WNPS);                                                                                                                                  
	function latchbynum(l# in number) return varchar2;                                                                                                                                 
	PRAGMA RESTRICT_REFERENCES(latchbynum,WNDS,WNPS);                                                                                                                                  
	function enqbynum(e# in number) return varchar2;                                                                                                                                   
	PRAGMA RESTRICT_REFERENCES(enqbynum,WNDS,WNPS);                                                                                                                                    
end;                                                                                                                                                                                
/                                                                                                                                                                                   
CREATE OR REPLACE PACKAGE BODY                                                                                                                                                      
OPS$ORACLE.waitinfo is                                                                                                                                                              
------------------------------------------------------------------------                                                                                                            
function enqbynum(e# in number)                                                                                                                                                     
        return varchar2                                                                                                                                                             
IS                                                                                                                                                                                  
cursor num2latch(n in number) is                                                                                                                                                    
        select name from v$latchname where latch#=n;                                                                                                                                
outstr varchar2(40);                                                                                                                                                                
BEGIN                                                                                                                                                                               
        open num2latch(e#);                                                                                                                                                         
        fetch num2latch into outstr;                                                                                                                                                
        if num2latch%NOTFOUND then                                                                                                                                                  
                outstr:=': No latch found for number '||to_char(e#);                                                                                                                
        end if;                                                                                                                                                                     
	close num2latch;                                                                                                                                                                   
        return outstr;                                                                                                                                                              
                                                                                                                                                                                    
END;                                                                                                                                                                                
------------------------------------------------------------------------                                                                                                            
function latchbynum(l# in number)                                                                                                                                                   
        return varchar2                                                                                                                                                             
IS                                                                                                                                                                                  
cursor num2latch(n in number) is                                                                                                                                                    
        select name from v$latchname where latch#=n;                                                                                                                                
outstr varchar2(40);                                                                                                                                                                
BEGIN                                                                                                                                                                               
        open num2latch(l#);                                                                                                                                                         
        fetch num2latch into outstr;                                                                                                                                                
        if num2latch%NOTFOUND then                                                                                                                                                  
                outstr:=to_char(l#)||': No latch found for';                                                                                                                        
        end if;                                                                                                                                                                     
        return outstr;                                                                                                                                                              
                                                                                                                                                                                    
END ;                                                                                                                                                                               
------------------------------------------------------------------------                                                                                                            
function segbyblock (f# in number,b# in number)                                                                                                                                     
	return varchar2                                                                                                                                                                    
IS                                                                                                                                                                                  
cursor block2seg(f# IN NUMBER,b# IN NUMBER) is                                                                                                                                      
	select seg.type#,seg.user#,seg.file#,seg.block#,seg.blocks,ext.ext#                                                                                                                
		from sys.seg$ seg, sys.uet$ ext                                                                                                                                                   
		where seg.file#  = ext.segfile#                                                                                                                                                   
		and  seg.block#  = ext.segblock#                                                                                                                                                  
		and ext.file#=f#                                                                                                                                                                  
		and b# between ext.block# and ext.block#+ext.length-1;                                                                                                                            
cursor seg2ind(f# IN NUMBER,b# IN NUMBER) is                                                                                                                                        
	select obj.name from sys.obj$ obj, sys.ind$ ind                                                                                                                                    
	where obj.obj#  = ind.obj#                                                                                                                                                         
	and    ind.file# = f#                                                                                                                                                              
	and    ind.block# = b#;                                                                                                                                                            
cursor seg2tab(f# IN NUMBER,b# IN NUMBER) is                                                                                                                                        
	select obj.name from sys.obj$ obj, sys.tab$ tab                                                                                                                                    
	where obj.obj#  = tab.obj#                                                                                                                                                         
	and    tab.file# = f#                                                                                                                                                              
	and    tab.block# = b#;                                                                                                                                                            
cursor seg2undo(f# IN NUMBER,b# IN NUMBER) is                                                                                                                                       
	select undo.name from sys.undo$ undo                                                                                                                                               
	where  undo.file# = f#                                                                                                                                                             
	and    undo.block# = b#;                                                                                                                                                           
cursor user2name(u IN NUMBER) is                                                                                                                                                    
	select username from dba_users where user_id=u;                                                                                                                                    
                                                                                                                                                                                    
segrec block2seg%ROWTYPE;                                                                                                                                                           
buff    varchar(40);                                                                                                                                                                
outstr varchar2(80);                                                                                                                                                                
extent#	integer;                                                                                                                                                                    
BEGIN                                                                                                                                                                               
                                                                                                                                                                                    
                                                                                                                                                                                    
			/* lets hope only one row is returned . .*/                                                                                                                                      
	open block2seg(f#,b#);                                                                                                                                                             
	fetch block2seg into segrec;                                                                                                                                                       
	if block2seg%NOTFOUND then                                                                                                                                                         
		outstr:='No segment found';                                                                                                                                                       
	else                                                                                                                                                                               
		extent#:=segrec.ext#;                                                                                                                                                             
		/* an index */                                                                                                                                                                    
	    if segrec.type# = 6 then                                                                                                                                                       
		outstr:='idx:';                                                                                                                                                                   
		open seg2ind(segrec.file#,segrec.block#);                                                                                                                                         
		fetch seg2ind into buff;                                                                                                                                                          
		if seg2ind%NOTFOUND then                                                                                                                                                          
			outstr:=outstr|| 'name not found';                                                                                                                                               
		else                                                                                                                                                                              
			outstr := outstr||buff;                                                                                                                                                          
		end if;                                                                                                                                                                           
		close seg2ind;                                                                                                                                                                    
	    elsif segrec.type# = 5 then                                                                                                                                                    
		outstr:='tbl:';                                                                                                                                                                   
		open seg2tab(segrec.file#,segrec.block#);                                                                                                                                         
		fetch seg2tab into buff;                                                                                                                                                          
		if seg2tab%NOTFOUND then                                                                                                                                                          
			outstr:=outstr|| 'name not found';                                                                                                                                               
		else                                                                                                                                                                              
			outstr := outstr||buff;                                                                                                                                                          
		end if;                                                                                                                                                                           
		close seg2tab;                                                                                                                                                                    
	    elsif segrec.type# = 1 then                                                                                                                                                    
		outstr:='rbs:';                                                                                                                                                                   
		open seg2undo(segrec.file#,segrec.block#);                                                                                                                                        
		fetch seg2undo into buff;                                                                                                                                                         
		if seg2undo%NOTFOUND then                                                                                                                                                         
			outstr:=outstr|| 'name not found';                                                                                                                                               
		else                                                                                                                                                                              
			outstr := outstr||buff;                                                                                                                                                          
		end if;                                                                                                                                                                           
		close seg2undo;                                                                                                                                                                   
	    else                                                                                                                                                                           
		outstr:='temp seg';                                                                                                                                                               
	    end if;                                                                                                                                                                        
			/* add the [file:block] address doublecheck */                                                                                                                                   
	    outstr:=outstr||'('||to_char(extent#)||')'||'['||ltrim(to_char(f#,'09'))||':'|| ltrim(to_char(b#,'099999')) ||'] ';                                                            
	end if;                                                                                                                                                                            
	close block2seg;                                                                                                                                                                   
	return outstr;                                                                                                                                                                     
END;                                                                                                                                                                                
                                                                                                                                                                                    
end waitinfo;                                                                                                                                                                       
/                                                                                                                                                                                   
