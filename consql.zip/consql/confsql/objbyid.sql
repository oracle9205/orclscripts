select object_name,object_type,owner from dba_objects where object_id=&objid
/
