REM Script to report ASH data of last 10 minutes, excluding db file like wait events.
REM Sai -> 04/21/2008

set trimspool on
set lines 199
set pages 1000
set arraysize 100
col stime for a10
col "EVENT#:P1:P2:P3" for a55
col "OBJ_FILE_BLOCK" for a19
spool /tmp/ash_noio.log

select
to_char(sample_time-(1/144), 'HH24:MI:SS') as stime,
sql_id,
event#||':'||substr(event, 1, 20)||': '||p1||':'||p2||':'||p3 "EVENT#:P1:P2:P3",
sum(time_waited) wtime,
max(time_waited) mtime,
count(*) cnt,
current_obj#||':'||current_file#||':'||current_block# "OBJ_FILE_BLOCK"
from v$active_session_history
where
sample_time between sample_time-(1/144) and sysdate and
event not in ('rdbms ipc message', 'pmon timer', 'smon timer') and
event not like 'db file%'
group by to_char(sample_time-(1/144), 'HH24:MI:SS'), sql_id,
         event#||':'||substr(event, 1, 20)||': '||p1||':'||p2||':'||p3,
         current_obj#||':'||current_file#||':'||current_block#
order by stime
/
