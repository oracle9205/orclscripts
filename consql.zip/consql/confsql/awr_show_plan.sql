REM Script to report execution plan from awr for a given sql_id
REM Sai => 12/13/2011

undef sql_id

select * from table(dbms_xplan.display_awr('&sql_id'))
/
