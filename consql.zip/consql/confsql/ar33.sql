rem 
explain plan for 
SELECT wuser.account_number
FROM wuser
WHERE wuser.account_number IN
(SELECT /*+ INDEX (WUSER_ALIAS WUSER_ALIAS_ALIAS_UPPER) */ wuser_alias.account_number
FROM wuser_alias
WHERE wuser_alias.alias_upper = :email_upper)
AND ROWNUM <= :max_res
/
@plan
rollback ;
