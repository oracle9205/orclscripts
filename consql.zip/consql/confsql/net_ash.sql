set pages 0 trims on 
select to_char(sample_time, 'DD-MON-YY HH24:MI:SS'), count(*), trunc(avg(time_waited)), max(time_waited) from 
&ASH_Dump_Table
where wait_class_id=2000153315 and to_char(sample_time, 'MM-DD-YY') > '05-28-11' group by to_char(sample_time, 'DD-MON-YY HH24:MI:SS')  order by  to_char(sample_time, 'DD-MON-YY HH24:MI:SS');
