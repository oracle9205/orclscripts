spool chk

show user

desc sys.all_users
desc sys.all_tables
desc sys.dba_objects
desc sys.all_catalog
desc sys.all_synonyms
desc sys.all_tab_partitions
desc sys.all_tab_subpartitions
desc sys.dba_data_files
desc sys.dba_extents
desc sys.dba_clu_columns
desc sys.dual
desc sys.product_component_version
desc sys.user_catalog
desc v$nls_parameters

spool off
