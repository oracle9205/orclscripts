select sid,EVENT,p1,p2,p3 from v$session where sid in (select BLOCKER_SID from v$wait_chains);
