select decode(begin_date,trunc(sysdate),'*',' ') Today,to_char(begin_date,'day'),wp.* from wpaypal_day wp  where begin_date between sysdate-8 and sysdate
/
