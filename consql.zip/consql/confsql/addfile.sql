--changed so race condition with datafiles does not happen ECRCHNGE00506943
-- kcg
set serveroutput on;
set feedback off;
exec dbms_output.put_line('   ');
exec dbms_output.put_line('ATTENTION: this script is deprecated please use the below method');
exec dbms_output.put_line('To add space to 1 ts: /oracle/<SID>/home/bin/datafiles -s<SID> -t<TSNAME> -av');
exec dbms_output.put_line('To run the auto-add by hand: /oracle/<SID>/home/bin/check_table_space -av');
exec dbms_output.put_line('To see help: run either command with just -h');
exec dbms_output.put_line('   ');
exec dbms_output.put_line('this is so manual addition and the auto-add do not collide');
exit;

