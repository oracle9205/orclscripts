set pages 999
break on date_sub skip 1
col number_of_threads heading 'Number Of|Threads'
col thread# heading 'Thread|Number'
col date_t format a20 heading 'Time Frame'
col date_sub heading 'Date'
compute sum of number_of_threads on date_sub



select		substr(to_char(first_time,'Mon - DDth'),1,10) DATE_SUB
,		to_char(first_time,'Mon - DDth  HHam') DATE_T
,		count(*) NUMBER_OF_THREADS
,		thread#
FROM		V$LOGHIST
GROUP BY	substr(to_char(first_time,'Mon - DDth'),1,10)
,		THREAD#
,		to_char(first_time,'Mon - DDth  HHam')
order by	substr(to_char(first_time,'Mon - DDth'),1,10)
,		to_char(first_time,'Mon - DDth  HHam')
/

