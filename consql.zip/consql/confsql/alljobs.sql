column what format a65
column interval format a30
column mins_to_exec format a10
SELECT 
        job
       ,to_char(last_date,'DD-MON-YY HH24:MI:SS') "LAST_DATE"
       ,to_char(next_date,'DD-MON-YY HH24:MI:SS') "NEXT_DATE"
       ,decode(broken,'Y','BROKEN',to_char(ROUND((next_date - SYSDATE)*24*60)))  mins_to_exec
       ,interval
       ,what         
  FROM
        dba_jobs
 ORDER BY NEXT_DATE ASC;


