col table_owner format a10
col table_name format a28
col high_value format a20

select table_owner, partition_name ,buffer_pool, high_value, partition_position, num_rows from dba_tab_partitions where table_name=upper('&table_name') order by partition_position ;
