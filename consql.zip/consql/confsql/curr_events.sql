col event format a40

select event, total_waits, time_waited, average_wait, total_timeouts 
from v$system_event 
order by time_waited ;

