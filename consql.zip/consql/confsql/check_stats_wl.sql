column column_name format a20;
column index_name format a30;
column partition_name format a10;
column AVG_LEAF_BLOCKS_PER_KEY format 999;
column AVG_DATA_BLOCKS_PER_KEY format 999;

SPOOL ST3.LOG
SET ECHO ON;
select table_name, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, AVG_ROW_LEN , GLOBAL_STATS, USER_STATS, sample_size 
from user_tables 
    where table_name = 'WLOG_ENTRY'; 

select partition_name "Partition", NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, AVG_ROW_LEN,  SAMPLE_SIZE, global_stats, user_stats 
 from user_tab_partitions 
 where table_name = 'WLOG_ENTRY' 
 order by partition_position 
/ 

 
select COLUMN_NAME, NUM_DISTINCT, DENSITY, NUM_NULLS, NUM_BUCKETS, LAST_ANALYZED 
from   user_tab_col_statistics 
where table_name = 'WLOG_ENTRY' 
/ 

select partition_name, COLUMN_NAME, NUM_DISTINCT, DENSITY, NUM_NULLS, NUM_BUCKETS, LAST_ANALYZED 
from user_part_col_statistics 
  where table_name = 'WLOG_ENTRY' 
/ 

select index_name, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, GLOBAL_STATS  
   from user_indexes 
   where TABLE_NAME= 'WLOG_ENTRY' 
/

select index_name, PARTITION_NAME, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, 
    CLUSTERING_FACTOR, GLOBAL_STATS 
from user_ind_partitions 
    where index_name IN (SELECT INDEX_NAME FROM DBA_INDEXES WHERE TABLE_NAME='WLOG_ENTRY'); 

select index_name,partition_name,status,tablespace_name
from user_ind_partitions
    where index_name IN (SELECT INDEX_NAME FROM DBA_INDEXES WHERE TABLE_NAME='WLOG_ENTRY');



spool off;

