set pagesize 0
spool dc.sql
select 'alter system disconnect session '''||sid||','||serial#||''' immediate;' from v$session where machine='scfvmware1';
spool off
