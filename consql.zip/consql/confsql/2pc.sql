column global_tran_id format a40
column paypal_global_tran_id format a40
column tran_comment format a30
column host format a10
select utl_raw.cast_to_varchar2(hextoraw(substr(global_tran_id,3))) paypal_global_tran_id,state,local_tran_id,fail_time,force_time,host,db_user from dba_2pc_pending 
/
