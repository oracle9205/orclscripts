select * from v$sess_io where sid = (select distinct sid from  v$mystat)
/
