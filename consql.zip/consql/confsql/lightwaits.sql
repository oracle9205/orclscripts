REM Rewrote the script for 10g and above.
REM Sai -> 04/17/2008

set trimspool on
set lines 199
set pages 1000
set arraysize 100
col "SID:MACHINE" for a18
col "HASH_VALUE" for 9999999999999
col "EVENT#:P1:P2:P3:WAITING_STATUS" for a57
col "MODULE:CALL_TIME_SEC" for a20


select
s.sid||':'||s.machine "SID:MACHINE",
decode(s.sql_hash_value, 0, s.prev_hash_value, s.sql_hash_value) "HASH_VALUE",
i.block_gets+i.consistent_gets gets,
s.event#||':'||substr(s.event, 1, 20)||': '||s.p1||':'||s.p2||':'||s.p3||':'||
decode(state, 'WAITING', 'WAIT:'||seconds_in_wait, 'NOWAIT:'||seconds_in_wait) "EVENT#:P1:P2:P3:WAITING_STATUS",
case when length(module) > 13 then substr(module, -13) else module end||':'||s.last_call_et "MODULE:CALL_TIME_SEC"
from
v$session s, v$sess_io i
where
s.sid = i.sid and
s.status = 'ACTIVE' and
s.event not in ('rdbms ipc message', 'pmon timer', 'smon timer', 'jobq slave wait')
order by s.event#
/
