select s.sid,s.sql_address sqladdr,w.event,io.block_gets+io.consistent_gets gets,
		s.module,
		    seconds_in_wait seconds,
	decode(w.event,'db file sequential read' ,waitinfo.segbyblock(w.p1,w.p2),
			'free buffer waits' ,waitinfo.segbyblock(w.p1,w.p2),
			'db file scattered read' ,waitinfo.segbyblock(w.p1,w.p2),
			'buffer busy waits' ,waitinfo.segbyblock(w.p1,w.p2),
			'write complete waits' ,waitinfo.segbyblock(w.p1,w.p2),
			'enqueue' ,waitinfo.segbyblock(s.row_wait_file#,s.row_wait_block#),
			'latch free',waitinfo.latchbynum(w.p2)||': tries='||to_char(w.p3),
			'latch activity',waitinfo.latchbynum(w.p2),
			 decode(w.p1text,'','',w.p1text||':'||to_char(w.p1)) ||
			 decode(w.p2text,'','',','||w.p2text||':'||to_char(w.p2)))  info
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where  s.sid = w.sid and io.sid=w.sid and
	s.status='ACTIVE'
	and s.module='BATCH'
	and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
	order by event,info
/
