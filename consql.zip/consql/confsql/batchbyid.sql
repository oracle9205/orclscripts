
select /*+ full(a) full(b) use_hash(b) */ a.id, a.batch_id, a.batch_num, a.status, nvl(to_char(b.time_created-a.time_created), 'Running') Time_taken, a.command_line from wbatch_log a , wbatch_log b
where a.batch_id=&batch_id
and a.time_created <= sql2u(sysdate)
and a.run_date >= sql2u(trunc(sysdate-1))
and a.status='S'
and a.id=b.parent_id(+) ;
