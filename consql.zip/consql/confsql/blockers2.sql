REM Script to report blockers directly from v$session
REM Sai -> 06/15/2011

set lines 199
col blocker for a9
col sql_id for a13
col status for a13
col waiters for 99999
col lock_sec for 9999999
col event for a30

select
 blocker,
 max(sql_id) sql_id,
 max(blocking_session_status) status,
 count(*) waiters,
 round(max(wait_time_micro)/1000000) lock_sec,
 max(event) event
from
(select 
 case when blocking_session=final_blocking_session and blocking_session >0 then
      'L1: '||blocking_session
      else
      'L2: '||blocking_session
 end as blocker, blocking_session, nvl(sql_id, prev_sql_id) sql_id,
 blocking_session_status, wait_time_micro, substr(event,1,30) event
 from v$session)
where blocking_session > 0
group by blocker
order by blocker
/
