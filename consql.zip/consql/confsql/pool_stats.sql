REM  poolstats.sql
REM  Shared SQL area user statistics
REM
REM 
set serveroutput on size 10000

DECLARE

val1 number;
val2 number;
val3 number;
val4 number;
val5 number;
val6 number;
val7 number;
val8 number;

BEGIN

select round(100*(1-(SUM(Reloads)/SUM(Pins))),2) into val1
  from V$LIBRARYCACHE;

select round(100*(1-(SUM(Getmisses)/SUM(Gets))),2) into val2
  from V$ROWCACHE;

select Value into val3
  from V$SYSSTAT
 where Name = 'physical reads';

select Value into val4
  from V$SYSSTAT
 where Name = 'db block gets';

select Value into val5
  from V$SYSSTAT
 where Name = 'consistent gets';

select round(100*(1-(val3 / (val4 + val5))),2) into val6
  from DUAL ;

select round(SUM(Users_Opening)/COUNT(*),2), round(SUM(Executions)/COUNT(*),2) into val7, val8
  from V$SQLAREA;


DBMS_OUTPUT.PUT_LINE('-------  SGA Cache Hit Ratios  -----------------');
DBMS_OUTPUT.PUT_LINE('Data Block Buffer Hit Ratio : '|| val6           );
DBMS_OUTPUT.PUT_LINE('-------  Shared SQL Pool  ----------------------');
DBMS_OUTPUT.PUT_LINE('Dictionary Hit Ratio        : '|| val2           );
DBMS_OUTPUT.PUT_LINE('-------- Shared SQL Buffers (Library Cache) ----');
DBMS_OUTPUT.PUT_LINE('Cache Hit Ratio             : '|| val1           );
DBMS_OUTPUT.PUT_LINE('Avg. Users/Stmt             : '|| val7           );
DBMS_OUTPUT.PUT_LINE('Avg. Executes/Stmt          : '|| val8           );
DBMS_OUTPUT.PUT_LINE('------------------------------------------------');

END ;
/
