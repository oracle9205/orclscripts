set linesize 200
column sid format 999
column osuser format a10
column wait format a10
column info format a60
column action format a10
column sec format 99
column module format a14
select username,osuser,s.sid,s.sql_address sqladdr,w.event,module,io.block_gets+io.consistent_gets gets,
                    seconds_in_wait sec,
chr(bitand(w.p1,-16777216)/16777215) || chr(bitand(w.p1,16711680)/65535) as "lock_mode"
from v$session_wait w,
     v$sess_io     io,
     v$session      s
        where  s.sid = w.sid and io.sid=w.sid and
        s.status='ACTIVE'
        and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
        order by event
/
