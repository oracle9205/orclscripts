10:05:52 SQL> @window_grant

'GRANT'||A.GRANTED_ROLE||'TO'||B.USERNAME||';'                                                                                                                                      
-----------------------------------------------------------------------                                                                                                             
grant CONNECT to ATCK;                                                                                                                                                              
grant SELECT_DW to ATCK;                                                                                                                                                            
grant RESOURCE to ATCK;                                                                                                                                                             
grant CONNECT to AUCT;                                                                                                                                                              
grant SELECT_DW to AUCT;                                                                                                                                                            
grant RESOURCE to AUCT;                                                                                                                                                             
grant SELECT_CATALOG_ROLE to BATCH_USER;                                                                                                                                            
grant AUCT_R to BATCH_USER;                                                                                                                                                         
grant NEW_DW_USER to BATCH_USER;                                                                                                                                                    
grant CTOC_R to BATCH_USER;                                                                                                                                                         
grant ATCK_R to BATCH_USER;                                                                                                                                                         
grant RESOURCE to BATCH_USER;                                                                                                                                                       
grant IGOR_R to BATCH_USER;                                                                                                                                                         
grant CONNECT to BATCH_USER;                                                                                                                                                        
grant SELECT_DW to BATCH_USER;                                                                                                                                                      
grant RDONLY_R to BATCH_USER;                                                                                                                                                       
grant SELECT_DW to CMCGRAW;                                                                                                                                                         
grant ATCK_R to CMCGRAW;                                                                                                                                                            
grant IGOR_R to CMCGRAW;                                                                                                                                                            
grant NEW_DW_USER to CMCGRAW;                                                                                                                                                       
grant RESOURCE to CTOC;                                                                                                                                                             
grant CTOC_R to CTOC;                                                                                                                                                               
grant CONNECT to CTOC;                                                                                                                                                              
grant SELECT_CATALOG_ROLE to CTOC;                                                                                                                                                  
grant SNMPAGENT to DBSNMP;                                                                                                                                                          
grant CONNECT to DBSNMP;                                                                                                                                                            
grant RESOURCE to DBSNMP;                                                                                                                                                           
grant SELECT_DW to DKRANTZ;                                                                                                                                                         
grant EBAY_LOAD_USERS to DKRANTZ;                                                                                                                                                   
grant CTOC_R to DKRANTZ;                                                                                                                                                            
grant IGOR_R to DKRANTZ;                                                                                                                                                            
grant CONNECT to DKRANTZ;                                                                                                                                                           
grant NEW_DW_USER to DKRANTZ;                                                                                                                                                       
grant RDONLY_R to DKRANTZ;                                                                                                                                                          
grant CONNECT to EBAYLOAD;                                                                                                                                                          
grant RESOURCE to EBAYLOAD;                                                                                                                                                         
grant EBAY_LOAD to EBAYLOAD;                                                                                                                                                        
grant EBAY_USERS_RO to FACT;                                                                                                                                                        
grant DBA to FACT;                                                                                                                                                                  
grant CONNECT to FACT;                                                                                                                                                              
grant RDONLY_R to FACT;                                                                                                                                                             
grant RESOURCE to FACT;                                                                                                                                                             
grant CONNECT to IGORBAT;                                                                                                                                                           
grant NEW_DW_USER to IGORBAT;                                                                                                                                                       
grant SELECT_DW to IGORBAT;                                                                                                                                                         
grant SELECT_MM to IGORBAT;                                                                                                                                                         
grant RDONLY_R to IGORBAT;                                                                                                                                                          
grant SELECT_CATALOG_ROLE to OPS$ORACLE;                                                                                                                                            
grant CONNECT to OPS$ORACLE;                                                                                                                                                        
grant CTOC_R to OPS$ORACLE;                                                                                                                                                         
grant SELECT_MM to OPS$ORACLE;                                                                                                                                                      
grant SELECT_DW to OPS$ORACLE;                                                                                                                                                      
grant DBA to OPS$ORACLE;                                                                                                                                                            
grant EBAY_LOAD_USERS to OPS$ORACLE;                                                                                                                                                
grant AUCT_R to OPS$ORACLE;                                                                                                                                                         
grant ATCK_R to OPS$ORACLE;                                                                                                                                                         
grant RESOURCE to OPS$ORACLE;                                                                                                                                                       
grant NEW_DW_USER to OPS$ORACLE;                                                                                                                                                    
grant IGOR_R to OPS$ORACLE;                                                                                                                                                         
grant ESERVICE_R to OPS$ORACLE;                                                                                                                                                     
grant EBAY_LOAD to OPS$ORACLE;                                                                                                                                                      
grant NEW_DW_USER to PALASH;                                                                                                                                                        
grant SELECT_DW to PALASH;                                                                                                                                                          
grant SELECT_CATALOG_ROLE to PERFSTAT;                                                                                                                                              
grant CONNECT to PERFSTAT;                                                                                                                                                          
grant SELECT_DW to PERFSTAT;                                                                                                                                                        
grant CONNECT to SAR;                                                                                                                                                               
grant ATCK_R to SAR;                                                                                                                                                                
grant RDONLY_R to SAR;                                                                                                                                                              
grant NEW_DW_USER to SAR;                                                                                                                                                           
grant IGOR_R to SAR;                                                                                                                                                                
grant AUCT_R to SAR;                                                                                                                                                                
grant CTOC_R to SAR;                                                                                                                                                                
grant SELECT_CATALOG_ROLE to SAR;                                                                                                                                                   
grant SELECT_DW to SAR;                                                                                                                                                             
grant SELECT_DW to SYS;                                                                                                                                                             
grant EXECUTE_CATALOG_ROLE to SYS;                                                                                                                                                  
grant HS_ADMIN_ROLE to SYS;                                                                                                                                                         
grant OEM_MONITOR to SYS;                                                                                                                                                           
grant DELETE_CATALOG_ROLE to SYS;                                                                                                                                                   
grant DBA to SYS;                                                                                                                                                                   
grant CONNECT to SYS;                                                                                                                                                               
grant AQ_USER_ROLE to SYS;                                                                                                                                                          
grant AQ_ADMINISTRATOR_ROLE to SYS;                                                                                                                                                 
grant SELECT_CATALOG_ROLE to SYS;                                                                                                                                                   
grant RESOURCE to SYS;                                                                                                                                                              
grant RECOVERY_CATALOG_OWNER to SYS;                                                                                                                                                
grant PLUSTRACE to SYS;                                                                                                                                                             
grant IMP_FULL_DATABASE to SYS;                                                                                                                                                     
grant EXP_FULL_DATABASE to SYS;                                                                                                                                                     
grant SNMPAGENT to SYS;                                                                                                                                                             
grant AQ_ADMINISTRATOR_ROLE to SYSTEM;                                                                                                                                              
grant DBA to SYSTEM;                                                                                                                                                                
grant CONNECT to SYSTEM;                                                                                                                                                            
grant SELECT_DW to SYSTEM;                                                                                                                                                          
grant ATCK_R to TTRAN;                                                                                                                                                              
grant CONNECT to TTRAN;                                                                                                                                                             
grant RESOURCE to TTRAN;                                                                                                                                                            
grant SELECT_DW to TTRAN;                                                                                                                                                           
10:06:00 SQL> spool
currently spooling to g1.sql
10:06:10 SQL> @g1
SP2-0734: unknown command beginning "10:05:52 S..." - rest of line ignored.
SP2-0734: unknown command beginning "'GRANT'||A..." - rest of line ignored.
Input truncated to 65 characters
10:06:14 SQL> 
10:14:47 SQL> 
10:14:47 SQL> 
10:14:47 SQL> 
10:14:48 SQL> 
10:40:43 SQL> 
10:40:43 SQL> 
10:40:44 SQL> desc timewindow
 Name                                                                                                  Null?    Type
 ----------------------------------------------------------------------------------------------------- -------- --------------------------------------------------------------------
 STIME                                                                                                          NUMBER
 ETIME                                                                                                          NUMBER
 PROFILE                                                                                                        VARCHAR2(100)

10:40:53 SQL> select * from timewindow;

     STIME      ETIME PROFILE                                                                                                                                                       
---------- ---------- ----------------------------------------------------------------------------------------------------                                                          
         0       2399 DBA                                                                                                                                                           
         0       2399 FRAUD_MODELS                                                                                                                                                  
       800       2399 REPORTS                                                                                                                                                       
      1000       2399 FRAUD_ANALYTICS                                                                                                                                               
      1300       2399 REPORTS_ADHOC                                                                                                                                                 
         0          0 FINSYS                                                                                                                                                        
         0          0 DEVELOPERS                                                                                                                                                    
       800       2399 SAR_COMPLIANCE                                                                                                                                                
10:41:03 SQL> alter table timewindow set stime=800 where profile=REPORTS;
alter table timewindow set stime=800 where profile=REPORTS
                           *
ERROR at line 1:
ORA-02000: missing UNUSED keyword 


10:41:31 SQL> connect fact/fiction;
Connected.
10:41:40 SQL> alter table timewindow set stime=800 where profile='REPORTS';
alter table timewindow set stime=800 where profile='REPORTS'
                           *
ERROR at line 1:
ORA-02000: missing UNUSED keyword 


10:41:56 SQL> update timewindow set stime=800 where profile='REPORTS';
update timewindow set stime=800 where profile='REPORTS'
       *
ERROR at line 1:
ORA-00942: table or view does not exist 


10:42:19 SQL> connect /
Connected.
10:42:26 SQL> update timewindow set stime=800 where profile='REPORTS';
10:42:32 SQL> commit;
10:42:34 SQL> select * from timewindow;

     STIME      ETIME PROFILE                                                                                                                                                       
---------- ---------- ----------------------------------------------------------------------------------------------------                                                          
         0       2399 DBA                                                                                                                                                           
         0       2399 FRAUD_MODELS                                                                                                                                                  
       800       2399 REPORTS                                                                                                                                                       
      1000       2399 FRAUD_ANALYTICS                                                                                                                                               
      1300       2399 REPORTS_ADHOC                                                                                                                                                 
         0          0 FINSYS                                                                                                                                                        
         0          0 DEVELOPERS                                                                                                                                                    
       800       2399 SAR_COMPLIANCE                                                                                                                                                
10:42:39 SQL> 