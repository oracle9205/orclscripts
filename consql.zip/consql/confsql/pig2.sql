REM ADDRESS       LOADS PARSE_CALLS EXECUTIONS BUFFER_GETS DISK_READS
REM 82201E90          4         176       1959      379561     342767
explain plan for
SELECT wtransaction.id,wtransaction.parent_id,wtransaction.type,wtransaction.time_created,
	wtransaction.time_processed,wtransaction.flags,wtransaction.account_number,
	wtransaction.shared_id,wtransaction.counterparty,wtransaction.amount,wtransaction.status,
	wtransaction.memo,wtransaction.message_id,wtransaction.reason,wtransaction.time_user,
	wtransaction.counterparty_alias,wtransaction.counterparty_alias_type,wtransaction.cctrans_id,
	wtransaction.sync_group,wtransaction.ach_id,wtransaction.address_id 
FROM wtransaction 
WHERE counterparty_alias=:counterparty_alias
/
@plan
rollback ;

