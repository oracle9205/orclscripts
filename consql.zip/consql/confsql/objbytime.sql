REM => Most recent segments created , top 25
REM => Sai, 06/14/2011

col owner for a10
col object_name for a30
col subobject_name for a19

select * from (select owner, object_name, subobject_name, object_id, data_object_id, created from dba_objects where 
              created > sysdate-7 order by created desc)
where rownum <= 25
/
