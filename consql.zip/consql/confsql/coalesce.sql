set verify off heading on feeback off echo off pagesize 56
set numformat 999,999,999,999
def tablespace_name = &&1

col ts# new_value ts_num noprint
select ts# from sys.ts$
where name = upper('&tablespace_name');

select count(*) free_extents, max(bytes) largest_extent
from dba_free_space
where tablespace_name = upper('&tablespace_name');

alter session set events = 'immediate trace name coalesce level &ts_num';

select count(*) free_extents, max(bytes) largest_extent
from dba_free_space
where tablespace_name = upper('&tablespace_name');
 
undefine 1
undefine tablespace_name
set echo on feedback on
