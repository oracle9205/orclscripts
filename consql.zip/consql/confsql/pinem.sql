declare 
 own varchar2(100); 
 nam varchar2(100); 
cursor pkgs is 
  select owner, object_name from dba_objects where object_type in('PACKAGE','PROCEDURE','FUNCTION','TRIGGER')
	and owner!='SYS'; 
begin 
open pkgs; 
loop 
fetch pkgs into own, nam; 
exit when pkgs%notfound; 
dbms_output.put_line('exec sys.dbms_shared_pool.keep('''||own|| '.'|| nam||''', ''P''); ');
end loop; 
end; 
/

declare 
 own varchar2(100); 
 nam varchar2(100); 
cursor pkgs is 
  select owner, object_name from dba_objects where object_type in('TRIGGER')
	and owner!='SYS'; 
begin 
open pkgs; 
loop 
fetch pkgs into own, nam; 
exit when pkgs%notfound; 
dbms_output.put_line('exec sys.dbms_shared_pool.keep('''||own|| '.'|| nam||''', ''R''); ');
end loop; 
end; 
/

declare 
 own varchar2(100); 
 nam varchar2(100); 
cursor pkgs is 
  select owner, object_name from dba_objects where object_type in('PACKAGE','PROCEDURE','FUNCTION','TRIGGER')
	and owner!='SYS'; 
begin 
open pkgs; 
loop 
fetch pkgs into own, nam; 
exit when pkgs%notfound; 
dbms_output.put_line('exec sys.dbms_shared_pool.keep('''||own|| '.'|| nam||''', ''P''); ');
end loop; 
end; 
/

