accept p1 prompt p1=
select chr(bitand(&p1,-16777216)/16777215) ||
chr(bitand(&p1,16711680)/65535)  from dual
