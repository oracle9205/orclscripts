select sum(pins) "Pins/Executions",
sum(gets) "Gets",
sum(reloads) "Cache Misses while executing" ,
sum(reloads)/sum(pins) *100 "Library Cache Hit Ratio" 
from v$librarycache 
/

select namespace, sum(pins) "Pins/Executions",
sum(gets) "Gets",
sum(reloads) "Cache Misses while executing" ,
sum(reloads) / sum(decode(pins,0,1,pins)) *100 "Library Cache Hit Ratio"
from v$librarycache group by namespace
/
