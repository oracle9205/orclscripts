 col VOLUME for a8
 col DATAFILE for a55
 col READTIM for 9999
 col WRITETIM for 9999
 col PCT_READS for 99
 col PCT_WRITES for 99
 col FILE# for 9999

 select a.name as volume,
 round(READTIM/READS) READTIM,
 round((READS/TOTREADS)*100) PCT_READS,
 round(WRITETIM/WRITES) as WRITETIM,
 round((WRITES/TOTWRITES)*100) as PCT_WRITES,
 a.FILE#,
 replace(substr(b.name, (instr(b.name, '/', -1)+1)), '::cdev:vxfs:') as DATAFILE
 from
 (
 select
 distinct substr(a.name, 14, 6) name,
 sum(io2.readtim-io1.readtim) over (partition by (substr(a.name, 14, 6))) READTIM,
 sum(io2.phyrds-io1.phyrds) over (partition by (substr(a.name, 14, 6))) READS,
 sum(io2.writetim-io1.writetim) over (partition by (substr(a.name, 14, 6))) WRITETIM,
 sum(io2.phywrts-io1.phywrts) over (partition by (substr(a.name, 14, 6))) WRITES,
 sum(io2.phyrds-io1.phyrds) over () TOTREADS,
 sum(io2.phywrts-io1.phywrts) over () TOTWRITES,
 max(io2.file#) over (partition by substr(a.name, 14, 6)
 order by io2.phywrts-io1.phywrts desc) FILE#,
 row_number() over (partition by substr(a.name, 14, 6) order by io2.phywrts-io1.phywrts desc) RN
 from v$dbfile a, v$filestat io2, (select file#, 0 readtim, 0 phyrds, 0 phywrts, 0 writetim from v$filestat) io1
 where a.file# = io1.file# and
 io2.file# = io1.file# and
 io2.phyrds-io1.phyrds > 0 and
 io2.phywrts-io1.phywrts > 0
 ) a, v$dbfile b
 where
 RN = 1 and
 a.file# = b.file#
 order by PCT_WRITES desc, WRITETIM desc
/
