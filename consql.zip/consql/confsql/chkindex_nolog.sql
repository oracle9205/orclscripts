select a.owner,a.index_name,a.table_name,a.tablespace_name,b.created from dba_indexes a, dba_objects b where a.logging='NO' and a.index_name=b.object_name and b.created > (sysdate-3) order by b.created
/
