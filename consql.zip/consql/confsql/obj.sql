select object_name, object_type, owner, status, to_char(created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects  where created
> ( sysdate - &No_of_days_old ) order by created, owner, object_type 
/
