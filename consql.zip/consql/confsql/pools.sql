column name format a10
column hit format 999.0
column consistent_gets format 999,999,999,999
column db_block_gets   format 999,999,999,999
column db_block_change   format 999,999,999,999
column physical_reads  format 999,999,999,999
column physical_writes  format 999,999,999,999

select name, 
set_msize,
 DB_BLOCK_GETS     ,
 CONSISTENT_GETS  ,
 PHYSICAL_READS  ,
 DB_BLOCK_CHANGE,
 PHYSICAL_WRITES ,
 100*(1-physical_reads/(db_block_gets+consistent_gets)) hit
from sys.v_$buffer_pool_statistics 
/
