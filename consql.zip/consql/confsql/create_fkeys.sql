col Parent_table format a20
col column_name format a20
col constraint_name format a40

select ' Alter table ' || A.Table_name || ' add constraint '|| A.Constraint_name || ' foreign key '|| '(' || C.Column_name || ') ref
erences ' || B.Table_name || '(' || C.Column_name || ') on delete cascade enable novalidate ; ' 
  from DBA_CONSTRAINTS A, 
       DBA_CONSTRAINTS B, 
       DBA_CONS_COLUMNS C
 where A.R_Constraint_Name = B.Constraint_Name
   and A.Constraint_Type='R'
   and B.Constraint_Type ='P'
   and A.Constraint_Name=C.Constraint_Name
   and A.Table_Name=C.Table_Name
   and B.Table_Name=upper('&table_name')
 order by B.Table_Name, A.Table_Name, C.Position
/
