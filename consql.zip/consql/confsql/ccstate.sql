 select
         u2sql(trunc(time_created/10)*10),
    count(*)/10 cctrans_per_sec,
    count(*) total_trans,
    count(decode(status,'D',1))  denied,
    count(decode(status,'E',1))  e ,
    count(decode(status,'P',1))  Pending,
    count(decode(status,'S',1))  Success,
    count(decode(status,'D',null,'E',null,'P',null,'S',null,1))  other
 from wcctrans
 where id > (select max(id)-1000 from wcctrans)
group by trunc(time_created/10)*10
/
