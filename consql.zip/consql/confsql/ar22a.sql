var email_upper varchar2(128);
var max_res varchar2(32);
var f_name varchar2(128);
var l_name varchar2(128);

exec :email_upper := 'S.BARRETT@%';
exec :f_name := 'LINDA';
exec :l_name := 'BARRETT';
exec :max_res := '100';

SELECT account_number
FROM
(
SELECT a.account_number 
FROM wuser a, wuser_alias b
WHERE a.first_name_upper = :f_name 
   AND a.last_name_upper = :l_name 
   AND a.account_number = b.account_number
   AND b.alias_upper LIKE :email_upper
)
WHERE ROWNUM <= :max_res
/
