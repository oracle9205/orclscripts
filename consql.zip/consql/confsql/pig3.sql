REM 
REM ADDRESS       LOADS PARSE_CALLS EXECUTIONS BUFFER_GETS DISK_READS
REM 81F9C254          7         650       4834      509601     490016
REM
REM this will be fixed by index on wcctrans(account_number)
REM
explain plan for 
SELECT account_number FROM wuser_alias WHERE alias_upper=UPPER(:emailid) AND type='E'
/
@plan
rollback ;

