column machine format a15
column info format a50
column wait format a6
column event format a30
column sid format 99999
column seq# format 999999
column host format a7
column module format a22
column seconds format 9999


select substr(s.program,1,20) program,s.sid,seq#,substr(module,instr(module,'/',-1)+1) module,w.event,
	decode(w.state,'WAITING','WAIT'
		    ,'WAITED KNOWN TIME',to_char(w.wait_time/100)
		    ,'WAITED SHORT TIME','SHORT'
		    ,'WAITED UNKNOWN TIME','?'
		    ,w.state) wait,
		    seconds_in_wait seconds,
	decode(w.p1text,'file#' ,waitinfo.segbyblock(w.p1,w.p2),
			'latch#',waitinfo.latchbynum(w.p1),
			         w.p1text||' '||to_char(w.p1)||' '||rawtohex(w.p1raw)) info
from v$session_wait w,
     v$session	    s
	where s.sid = w.sid
	and w.event != 'SQL*Net message from client'
	and s.machine not like 'BOMBAY%'
	and username is not null
	order by module 
/

