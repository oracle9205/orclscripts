column "sid,ser#" format a13
select  sql_address sqladdr,substr(a.username,1,8) USERNAME, machine,
	substr(b.spid,1,6) SRVPID, ''''||to_char(a.sid)||','||to_char(a.serial#)||'''' "sid,ser#" ,
	to_char(a.logon_time,'MM/DD HH24:MI') logon_time,
	a.module Module, substr(a.status,1,1) stat, substr(a.program,1,25) PROGRAM
	from v$process b, v$session a
	where a.paddr = b.addr and  a.username='IVR_INTERFACE'
	order by a.username,b.spid
/
