select hi Site , low Stage, hi-low Data_lag  from 
( select max(id) hi from confdba.new_wlog_entry_hash ) h, 
( select max(id) low from confdba.new_wlog_entry_insert ) i
;
