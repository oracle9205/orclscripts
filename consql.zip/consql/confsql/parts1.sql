col high_value format a35
col table_owner format a10
select * from ( select table_owner, partition_name , high_value, partition_position, num_rows from dba_tab_partitions where table_name=upper('&table_name') order by partition_position desc ) where rownum < 10
/
