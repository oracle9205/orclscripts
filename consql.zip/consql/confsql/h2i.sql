REM Script to convert hash value to sql_id
REM Tanel Poder

CREATE OR REPLACE FUNCTION h2i (p_hash_value NUMBER) RETURN VARCHAR2 IS
l_output VARCHAR2(8) := �;
BEGIN
FOR i IN (
select substr(�0123456789abcdfghjkmnpqrstuvwxyz�, 1+floor(mod(p_hash_value/(POWER(32,LEVEL-1)),32)),1) sqlidchar
FROM dual
CONNECT BY LEVEL <= LN(p_hash_value)/LN(32)
ORDER BY LEVEL DESC
) LOOP
l_output := l_output || i.sqlidchar;
END LOOP;
RETURN l_output;
END;
/
