 select object_name, object_type, owner, status, to_char(created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects  where created > ( sysdate - &No_of_days_old ) and object_type in ('TABLE', 'INDEX') and owner=upper('&obj_owner') order by created, owner, object_type 
/
