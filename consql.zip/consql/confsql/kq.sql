select n.name,s.value
	from v$sesstat s, v$statname n
	where s.value > 0
	and s.sid=152
	and n.statistic#=s.statistic#
	and (n.name like 'table scan%' or n.name like '%get%')
/
