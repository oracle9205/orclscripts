accept suffix prompt 'sufifx: '
create table events_&suffix as select * from v$system_event;
drop synonym events_prev ;
create synonym events_prev for events_&suffix;
