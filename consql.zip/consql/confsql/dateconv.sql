host perl -e 'print scalar localtime(&timestamp),"\n";'
