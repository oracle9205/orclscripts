column Ctabname format a15 heading 'Table Name' trunc 
column Cname    format a15 heading 'Constraint Name' trunc 
column Ctype    format a1
column Cdecode  format a15 heading 'Type' trunc 
column On_Col   format a15 heading 'On column' trunc 
column Cstatus  format a4  heading 'Status' trunc 
break on Ctabname 
 
select UC1.Table_Name Ctabname,  
       UC1.Constraint_Name Cname, 
       UCC1.Column_Name On_Col, 
       DECODE(Constraint_Type,'C','Check', 
                              'P','Prim Key', 
                              'U','Unique', 
                              'R','Foreign Key', 
                              'V','With Chck Opt') Cdecode, 
       Status Cstatus 
  from dba_CONSTRAINTS UC1, dba_CONS_COLUMNS UCC1 
 where UC1.Constraint_Name = UCC1.Constraint_Name(+) 
   and UC1.Owner = UCC1.Owner 
   and uc1.table_name = upper('&table_name')
 order by UC1.Table_Name ; 

