column envent format a35
select * from v$session_event where sid in (&sidlist)
	and time_waited > 0
	order by time_waited desc
/
