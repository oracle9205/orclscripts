column name format a45
column destination format a30
select status,binding,reopen_secs,fail_sequence,destination from v$archive_dest
/

select sequence#,name,blocks,creator,registrar,to_char(completion_time,'HH24:MI:SS')
from v$archived_log
where completion_time > sysdate-2/24
/
