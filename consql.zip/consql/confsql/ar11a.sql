rem 
delete plan_table;
explain plan for 
SELECT account_number
FROM
(
SELECT a.account_number 
FROM wuser a, wuser_alias b
WHERE a.first_name_upper = :f_name 
   AND a.last_name_upper = :l_name 
   AND a.account_number = b.account_number
   AND b.alias_upper LIKE :email_upper
)
WHERE ROWNUM <= :max_res
/
@plan
rollback ;
