
select s.sql_address sqladdr,
    count(*) count
 from v$session_wait w,
      v$session         s
    where  s.sid = w.sid
    and s.status='ACTIVE'
    and  w.event in ('latch free')
group by s.sql_address
having count(*) > 10
order by count(*) asc
/

select count(*) 
 from v$session_wait w,
      v$session         s
    where  s.sid = w.sid
    and s.status='ACTIVE'
    and  w.event in ('latch free')
/
