REM Ash report about active session count per every 10 seconds for a given time range.
REM All time metrics are in seconds except where mentioned explicitly
REM Sai => 06/14/11

set lines 199
set pages 40
set ver off
alter session set nls_date_format = 'MM/DD HH24:MI:SS';

col cnt for 9999999
col max_time for 99999
col uio_ms for 99999
col sio_ms for 99999
col ccry for 99999
col cmt for 99999
col clst for 99999
col netw for 99999
col app for 99999
col othr for 99999

select
 stime, top_sql, cnt, total_time, max_time, uio_ms, sio_ms,
 ccry, cfg, cmt, clst, netw, app, othr
from
(
select
 stime,
 first_value(sql_id ) over (partition by (case when sql_id is not null then stime end) order by cnt desc) top_sql,
 row_number() over (partition by (case when sql_id is not null then stime end) order by cnt desc) rn,
 sum(cnt) over (partition by stime) cnt,
 sum(total_time) over(partition by stime) total_time,
 max(max_time) over(partition by stime) max_time,
 round(avg(uio_ms) over(partition by stime)) uio_ms,
 round(avg(sio_ms) over ()) sio_ms,
 sum(ccry) over(partition by stime) ccry,
 sum(cfg) over(partition by stime) cfg,
 sum(cmt) over(partition by stime) cmt,
 sum(clst) over(partition by stime) clst,
 sum(netw) over(partition by stime) netw,
 sum(app) over(partition by stime) app,
 sum(othr) over (partition by stime) othr
from
(
select 
 to_date(to_char(sample_time, 'MM/DD')||' '||to_char(sample_time, 'HH24')||':'||
 to_char(sample_time, 'MI')||':'||
 ltrim(to_char((trunc(to_number(to_char(sample_time, 'SS'))/10)*10),'09')), 'MM/DD HH24:MI:SS') as stime,
 sql_id,
 count(*) as cnt,
 round(sum(time_waited)/1000000) as total_time,
 round(max(time_waited)/1000000) as max_time,
 nvl(round(avg(decode(wait_class, 'User I/O', time_waited))/1000),0) uio_ms,
 nvl(round(avg(decode(wait_class, 'System I/O', time_waited))/1000),0) sio_ms,
 nvl(round(sum(decode(wait_class, 'Concurrency', time_waited))/1000000),0) ccry,
 nvl(round(sum(decode(wait_class, 'Configuration', time_waited))/1000000),0) cfg,
 nvl(round(sum(decode(wait_class, 'Commit', time_waited))/1000000),0) cmt,
 nvl(round(sum(decode(wait_class, 'Cluster', time_waited))/1000000),0) clst,
 nvl(round(sum(decode(wait_class, 'Network', time_waited))/1000000),0) netw,
 nvl(round(sum(decode(wait_class, 'Application', time_waited))/1000000),0) app,
 nvl(round(sum(decode(wait_class, 'Other', time_waited))/1000000),0) othr
from &&ash_table
where
sample_time between
 to_date(to_char(&&sysdate_value, 'MM/DD')||' '||('&&HH24_MI_SS_1'), 'MM/DD HH24_MI_SS')
 and
 to_date(to_char(&&sysdate_value, 'MM/DD')||' '||('&&HH24_MI_SS_2'), 'MM/DD HH24_MI_SS')
group by
 to_date(to_char(sample_time, 'MM/DD')||' '||to_char(sample_time, 'HH24')||':'||
 to_char(sample_time, 'MI')||':'||
 ltrim(to_char((trunc(to_number(to_char(sample_time, 'SS'))/10)*10),'09')), 'MM/DD HH24:MI:SS'),
 sql_id
))
where rn=1 and top_sql is not null
order by stime
/
