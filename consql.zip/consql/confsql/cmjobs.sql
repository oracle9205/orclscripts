column concurrent_program_name format a20
column user_concurrent_program_name format a55
column phase_code format a10
column status_code format a10

select
    fcr.actual_start_date,
	fcp.concurrent_program_name,
    fcp.user_concurrent_program_name,
    fcr.phase_code,
    fcr.status_code
      from
            apps.fnd_concurrent_programs fcp,
            apps.fnd_concurrent_requests fcr
      where
            fcp.concurrent_program_id = fcr.concurrent_program_id
     and
    fcp.application_id = fcr.program_application_id
     and
    fcr.phase_code= 'R'
/
