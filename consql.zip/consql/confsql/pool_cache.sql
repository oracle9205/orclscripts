select name, sharable_mem, kept, type
     from v$db_object_cache
    where sharable_mem > 10000
     and (type = 'PACKAGE' or type = 'PACKAGE BODY' or type = 'FUNCTION'
          or type = 'PROCEDURE')
     and kept = 'NO'
     order by 2 asc
/
