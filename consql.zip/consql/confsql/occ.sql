
host netstat -an | grep 1234 | wc
