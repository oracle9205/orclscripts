select 'alter system kill session '||''''||s.sid||','||serial#||''''||';'
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where  s.sid = w.sid and io.sid=w.sid and
	s.status='ACTIVE'
	and  w.event = 'enqueue'
        and username is not NULL
/
