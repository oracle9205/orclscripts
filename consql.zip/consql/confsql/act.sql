@mydate
alter session set current_schema=ppdba;
col pypl_date format a20
col ACT format a10
select pypl_date, act from
(select
to_date(substr(info1,1,14),'MM-DD HH24:MI:SS') pypl_date,
substr(info1, instr(info1, ' ', 1, 18)+1, (instr(info1, ' ', 1, 19)-instr(info1, ' ', 1, 18)-1)) act
from
(select regexp_replace(date1, ' +', ' ') info1 from
(select * from pypl_freecon where substr(date1, 1, 5) in (
select to_char((sysdate-&num_days_back + rownum),'MM-DD') from all_objects where rownum<=5)) ) 
where rownum < 9000*(&num_days_back)) where act > &act_threshold order by 1
/
