select index_name,column_name,column_position
from user_ind_columns
where table_name=upper('&table_name')
/
