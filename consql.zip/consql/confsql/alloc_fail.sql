insert into failed_allocs select sysdate,x.* from x$ksmlru x;

select * from failed_allocs;
