select substr(sql_text,1,60),count(*),sum(parse_calls) parses, sum(sharable_mem) shareable,sum(persistent_mem) persisten,sum(runtime_mem) runtime,min(first_load_time) from sqlsnap group by substr(sql_text,1,60) having count(*) > 100
/
