set serveroutput on 

declare
cursor partitions is select partition_name,partition_position,high_value
	from dba_tab_partitions where table_name = 'WTRANSACTION' order by partition_position asc;
-- partitions%rowtype prec;
id        number;
timestamp number;
position  number;
val	  number;
valtmp	  varchar2(100);
prev_val  number;
begin

        prev_val := -1;
	dbms_output.put_line('date               pos  id            maxval    part. name');
	for prec in partitions
	loop
		valtmp:=prec.high_value;
		if (upper(valtmp) <> 'MAXVALUE')
		then
			val:=to_number(valtmp);
			begin
			    select time_created,id into timestamp,id from
				(select time_created,id from wtransaction where id<val and id>=prev_val and id=base_id order by id desc)
	 				where rownum=1;
			    dbms_output.put(to_char(u2sql(timestamp),'YYYY/MM/DD HH24:MI'||'   '));
			    dbms_output.put_line(to_char(prec.partition_position)||'  '||to_char(id)||'  '||
					to_char(val)||'  '||prec.partition_name);
			exception when no_data_found then
			    dbms_output.put('-- empty ---       ');
			    dbms_output.put_line(to_char(prec.partition_position)||'              '||
						to_char(val)||'  '||prec.partition_name);

			end;
			prev_val:=val;
		end if;
	end loop;
end;
/
