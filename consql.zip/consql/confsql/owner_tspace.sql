select d.object_name, d.object_type, d.owner, s.tablespace_name, s.bytes, to_char(d.created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects d, dba_segments s
where
d.object_name=s.segment_name
and s.tablespace_name=upper('&tspace_name')
and d.owner in ('CRYSTAL')
and d.object_name like 'TMP_%'
and d.object_name not in 'TMP_SUBPRIME'
order by d.created, d.owner, d.object_type
/
