alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
col ind noprint
col dc_machine form a20
select 1 ind,module,inst_id,machine DC_machine, count(*), max(logon_time) from gv$session where machine like '%occ%'
and lower(substr(machine,1,3)||regexp_replace(upper(regexp_replace(machine,'.*(.)$','\1')),'[0-9]',''))=lower('&DC')
group by machine, inst_id, module
union
select 2 ind,module, inst_id, DC DC_machine, count(*), max(logon_time) from
(select module,inst_id,lower(substr(machine,1,3)||regexp_replace(upper(regexp_replace(machine,'.*(.)$','\1')),'[0-9]','')) DC,
logon_time
from gv$session where machine like '%occ%')
group by DC, inst_id, module
order by ind,5 desc,2,1,3
/
