select owner,segment_name,segment_type,extents,bytes,initial_extent, next_extent, pct_increase from dba_segments where segment_name like
upper('&segname')
/
