REM Script to report waits summary by time waited and number of waits since last db restart.
REM Sai => 11/25/2008

set trimspool on
col wait_class for a50

select
 a.wait_class||': '||substr(b.event, 1, 25)||' ('||b.pct_wait||'%)' as wait_class,
 round((a.time_waited/(sum(a.time_waited) over ()))*100,1) as wait_time_pct,
 round((a.time_waited*10)/a.total_waits,1) as avg_wait_time_ms,
 round((a.total_waits/(sum(a.total_waits) over ()))*100,1) as total_waits_pct,
 a.total_waits as total_waits
from v$system_wait_class a,
     (select
       wait_class#, event, pct_wait
      from
       (select
         wait_class#, event,
         round((TIME_WAITED_MICRO/(sum(TIME_WAITED_MICRO) over (partition by wait_class#)))*100,1) pct_wait,
         row_number() over (partition by wait_class# order by TIME_WAITED_MICRO desc) rn
        from v$system_event
       )
      where rn=1
     ) b
where
a.wait_class not in ('Idle') and
a.wait_class# = b.wait_class#
order by wait_time_pct desc, total_waits_pct
/
