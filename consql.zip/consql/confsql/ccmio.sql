
select s.sid,substr(module,instr(module,'/',-1)+1) module,i.block_gets,i.consistent_gets,
	i.physical_reads,i.block_changes,i.consistent_changes from v$sess_io i,
	v$session s where 
	i.sid=s.sid 
	and s.machine like 'spccm%' 
/
