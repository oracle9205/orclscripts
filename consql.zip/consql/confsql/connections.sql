select
substr(machine,1,instr(machine,'.')-1) machine, count(*),
		to_char(max(logon_time),'MM/DD HH24:MI')  earliest_connection,
		to_char(min(logon_time),'MM/DD HH24:MI') latest_connection,
		(max(logon_time)-min(logon_time))/24 delta_hours
from v$session 
group by substr(machine,1,instr(machine,'.')-1)
/

