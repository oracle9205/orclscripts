column concurrent_program_name format a20
column user_concurrent_program_name format a55
column phase_code format a10
column status_code format a10

select
    to_char(fcr.requested_start_date,'MM/DD HH24:MI') "Req. Start",
    to_char(fcr.actual_start_date,'MM/DD HH24:MI') "Actual Start",
    to_char(fcr.actual_completion_date,'MM/DD HH24:MI') "Actual finish",
    (fcr.actual_completion_date-fcr.actual_start_date)*24*3600 delta,
    fcr.phase_code,
    fcr.status_code
      from
            apps.fnd_concurrent_programs fcp,
            apps.fnd_concurrent_requests fcr
      where
            fcp.concurrent_program_id = fcr.concurrent_program_id
     and
    fcp.application_id = fcr.program_application_id
     and
    fcp.user_concurrent_program_name='NetFlix Order Import'
and fcr.requested_start_date > trunc(sysdate)
order by fcr.requested_start_date
/
