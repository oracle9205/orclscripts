REM Script to report objects from dba_objects by a given object_name
REM Sai => 12/13/2011

select * from
 (select owner, object_name, created from dba_objects where object_name like upper('&obj_name') order by created desc)
where rownum <= 25
/
