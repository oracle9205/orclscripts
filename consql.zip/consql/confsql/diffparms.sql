select p.name, p.value , c.value
from parms_prev p, v$parameter c
where p.name = c.name and p.value != c.value
/
