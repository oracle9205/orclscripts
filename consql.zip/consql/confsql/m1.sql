select KGLNAOWN, KGLNAOBJ from x$kglob where kglnahsh='&p1'
/
