select machine,s.sid,sql_hash_value sql_hash_value,w.event,module,io.block_gets+io.consistent_gets gets,
                    seconds_in_wait sec,
        decode(w.event,'db file sequential read' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'direct path write' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'direct path read' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'free buffer waits' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'db file scattered read' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'buffer busy waits' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'write complete waits' ,new_waitinfo.segbyblock(w.p1,w.p2),
                        'enqueue' ,new_waitinfo.segbyblock(s.row_wait_file#,s.row_wait_block#),
                        'latch free',new_waitinfo.latchbynum(w.p2)||': tries='||to_char(w.p3),
                        'latch activity',new_waitinfo.latchbynum(w.p2),
                         decode(w.p1text,'','',w.p1text||':'||to_char(w.p1)) ||
                         decode(w.p2text,'','',','||w.p2text||':'||to_char(w.p2)))  info
from v$session_wait w,
     v$sess_io     io,
     v$session      s
        where  s.sid = w.sid and io.sid=w.sid and
        s.status='ACTIVE'
	and module like '%BATCH%'
        and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
        order by event,info
/
