select spid
from v$process p,v$session s
where s.paddr=p.addr
and s.sid in (
select blocking_session from v$session where event in (
'cursor: pin S wait on X',
'cursor: pin S',
'cursor: pin X',
'cursor: mutex S' ,
'cursor: mutex X',
'library cache: mutex X'));
