accept suffix prompt 'table suffix: '
create table latch_&suffix storage (initial 128k next 128k maxextents 50) as select * from v$latch
/
