select distinct(s.sql_address sqladdr),w.event
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where s.sid = w.sid
	and io.sid=w.sid
	and s.status = 'ACTIVE'
	order by event,info
/
