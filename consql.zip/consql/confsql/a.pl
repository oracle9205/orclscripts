for $i qw(
ash_sum_10sec.sql
ash_sum_1sec.sql   
ash_sum_awr.sql    
ashbyclass.sql           
ashbyevent.sql        
blockers2.sql             
eventbyclass.sql      
h2i.sql                          
i2h.sql                          
lw.sql                            
lwbyclass.sql             
lwbyevent.sql          
lwg.sql                         
objbytime.sql           
) {

system("scp -p /goldengate/software/11g_scripts/utils_sql/$i phxppdb303:/x/home/oracle/utils/sql/ ");
}
