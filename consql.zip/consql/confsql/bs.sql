select segment_name, sum(bytes)/(1024*1024*1024) from dba_segments group by segment_name order by 2 desc
