select index_name,partition_name,status from dba_ind_partitions
where index_name like 'WTRANSACTION_%' and partition_name not like 'WTA%';

