REM Sai => 09/30/09 Written for PPDBA repository live objects.

set ver off
set lines 199
col dbname for a8
col owner format a10
col object_type format a11
col part_keys  for a30
col subpart_keys  for a30
undef object_name

select
e.dbname, b.owner, b.object_type, 
b.columns part_keys, d.columns subpart_keys
from
  (select /*+ index(a, PYPL_PART_KEY_COLUMNS_IDX1) */ 
  dbid, owner, object_type, name, 
  max(decode(column_position, 1, column_name))||
  max(decode(column_position, 2, ', '||column_name))||
  max(decode(column_position, 3, ', '||column_name))||
  max(decode(column_position, 4, ', '||column_name))||
  max(decode(column_position, 5, ', '||column_name)) columns
  from pypl_part_key_columns a
  where name = upper('&&object_name')
  group by dbid, owner, object_type, name) b,
  (select /*+ index(c, PYPL_SUBPART_KEY_COLUMNS_IDX1) */ 
  dbid, owner, object_type, name, 
  max(decode(column_position, 1, column_name))||
  max(decode(column_position, 2, ', '||column_name))||
  max(decode(column_position, 3, ', '||column_name))||
  max(decode(column_position, 4, ', '||column_name))||
  max(decode(column_position, 5, ', '||column_name)) columns
  from pypl_subpart_key_columns c
  where name = upper('&&object_name')
  group by dbid, owner, object_type, name) d,
  pypl_databases e
where
b.dbid = d.dbid(+) and
b.dbid = e.dbid
/
