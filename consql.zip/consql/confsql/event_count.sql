select w.event, count(*) from v$session_wait w, v$session s where s.sid=w.sid and s.status='ACTIVE' group by w.event order by count(*)
/
