create table filestat_&suffix nologging storage (initial 200k) as select * from v$filestat
/
