CREATE OR REPLACE PACKAGE                                                                                                                                                           
CONFDBA.bitwise                                                                                                                                                                     
AS                                                                                                                                                                                  
   --                                                                                                                                                                               
   -- returns the bitand of the of two integers. For example suppose you want                                                                                                       
   -- to bitand the following bit patterns:                                                                                                                                         
   --     1100        "12"                                                                                                                                                          
   --     1010        "10"                                                                                                                                                          
   --   ==========   bitand                                                                                                                                                         
   --     1000        "8"                                                                                                                                                           
   -- Thus bitand(12,10) returns 8!                                                                                                                                                 
   --                                                                                                                                                                               
   FUNCTION bitand (left IN BINARY_INTEGER, right IN BINARY_INTEGER)                                                                                                                
   RETURN BINARY_INTEGER;                                                                                                                                                           
   PRAGMA RESTRICT_REFERENCES(bitand,WNDS,RNDS,WNPS,RNPS);                                                                                                                          
                                                                                                                                                                                    
   --                                                                                                                                                                               
   -- First of all, try to avoid using this function. It is about 5x                                                                                                                
   -- slower than bitand and bitnot!!                                                                                                                                               
   --                                                                                                                                                                               
   -- Bitor returns the bitwise OR of two integers. Forexample, suppose                                                                                                             
   -- You want to bitor the following bit patters:                                                                                                                                  
   --     1100        "12"                                                                                                                                                          
   --     1010        "10"                                                                                                                                                          
   --   ==========    bitor                                                                                                                                                         
   --     1110        "14"                                                                                                                                                          
   --                                                                                                                                                                               
   FUNCTION bitor (left IN BINARY_INTEGER, right IN BINARY_INTEGER)                                                                                                                 
   RETURN BINARY_INTEGER;                                                                                                                                                           
   PRAGMA RESTRICT_REFERENCES(bitor,WNDS,RNDS,WNPS,RNPS);                                                                                                                           
                                                                                                                                                                                    
   --                                                                                                                                                                               
   -- First of all, try to avoid using this function. It is about 5x                                                                                                                
   -- slower than bitand and bitnot!!                                                                                                                                               
   --                                                                                                                                                                               
   -- Bitxor returns the bitwise EXCLUSIVE OR of two integers. For example,                                                                                                         
   -- suppose you want to bitor the following bit patters:                                                                                                                          
   --     1100        "12"                                                                                                                                                          
   --     1010        "10"                                                                                                                                                          
   --   ==========    bitxor                                                                                                                                                        
   --     0110        "6"                                                                                                                                                           
   --                                                                                                                                                                               
   FUNCTION bitxor (left IN BINARY_INTEGER, right IN BINARY_INTEGER)                                                                                                                
   RETURN BINARY_INTEGER;                                                                                                                                                           
   PRAGMA RESTRICT_REFERENCES(bitxor,WNDS,RNDS,WNPS,RNPS);                                                                                                                          
                                                                                                                                                                                    
   --                                                                                                                                                                               
   -- returns the bitnot of the of an "unsigned" integer. This function will                                                                                                        
   -- determine the number of bytes to compare with itself. For example suppose                                                                                                     
   -- you specify bitnot(5). "5" fits in 3 bits and there it will compare it                                                                                                        
   -- with only 8 bits (one byte). So bitnot(5) returns:                                                                                                                            
   --   **** **** **** **** **** **** **** ****    32 bits                                                                                                                          
   --                                       101        "5"                                                                                                                          
   --   =========================================    bitnot                                                                                                                         
   --   1111 1111 1111 1111 1111 1111 1111 1010      2147483642                                                                                                                     
   FUNCTION bitnot (operator IN BINARY_INTEGER)                                                                                                                                     
   RETURN BINARY_INTEGER;                                                                                                                                                           
   PRAGMA RESTRICT_REFERENCES(bitnot,WNDS,RNDS,WNPS,RNPS);                                                                                                                          
                                                                                                                                                                                    
END bitwise;                                                                                                                                                                        
/                                                                                                                                                                                   
CREATE OR REPLACE PACKAGE BODY                                                                                                                                                      
CONFDBA.bitwise                                                                                                                                                                     
AS                                                                                                                                                                                  
   --                                                                                                                                                                               
   -- this implementation uses the available, but not supported, built-in                                                                                                           
   -- BITAND function!                                                                                                                                                              
   --                                                                                                                                                                               
   FUNCTION bitand (left IN BINARY_INTEGER, right IN BINARY_INTEGER)                                                                                                                
   RETURN BINARY_INTEGER                                                                                                                                                            
   IS                                                                                                                                                                               
   BEGIN                                                                                                                                                                            
     return standard.bitand(left,right);                                                                                                                                            
   END;                                                                                                                                                                             
                                                                                                                                                                                    
    -- Likewise, this function, which returns the bitwise disjunction of                                                                                                            
    -- its binary_integer arguments.  Note that bitand(x, y) is an                                                                                                                  
    -- undocumented built-in function.  Function due to De Morgan                                                                                                                   
    FUNCTION bitor(left IN BINARY_INTEGER,                                                                                                                                          
                   right IN BINARY_INTEGER)                                                                                                                                         
    RETURN BINARY_INTEGER IS                                                                                                                                                        
    BEGIN                                                                                                                                                                           
      RETURN(bitnot(bitand(bitnot(left), bitnot(right))));                                                                                                                          
    END;                                                                                                                                                                            
                                                                                                                                                                                    
    FUNCTION bitxor(left IN BINARY_INTEGER,                                                                                                                                         
                    right IN BINARY_INTEGER)                                                                                                                                        
    RETURN BINARY_INTEGER IS                                                                                                                                                        
    BEGIN                                                                                                                                                                           
      RETURN(bitand(bitor(left, right), bitnot(bitand(left, right))));                                                                                                              
    END;                                                                                                                                                                            
                                                                                                                                                                                    
   --                                                                                                                                                                               
   -- This function takes a binary_integer (a 32-bit 2s complement datatype)                                                                                                        
   -- and returns the bitwise negation of its value                                                                                                                                 
   -- Assumes BINARY_INTEGER is 32-bit integer (valid for Oracle7)                                                                                                                  
   --                                                                                                                                                                               
   FUNCTION bitnot(operator IN BINARY_INTEGER)                                                                                                                                      
   RETURN BINARY_INTEGER IS                                                                                                                                                         
   BEGIN                                                                                                                                                                            
     IF operator >= 0 THEN                                                                                                                                                          
          RETURN(2147483647 - operator);                                                                                                                                            
     ELSE                                                                                                                                                                           
          RETURN(-1 - operator);                                                                                                                                                    
     END IF;                                                                                                                                                                        
   END;                                                                                                                                                                             
                                                                                                                                                                                    
END bitwise;                                                                                                                                                                        
/                                                                                                                                                                                   
