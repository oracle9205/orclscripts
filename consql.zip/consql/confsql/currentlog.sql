select group#, thread#, sequence#, bytes/(1024*1024) "Size", status, archived, used,
   round((first_time - lag(first_time) over (order by sequence#))*24*60,0) switch_freq,
   --to_char(first_time,'DD-MON-YYYY HH24:MI:SS') time_of_change,
   case when used is not null
   then round((sysdate - first_time)*24*60,0)
   end  min_since_last_switch
from v$log a,
(select  le.leseq  log_sequence#,
	       substr(to_char(100 * cp.cpodr_bno / le.lesiz, '999.00'), 2) || '%'  used
from    sys.x$kcccp  cp,
	       sys.x$kccle  le
where
       le.inst_id = userenv('Instance') and
       cp.inst_id = userenv('Instance') and
       le.leseq = cp.cpodr_seq
and le.leseq > 0) b
where a.sequence# = b.log_sequence# (+)
and a.status = 'CURRENT'
;
