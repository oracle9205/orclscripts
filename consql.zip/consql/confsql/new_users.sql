Accept username prompt 'New Username :'

-- Create the New User with 5G quota
create user &username identified by &Password default tablespace users temporary tablespace user_temp_lm quota 5000M on users ;


-- Grant the new_dw_user role to the user 

grant new_dw_user to &username ;

-- Grant the Select_dw to the user

grant select_dw to &username ;


