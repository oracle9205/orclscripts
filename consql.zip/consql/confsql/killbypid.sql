select '!kill -9 '||spid
from v$process a, v$session b
where b.paddr = a.addr
and b.sid in &sid
/
