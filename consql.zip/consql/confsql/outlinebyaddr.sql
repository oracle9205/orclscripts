column version format a10
column hint_text format a10
column ol_name   format a10
column category  format a10
set verify off
accept address prompt 'address: '

select * from outln.ol$ where hash_value = (select hash_value from v$sqlarea where address=hextoraw('&address'))
/
select * from outln.ol$hints where ol_name = (select ol_name from outln.ol$ where hash_value=(select hash_value from v$sqlarea where address=hextoraw('&address')))
/
