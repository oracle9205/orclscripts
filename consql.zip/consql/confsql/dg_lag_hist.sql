REM Script to report stats of dataguard from v$dataguard_stats
REM Sai => 12/13/2011

set lines 199
col name for a40
col unit for a15

select * from v$standby_event_histogram;
/
