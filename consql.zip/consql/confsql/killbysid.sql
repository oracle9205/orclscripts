column kil format a90
select 'alter system kill session '''||to_char(a.sid)||','||to_char(a.serial#)||''';' kil
        from v$session a
	where a.sid in (&sidlist)
        order by a.sid
/
