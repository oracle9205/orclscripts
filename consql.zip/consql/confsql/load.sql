
host uptime

