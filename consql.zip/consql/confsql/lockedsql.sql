REM  lock_sql.sql
REM  Show SQL text associated with locked sessions
REM
column username format  A15 
column sid      format  9990    heading SID 
column type     format  A4 
column lmode    format  990     heading HELD 
column request  format  990     heading REQ
column id1      format  9999990 
column id2      format  9999990 
break on Sid 
select SN.Username, 
       M.Sid, 
       SN.Serial#, 
       M.Type,
       DECODE(M.Lmode, 0, 'None', 
                       1, 'Null', 
                       2, 'Row Share', 
                       3, 'Row Excl.', 
                       4, 'Share', 
                       5, 'S/Row Excl.', 
                       6, 'Exclusive', 
                Lmode, LTRIM(TO_CHAR(Lmode,'990'))) Lmode, 
       DECODE(M.Request, 0, 'None', 
                         1, 'Null', 
                         2, 'Row Share', 
                         3, 'Row Excl.', 
                         4, 'Share', 
                         5, 'S/Row Excl.', 
                         6, 'Exclusive', 
                Request, LTRIM(TO_CHAR(M.Request, 
                                '990'))) Request, 
        M.Id1, 
        M.Id2, 
        T.Sql_Text sql
  from V$SESSION SN, V$LOCK M , V$SQLTEXT T
 where T.Address = SN.Sql_Address 
   and T.Hash_Value = SN.Sql_Hash_Value 
   and ( (SN.Sid = M.Sid 
          and M.Request != 0) 
    or (SN.Sid = M.Sid 
          and M.Request = 0 and Lmode != 4 
          and (id1, id2) in
           (select S.Id1, S.Id2 
              from V$LOCK S 
             where Request != 0 
               and S.Id1 = M.Id1 
               and S.Id2 = M.Id2)  ) )
order by SN.Username, SN.Sid, T.Piece;

clear breaks 
clear columns
