rem
rem collect index stats for the current schema using 
rem 'alter index validate structure'
rem
set serveroutput on size 100000
declare
	cursor index_cursor is select index_name from user_indexes;
	cursor stats_cursor is select * from index_stats;
	irec index_cursor%ROWTYPE;
	srec stats_cursor%ROWTYPE;
	handle number;
begin

	dbms_output.put(rpad('index name',30));
	dbms_output.put(lpad('height',10));
	dbms_output.put(lpad('del. rows',10));
	dbms_output.put(lpad('del. len',10));
	dbms_output.put(lpad('rows/key',10));
	dbms_output.put(lpad('blk/access',10));
	dbms_output.put(lpad('distinct',10));
	dbms_output.put(lpad('pct_used',10));
	dbms_output.put(lpad('lf_rows',10));
	dbms_output.put(lpad('lf_blocks',10));

	dbms_output.put_line('');

	for  irec in index_cursor
	loop
		handle := dbms_sql.open_cursor;
		dbms_sql.parse(handle,'analyze index '||irec.index_name||' validate structure',dbms_sql.native);
		dbms_sql.close_cursor(handle);
		for srec in stats_cursor
		loop
			dbms_output.put(rpad(srec.name,30));
			dbms_output.put( lpad(to_char(srec.height),10) );

			dbms_output.put(lpad(to_char(srec.del_lf_rows),10));
			dbms_output.put(lpad(to_char(srec.del_lf_rows_len),10));
			dbms_output.put(lpad(to_char(round(srec.rows_per_key)),10));
			dbms_output.put(lpad(to_char(round(srec.blks_gets_per_access)),10));
			dbms_output.put(lpad(to_char(srec.distinct_keys),10));
			dbms_output.put(lpad(to_char(srec.pct_used),10));
			dbms_output.put(lpad(to_char(srec.lf_rows),10));
			dbms_output.put(lpad(to_char(srec.lf_blks),10));


			dbms_output.put_line('');
		end loop;
	end loop;
end;
/
