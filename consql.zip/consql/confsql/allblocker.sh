#!/bin/sh
#create the spool file
TMPFILE=/tmp/all_blocker.sql
> /tmp/all_blocker.lst
> $TMPFILE
sqlplus -s '/ as sysdba' <<EOF
set head off
set pagesize 0
set feedback off
spool /tmp/all_blocker.lst

select spid
from v\$process p,v\$session s
where s.paddr=p.addr
and s.sid in (
SELECT BLOCKER_SID from  v\$wait_chains
where IN_WAIT_SECS > 5
);
spool off;
EOF
echo "sqlplus '/ as sysdba' <<EOF"    >> $TMPFILE
for i in `cat /tmp/all_blocker.lst`
do
echo "oradebug setospid $i;"          >> $TMPFILE
echo "oradebug unlimit;"              >> $TMPFILE
echo "oradebug dump errorstack 10;"   >> $TMPFILE
echo "oradebug tracefile_name;"       >> $TMPFILE
done
echo "EOF"                            >> $TMPFILE
chmod 755 $TMPFILE
echo "Collecting errorstack for FIRST time and running the script $TMPFILE"
$TMPFILE
