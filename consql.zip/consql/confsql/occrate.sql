select to_char(logon_time,'DD HH24:MI') time,count(*) from v$session group by to_char(logon_time,'DD HH24:MI')
order by time
/
