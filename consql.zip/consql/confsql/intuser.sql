rem
rem do a ps like display of oracle processes
rem

column ser# format 99999 
select  substr(a.username,1,8) USERNAME, substr(a.osuser,1,8) OSUSER,
	substr(b.spid,1,6) SRVPID, substr(to_char(a.sid),1,3) SID,
	a.serial# ser#, io.block_gets+io.consistent_gets reads,
	substr(a.module,1,12) Module,
	substr(a.status,1,1) stat, substr(a.program,1,25) PROGRAM
	from v$process b, v$session a, v$sess_io io
	where a.sid=io.sid and
	a.paddr = b.addr
	and (a.username like 'INT_' or a.username like '%OLTP%')
	order by a.username,a.sid
/


