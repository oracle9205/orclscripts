select segment_name,bytes  from dba_segments where tablespace_name='SCRUB' and owner='FACT' and (segment_name like 'WT%' or segment_name like 'WCC%' or segment_name like 'WLE%' or segment_name like 'PV%') order by segment_name
/
