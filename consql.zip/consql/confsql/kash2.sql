alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';

column sample_time format a35

select SAMPLE_TIME, event, count(*), round(max(time_waited)/1000,0) max_time from v$active_session_history where sample_time>to_timestamp(sysdate-(&min*(1/1440)), 'DD-MON-YYYY HH24:MI:SS') group by SAMPLE_TIME, event order by 1,3;

