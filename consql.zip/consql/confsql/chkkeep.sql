SELECT 'KEEP' POOL, o.name, COUNT(buf#) BLOCKS 
FROM obj$ o, x$bh x 
WHERE o.dataobj# = x.obj 
AND x.state != 0 
AND o.owner# != 0 
AND buf# >= (SELECT lo_bnum 
FROM v$buffer_pool 
WHERE name = 'KEEP' 
AND buffers > 0) 
AND buf# <= (SELECT hi_bnum 
FROM v$buffer_pool 
WHERE name = 'KEEP' 
AND buffers > 0) 
GROUP BY 'KEEP', o.name 
UNION ALL 
SELECT 'DEFAULT' POOL, o.name, COUNT(buf#) BLOCKS 
FROM obj$ o, x$bh x 
WHERE o.dataobj# = x.obj 
AND x.state != 0 
AND o.owner# != 0 
AND buf# >= (SELECT lo_bnum 
FROM v$buffer_pool 
WHERE name = 'DEFAULT' 
AND buffers > 0) 
AND buf# <= (SELECT hi_bnum 
FROM v$buffer_pool 
WHERE name = 'DEFAULT' 
AND buffers > 0) 
GROUP BY 'DEFAULT', o.name 
UNION ALL 
SELECT 'RECYCLE' POOL, o.name, COUNT(buf#) BLOCKS 
FROM obj$ o, x$bh x 
WHERE o.dataobj# = x.obj 
AND x.state != 0 
AND o.owner# != 0 
AND buf# >= (SELECT lo_bnum 
FROM v$buffer_pool 
WHERE name = 'RECYCLE' 
AND buffers > 0) 
AND buf# <= (SELECT hi_bnum 
FROM v$buffer_pool 
WHERE name = 'RECYCLE' 
AND buffers > 0) 
GROUP BY 'RECYCLE', o.name; 
