column sid format 9999
column seq# format 9999
column event format a30
column info format a45
column p1text format a15
column p2text format a15
column p2 format 99999999
column p3 format 99999999
column wait format a5
column module format a12
column action format a12
column wait format a8
select s.sid,substr(s.module,1,12) module,w.event,
        decode(w.state,'WAITING','WAIT'
                    ,'WAITED KNOWN TIME',to_char(w.wait_time/100)
                    ,'WAITED SHORT TIME','SHORT'
                    ,'WAITED UNKNOWN TIME','UNKNOWN'
                    ,w.state) wait,
        decode(w.p1text,'file#',waitinfo.segbyblock(w.p1,w.p2),w.p1text||' '||to_char(w.p1),w.p1text) info
from v$session_wait w,
     v$session      s
        where s.sid = w.sid
        and s.status != 'INACTIVE'
        order by s.sid
/

