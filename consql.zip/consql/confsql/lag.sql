@mydate


select checkpoint_time from v$datafile where file#=1;
