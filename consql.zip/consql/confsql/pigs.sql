column executins vg_hformat 999,999,999
column avg_gets format 9,999,999.99
column avg_disk_reads format 9,999,999.99
column hit_ratio format 9.99
select address,executions,buffer_gets,
	(buffer_gets-disk_reads)/(buffer_gets+1) hit_ratio, 
	buffer_gets /decode(executions,0,1,executions) avg_gets, 
	disk_reads  /decode(executions,0,1,executions) avg_disk_reads, 
	substr(sql_text ,1,40)
	from sqlarea_prev 
where executions > 1000000
order by buffer_gets asc
/
