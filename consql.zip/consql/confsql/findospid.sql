select p.spid, s.machine, s.sid, sysdate-s.logon_time
from
        v$session s,
        v$process p
where
        s.machine='&machine'
        and p.addr=s.paddr
order by 4 desc;

