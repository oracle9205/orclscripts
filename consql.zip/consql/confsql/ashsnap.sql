col crdate new_value crdate 
select to_char(sysdate,'mmddyyyy_hh24miss')||'_'||instance_number||'_drop'  crdate from v$instance;
create table ops$oracle.ash_&crdate as select * from v$active_session_history;
