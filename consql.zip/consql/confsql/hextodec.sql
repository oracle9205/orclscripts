REM  hextodec.sql
create function HEXTODEC (Hexnum in CHAR) 
   RETURN NUMBER IS  
          X                 NUMBER;  
          Digits            NUMBER; 
          Result            NUMBER := 0; 
          Current_Digit     CHAR(1); 
          Current_Digit_Dec NUMBER; 
begin 
    Digits := LENGTH(Hexnum); 
    for X in 1..Digits loop 
        Current_Digit := UPPER(SUBSTR(Hexnum, X, 1)); 
        if Current_Digit in ('A','B','C','D','E','F') then 
           Current_Digit_Dec := ASCII(Current_Digit) - ASCII('A') + 10; 
        else 
           Current_Digit_Dec := TO_NUMBER(Current_Digit); 
        end if; 
        Result := (Result * 16) + Current_Digit_Dec; 
    end loop; 
return Result; 
end;  
/
