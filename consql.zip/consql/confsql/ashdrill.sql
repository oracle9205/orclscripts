@mydate
set pages 100 trims on head on
col sample_time format a25
col event format a35
col maxtime format a10 
col avgtime format a10 
set linesize 200

select  object_name  ,created  from dba_objects where object_name like 'ASH%' 
and created > sysdate - &daysback_tolookforashtable   and object_type='TABLE' order by created;

ACCEPT ashtable PROMPT 'Please enter ASH table name:'

select min(sample_time), max(sample_time)  from &ashtable;

ACCEPT begin_time PROMPT 'Begin Sample Time e.g. 22-JAN-10 06.50.59.848 AM ------:'
ACCEPT end_time   PROMPT 'End Sample Time e.g. 22-JAN-10 06.55.59.848 PM   ------:' 

break on sample_time skip 1

TTITLE left  'QUEUE REPORT by Event Name' skip 1 - 
left =========================== skip 4 -

select sample_time, event, count(*) 
  from &ashtable
  where sample_time between '&begin_time' and '&end_time'
        group by sample_time,event
        order by  sample_time,count(*)
/

TTITLE left  'QUEUE REPORT by Event Name and Time Waited' skip 1 - 
left =========================================== skip 4 -

select sample_time, event, count(*), round(max(TIME_WAITED)/1000,2)||' ms' maxtime, 
       round(avg(TIME_WAITED)/1000,2)||' ms' avgtime 
   from &ashtable
   where sample_time between '&begin_time' and '&end_time'
       group by sample_time,event 
       order by sample_time
/

undef begin_time
undef end_time
