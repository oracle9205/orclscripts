host ~/utils/parents &pid
