column sid format 9999
column seq# format 9999
column event format a30
column info format a40
column p1text format a15
column p2text format a15
column p2 format 99999999
column p3 format 99999999
column wait format a5
column module format a12
column action format a12

select s.sid,substr(s.module,1,12) module,substr(s.action,1,12) action,w.event,
	decode(w.state,'WAITING','WAIT'
		    ,'WAITED KNOWN TIME',to_char(w.wait_time/100) 
		    ,'WAITED SHORT TIME','SHORT','UNKNOWN') wait,
	decode(w.p1text,'file#',decode(p2text,'block#',intutils.segbyblock(w.p1,w.p2),
					w.p1text||' '||to_char(w.p1)), 
			'name|mode',intutils.enqbynum(p1)||'id1: '||rawtohex(p2)||
					'id2: '||rawtohex(p3),
			decode(w.event, 'latch free',intutils.latchbynum(w.p2),
				w.p1text||' '||to_char(w.p1))||
				w.p2text||to_char(w.p2)
		) info
from v$session_wait w,
     v$session	    s
	where s.sid = w.sid
	and (s.username like '%OLTP%' or s.username like 'INT_')
	order by s.sid
/
