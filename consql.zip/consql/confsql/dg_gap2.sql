REM Script to report status of daaguard redo transport from primary to the standby
REM Sai => 12/13/2011

select * from V$archive_gap;
