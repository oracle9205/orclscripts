accept s1 prompt 'suffix 1: ';
accept s2 prompt 'suffix 2: ';






drop   table diff_tables_&&s1&&s2;
create table diff_tables_&&s1&&s2
as
select 'SNAP1' snapshot, owner, table_name, buffer_pool from
        (select owner, table_name, buffer_pool
                from snap_tables_&&s1
        minus
        select owner, table_name, buffer_pool
                from snap_tables_&&s2)
union all
select 'SNAP2' snapshot, owner, table_name , buffer_pool from
        (select owner, table_name, buffer_pool
                from snap_tables_&&s2
        minus
        select owner, table_name, buffer_pool
                from snap_tables_&&s1)
/

---
---
---



drop   table diff_indexes_&&s1&&s2;
create table diff_indexes_&&s1&&s2
as
select 'SNAP1' snapshot, owner, index_name, table_name, uniqueness, buffer_pool from
        (select owner, index_name, table_name, uniqueness, buffer_pool
                from snap_indexes_&&s1
        minus
        select owner, index_name , table_name, uniqueness, buffer_pool
                from snap_indexes_&&s2)
union all
select 'SNAP2' snapshot, owner, index_name , table_name, uniqueness, buffer_pool from
        (select owner, index_name, table_name, uniqueness, buffer_pool
                from snap_indexes_&&s2
        minus
        select owner, index_name, table_name, uniqueness, buffer_pool
                from snap_indexes_&&s1)
/





drop   table diff_segments_&&s1&&s2;
create table diff_segments_&&s1&&s2
as
select 'SNAP1' snapshot, owner,segment_name,partition_name,segment_type,buffer_pool from
        (select owner,segment_name,partition_name,segment_type,buffer_pool
                from snap_segments_&&s1 
        minus 
        select           owner,segment_name,partition_name,segment_type,buffer_pool
                from snap_segments_&&s2)
union all
select 'SNAP2' snapshot, owner,segment_name,partition_name,segment_type,buffer_pool from
        (select          owner,segment_name,partition_name,segment_type,buffer_pool
                from snap_segments_&&s2
        minus
        select           owner,segment_name,partition_name,segment_type,buffer_pool
                from snap_segments_&&s1)
/




drop   table diff_objects_&&s1&&s2;
create table diff_objects_&&s1&&s2
as
select 'SNAP1' snapshot, owner,object_name,object_type,status  
	from (select     owner,object_name,object_type,status  
                from snap_objects_&&s1 
        minus 
        select           owner,object_name,object_type,status  
                from snap_objects_&&s2)
union all
select 'SNAP2' snapshot, owner,object_name,object_type,status
	from (select          owner,object_name,object_type,status  
                from snap_objects_&&s2
        minus
        select           owner,object_name,object_type,status  
                from snap_objects_&&s1)
/





drop   table diff_tab_privs_&&s1&&s2;
create table diff_tab_privs_&&s1&&s2
as
select 'SNAP1' snapshot,  grantee,owner,table_name,privilege
	from (select      grantee,owner,table_name,privilege
                from snap_tab_privs_&&s1
        minus
        select            grantee,owner,table_name,privilege
                from snap_tab_privs_&&s2)
union all
select 'SNAP2' snapshot,  grantee,owner,table_name,privilege
        from (select      grantee,owner,table_name,privilege
                from snap_tab_privs_&&s2
        minus
        select            grantee,owner,table_name,privilege
                from snap_tab_privs_&&s1)
/



index_owner,index_name,table_name,column_name,column_position

drop   table diff_ind_columns_&&s1&&s2;
create table diff_ind_columns_&&s1&&s2
as
select 'SNAP1' snapshot,  index_owner,index_name,table_name,column_name,column_position
	from (select      index_owner,index_name,table_name,column_name,column_position
                from snap_ind_columns_&&s1
        minus
        select            index_owner,index_name,table_name,column_name,column_position
                from snap_ind_columns_&&s2)
union all
select 'SNAP2' snapshot,  index_owner,index_name,table_name,column_name,column_position
        from (select      index_owner,index_name,table_name,column_name,column_position
                from snap_ind_columns_&&s2
        minus
        select            index_owner,index_name,table_name,column_name,column_position
                from snap_ind_columns_&&s1)
/





drop   table diff_cons_columns_&&s1&&s2;
create table diff_cons_columns_&&s1&&s2
as
select 'SNAP1' snapshot,  owner, table_name,column_name,position
	from (select      owner, table_name,column_name,position
                from snap_cons_columns_&&s1
        minus
        select            owner, table_name,column_name,position
                from snap_cons_columns_&&s2)
union all
select 'SNAP2' snapshot,  owner, table_name,column_name,position
        from (select      owner, table_name,column_name,position
                from snap_cons_columns_&&s2
        minus
        select            owner, table_name,column_name,position
                from snap_cons_columns_&&s1)
/




