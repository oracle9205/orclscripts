REM  pqo_stat.sql
REM  Are parallel query server processes unused?
REM
column Parallel_Min_Servers format 999999999
select TO_NUMBER(A.Value) Parallel_Min_Servers,
       B.Value Servers_Busy
  from V$PARAMETER A, V$PQ_SYSSTAT B
 where A.Name = 'parallel_min_servers'
   and RTRIM(B.Statistic) = 'Servers Busy';

REM   Have any servers have been started?
REM
select Statistic, Value Servers_Started
  from V$PQ_SYSSTAT
 where RTRIM(Statistic) = 'Servers Started';

REM Is Parallel_Max_Servers high enough for current usage?
REM
column Parallel_Max_Servers format 999999999
select TO_NUMBER(A.Value) Parallel_Max_Servers,
       B.Value Servers_HW
  from V$PARAMETER A, V$PQ_SYSSTAT B
 where A.Name = 'parallel_max_servers'
   and RTRIM(B.Statistic) = 'Servers Highwater';

