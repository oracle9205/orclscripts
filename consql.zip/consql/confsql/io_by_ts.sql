column tablespace_name format a80
column percent_io format 999999999999
set linesize 200
select * from
(select df.tablespace_name,
      sum(  ((FS.Phyblkrd+FS.Phyblkwrt)/ab.tot)*100 )  Percent_IO
from
	dba_data_files df,
	v$filestat fs,
        (Select sum(f.phyblkrd + f.phyblkwrt) tot
            from v$filestat f, v$datafile d
            where f.file#=d.file# ) ab
where
	fs.file#=df.file_id 
group by tablespace_name 
)
order by Percent_IO
/
