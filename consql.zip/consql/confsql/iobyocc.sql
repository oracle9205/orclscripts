select substr(action,1,15),count(*), sum(BLOCK_GETS), sum(CONSISTENT_GETS), sum(PHYSICAL_READS),
		        sum(BLOCK_CHANGES), sum(CONSISTENT_CHANGES)
from
	v$sess_io io, v$session ses
where 
	ses.sid=io.sid
group by substr(action,1,15)
/
