set echo off;
set verify off;

prompt '-----------------------------------------------------------------------'
prompt CHECK1:
prompt Checking if wtrans_archive_partitions records are valid ...
prompt You should only see wta_over2 partition as the one that does not
prompt exist on wtrans_archive_partitions table.

--if partition name exists on the table
      select partition_name, partition_position
      from dba_tab_partitions@hist
      where table_name='WTRANSACTION_ARCHIVE' and partition_name not in (select partition_name from wtrans_archive_partitions) 
      order by partition_position asc;
prompt END OF CHECK1
prompt '-----------------------------------------------------------------------'

prompt '-----------------------------------------------------------------------' 
prompt CHECK2:
prompt Checking if there are duplicate rows on wtrans_archive_partitions...
prompt This query should come back with no rows selected. If there are dups
prompt pls. make sure to open up a remedy ticket and remove the duplicate asap.

--if duplicates exists on the table
select partition_name,partition_position 
  from wtrans_archive_partitions 
 where rowid not in (select min(rowid) from wtrans_archive_partitions group by partition_name);

prompt END OF CHECK2
prompt '------------------------------------------------------------------------'

prompt '------------------------------------------------------------------------' 
prompt Here are the values for wtrans_archive_partitions table...
select partition_name,partition_position
from wtrans_archive_partitions order by partition_position;
prompt END OF WTRANS_ARCHIVE_PARTITIONS TABLE

prompt '------------------------------------------------------------------------'
prompt CHECK3:
prompt Checking if wtransaction_partitions records are valid ...
prompt You should see no rows selected which means all partitions exist on the table
--if partition name exists on the table
      select partition_name, partition_position
      from dba_tab_partitions
      where table_name='WTRANSACTION' and partition_name not in (select partition_name from wtransaction_partitions) 
      order by partition_position asc;
prompt END OF CHECK3
prompt '-----------------------------------------------------------------------'

prompt '-----------------------------------------------------------------------'
prompt CHECK4:
prompt Checking if there are duplicate rows on wtransaction_partitions...
prompt This query should come back with no rows selected. If there are dups
prompt pls. make sure to open up a remedy ticket and remove the duplicate asap.

--if duplicates exists on the table
select partition_name,partition_position 
  from wtransaction_partitions 
 where rowid not in (select min(rowid) from wtransaction_partitions group by partition_name);

prompt END OF CHECK4
prompt '-----------------------------------------------------------------------'

prompt '-----------------------------------------------------------------------'
prompt Here are the values for wtransaction_partitions table...
select partition_name,partition_position
from wtransaction_partitions order by partition_position;
prompt END OF WTRANSACTION_PARTITIONS TABLE
prompt '-----------------------------------------------------------------------'
