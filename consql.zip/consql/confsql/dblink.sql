col host format a20
col db_link format a30

select * from dba_db_links ;
