/* 
 Sai -> 10/25/2007 */

set trimspool on
col "PQ, SID, TIME_SEC, PCT, NAME" for a125

select
 decode(sign(qcsid), 1, 'PQ: '||qcsid||' Sid: '||rpad(sid, 5), 'Sid: '||rpad(sid, 5))||
 ' Time-> '||rpad(time_remaining, 5)||' '||
 lpad(round((nvl(sofar, 0)/nvl(decode(totalwork, 0, 1, totalwork), 1)*100)), 2)||'% Done, '||
 message "PQ, SID, TIME_SEC, PCT, NAME"
from v$session_longops
where
time_remaining > 0
order by qcsid, sid
/
