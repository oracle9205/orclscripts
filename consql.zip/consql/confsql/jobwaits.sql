column info format a45
column wait format a6
column event format a30
column machine format a13
column sid format 99999
column seq# format 999999
column host format a15
select substr(s.program,1,20),s.sid,s.sql_address sqladdr,machine,w.event,io.block_gets+io.consistent_gets gets,
	decode(w.state,'WAITING','WAIT'
		    ,'WAITED KNOWN TIME',to_char(w.wait_time/100)
		    ,'WAITED SHORT TIME','SHORT'
		    ,'WAITED UNKNOWN TIME','?'
		    ,w.state) wait,
		    seconds_in_wait seconds,
	decode(w.event,'db file sequential read' ,waitinfo.segbyblock(w.p1,w.p2),
			'db file scattered read' ,waitinfo.segbyblock(w.p1,w.p2),
			'buffer busy waits' ,waitinfo.segbyblock(w.p1,w.p2),
			'latch free',waitinfo.latchbynum(w.p2)||': tries='||to_char(w.p3),
			'latch activity',waitinfo.latchbynum(w.p2),
			 decode(w.p1text,'','',w.p1text||':'||to_char(w.p1)) ||
			 decode(w.p2text,'','',','||w.p2text||':'||to_char(w.p2)))  info
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where s.sid = w.sid
	and io.sid=w.sid
	and s.sid in (select sid from dba_jobs_running)
	order by event,info 
/
