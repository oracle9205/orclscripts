set verify off numformat 9999999999999

def tablespace_name = &&1

select  segment_type, count(*) from dba_segments
where tablespace_name = upper('&tablespace_name')
group by segment_type;

col thrice_largest new_value next_extent_size noprint
select 2 * max(bytes)/1024 thrice_largest
from dba_free_space
where tablespace_name = upper('&tablespace_name');

create table drop_temp_segs (f1 char(2)) tablespace &tablespace_name storage (initial 1k next &next_extent_size.K minextents 2);

select  segment_type, count(*) from dba_segments
where tablespace_name = upper('&tablespace_name')
group by segment_type;

undefine 1
