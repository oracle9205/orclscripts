REM  mon_rsiz.sql
REM  Rollback Segment Extensions
REM
column Name format A20
select Name, OptSize, Shrinks, AveShrink, Extends
  from V$ROLLSTAT, V$ROLLNAME
 where V$ROLLSTAT.USN=V$ROLLNAME.USN;
