-- to list buffer busy waits by file
col name format a55

select name, time, count
from v$datafile df, x$kcbfwait fw
where fw.indx+1 = df.file# 
order by count ;
