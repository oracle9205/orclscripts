select sequence#, 
	min(first_time) first_change,
	max(decode(name,'STB',archived)) STB,
	max(decode(name,'CONFSB',archived)) CONFSB,
	max(decode(substr(name,1,1),'/',archived)) LOCAL
from v$archived_log
group by sequence# 
/
