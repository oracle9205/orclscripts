column index_name format a30
column columns format a50
column index_type format a10 heading type
column owner format a10
column tablespace_name format a15

select b.uniqueness,b.index_type,a.*
from
(select index_name,index_owner,
        max(decode(column_position,1,column_name,null))||
        max(decode(column_position,2,', '||column_name,null))||
        max(decode(column_position,3,', '||column_name,null))||
        max(decode(column_position,4,', '||column_name,null))||
        max(decode(column_position,5,', '||column_name,null)) columns from dba_ind_columns 
        where  table_name = upper('&table_name') 
group by index_name,index_owner) a,
dba_indexes b
where a.index_name = b.index_name and
a.index_owner=b.owner
/
