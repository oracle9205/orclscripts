set linesize 80;
set pagesize 1000;
set long 50;

break on "OWNER" on "TABLE";

/* ****************************************************** */
/*                                                        */
/*  - will show all the tables for a given database       */
/*                                                        */
/* ****************************************************** */

select 	substr(a.owner,1,10)                    "OWNER",
        substr(a.table_name,1,15)               "TABLE",
	substr(to_char(a.initial_extent, '9,999,999'),1, 10)
						"INIT EXT",
	substr(to_char(a.next_extent, '999,999'),1,8)
						"NEXT EXT",
	substr(to_char(a.pct_increase),1,4)	"% INC",
	substr(to_char(b.extents),1,3)		"EXTS"
from 	all_tables 	a,
	dba_segments	b 
where 	a.owner 	= b.owner    and
	a.table_name 	= b.segment_name and
        a.owner not in ('SYS','SYSTEM','OUTLN')
order by 1 asc, 2 asc;

set echo off;
set long 80;

