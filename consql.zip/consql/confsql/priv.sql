select to_char(sample_time, 'DD-MON-YY HH24:MI:SS'), count(*), trunc(avg(time_waited)), max(time_waited) from ash
where wait_class_id=3871361733 group by to_char(sample_time, 'DD-MON-YY HH24:MI:SS')  order by 1
/
