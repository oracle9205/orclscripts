

column name format  a35
column value format 999,999,999,999
select n.name,s.value
	from v$sysstat s, v$statname n
	where n.statistic#=s.statistic#
	and (n.name like '%check%'
	or n.name = 'physical writes'
	or n.name = 'redo blocks written'
	or n.name = 'DBWR undo block writes')
/
