col "DB_SIZE in Megs" format 999,999

select sum(bytes)/(1024*1024) "DB_SIZE in Megs" from v$datafile ;
