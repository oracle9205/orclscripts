set pages 0 trims on
select to_char(sample_time, 'DD-MON-YY HH24:MI:SS'), count(*), trunc(avg(time_waited)), max(time_waited) from 
&ASH_Table_Name 
where wait_class_id=3871361733 and to_char(sample_time, 'MM-DD-YY') > '06-06-11' 
group by to_char(sample_time, 'DD-MON-YY HH24:MI:SS') order by  to_char(sample_time, 'DD-MON-YY HH24:MI:SS');
