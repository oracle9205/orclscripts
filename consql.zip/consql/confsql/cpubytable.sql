REM Script to report top 25 cpu/pio/lio by table for the most recent awr snapshot interval
REM Sai => 11/19/2008

set trimspool on
col table_name for a30

select /* rule */ * from
 (select
  table_name, round(sum(cpu_pct)*100) cpu_pct, round(sum(lio_pct)*100) lio_pct, round(sum(pio_pct)*100) pio_pct
  from
   (select /*+ index(d, WRH$_SQLSTAT_PK) */
    c.table_name,
    cpu_time_delta/(nvl((sum(cpu_time_delta) over ()),0)+0.001) cpu_pct,
    buffer_gets_delta/(nvl((sum(buffer_gets_delta) over ()),0)+0.001) lio_pct,
    disk_reads_delta/(nvl((sum(disk_reads_delta) over ()),0)+0.001) pio_pct
    from
     (select distinct * from (select a.sql_id, b.to_name table_name from
                              v$sql a, v$object_dependency b
                              where a.hash_value = b.from_hash and b.to_type=2 and
                              b.to_owner = 'CONFDBA')) c,
      (select /*+ index(e, WRH$_SQLSTAT_PK) */ * from wrh$_sqlstat e where dbid = (select dbid from v$database) and snap_id =
         (select snap_id from (select /*+ index_desc(e, WRM$_SNAPSHOT_PK) */ snap_id from dba_hist_snapshot e) where rownum =1)) d
where
c.sql_id = d.sql_id
)
group by table_name
order by 2 desc
)
where rownum <= 25
/
