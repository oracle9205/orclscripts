col owner format a12
col referenced_name format a20
col REFERENCED_LINK_NAME format a6
col referenced_owner format a12

select * from dba_dependencies where referenced_name = upper('&REFERENCED_NAME') ;
