rem 
explain plan for 
/* WUser--load_search_wildcard */SELECT wuser.account_number FROM wuser WHERE wuser.account_number IN (SELECT /*+ INDEX (WUSER_ALIAS WUSER_ALIAS_ALIAS_UPPER) */ wuser_alias.account_number FROM wuser_alias WHERE wuser_alias.alias_upper LIKE :email_upper) AND ROWNUM <= :max_res
/
@plan
rollback ;
