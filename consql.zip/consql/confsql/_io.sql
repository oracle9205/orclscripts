select s.file#, d.name, d.bytes, s.phywrts, s.phyblkwrt from v$filestat s, v$datafile d where s.file#=d.file# order by phywrts, phyblkwrt 
/
