set echo on
set timing on

Uncomment and execute the following to reduce the load on CONF.

-- 1) This will eliminate all the admin queries hitting wlog_entry.
-- This will impact our Fraud prevention capability.
-- Drop public synonym wlog_entry_all ;


-- to turn it back on
-- create public synonym wlog_entry_all for confdba.wlog_entry_all ;


----------------------


-- 2) This will disable all queries hitting HIST from CONF using the dblink
-- This will mean customers can not see their historical data > 60 days 
-- Also the customer or admin will not be able to close any accounts. 
-- Customers will get a message stating 'Transaction History will be available after 1 Hour'
-- This will also impact the dlog ( downloadable log ) feature.

-- update wtransaction_archive_status set available = 0 ;
-- commit ;

-- to turn it back on

-- update wtransaction_archive_status set available = 1 ;
-- commit ;

