REM  pool_str.sql
REM  Shared Pool Structures
REM
set serveroutput on size 10000
REM 

DECLARE

val1 number;
val2 number;
val3 number;
val4 number;
val5 number;
val6 number;
val7 number;
val8 number;
val9 number;
val10 number;

BEGIN

select Value into  val1
  from V$PARAMETER
 where Name='shared_pool_size' ;

select round(SUM(Sharable_Mem+Persistent_Mem+Runtime_Mem),2) into val2
  from V$SQLAREA ;

select  round(SUM(Sharable_Mem),2), round(SUM(Persistent_Mem),2), round(SUM(Runtime_Mem),2), count(*) 
           into  val3, val4, val5, val6
  from V$SQLAREA ;

select COUNT(*)  into  val7
  from V$DB_OBJECT_CACHE ;

select (val1-val2) into  val8
  from DUAL;

select COUNT(*)  into val9
  from V$SESSION A, V$SQLTEXT B
 where A.SQL_Address||A.SQL_Hash_Value = B.Address||B.Hash_Value ;


select round(SUM(Sharable_Mem+Persistent_Mem+Runtime_Mem),2)  into val10
  from V$SESSION A,
       V$SQLTEXT B,
       V$SQLAREA C
 where A.SQL_Address||A.SQL_Hash_Value = 
         B.Address||B.Hash_Value 
   and B.Address||B.Hash_Value = C.Address||C.Hash_Value ;


DBMS_OUTPUT.PUT_LINE('--------------  Shared Pool Library Cache Information    --------------------') ;
DBMS_OUTPUT.PUT_LINE('Size                                 : '||  val1                              ) ;
DBMS_OUTPUT.PUT_LINE('Used (total)                         : '||  val2                              ) ;
DBMS_OUTPUT.PUT_LINE('Sharable                             : '||  val3                              ) ;
DBMS_OUTPUT.PUT_LINE('Persistent                           : '||  val4                              ) ;
DBMS_OUTPUT.PUT_LINE('Runtime                              : '||  val5                              ) ;
DBMS_OUTPUT.PUT_LINE('Available                            : '||  val8                              ) ;
DBMS_OUTPUT.PUT_LINE('Number of SQL Stmts                  : '||  val6                              ) ;
DBMS_OUTPUT.PUT_LINE('Number of Programmatic Constructs    : '||  val7                              ) ;
DBMS_OUTPUT.PUT_LINE('Pinned Statements                    : '||  val9                              ) ;
DBMS_OUTPUT.PUT_LINE('Pinned Statements size               : '||  val10                             ) ;
DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------------------') ;

END ;
/
