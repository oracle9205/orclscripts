-- ------------------------------------------------------------------
-- chk_schema.sql
-- Purpose	- Checks the consistency of schema objects
--
-- Author	- Logo Palanisamy
--
-------------------------------------------------------------------------
-- ** List all batch objects which depend "completely" on OLTP schema
-- ** List all orphan grants (grants to non-existing objects)
-- ** List the count of constraints by type, owner (disabled/total)
-- ** List all tablespace quota information
-- ** No T_STAT tables in batch schema
-- ** List any interbatch object dependency. e.g sp_backward_calc
-- ** List all irrelevant roles DEVELOPERD, etc
-- ** If a table is in all schema (T_PRC_DPVA_CONS), there should be
--    public synonym for it.
set echo off
set pause off
set verify off
set heading on
set feedback off
set linesize 80 trimspool on 
set pagesize 50
set newpage 0
set embedded off
col table_owner format a11
col owner format a14
col index_tbs format a9
col table_tbs format a9
col schema_today format a12
col object_name format a30
col tablespace_name format a10
col index_name format a25
col segment_name format a25
col segment_type format a8
col object_type format a15
col towner format a6
col table_name format a25
col server_alias format a16 truncated
col prev_status format a18
col curr_status format a18
col grantee format a17
col grantor format a7
col privilege format a12
col server_name format a11
col user new_value id noprint
col db_date format a11
col schema_status format a13
col server_alias format a10
col db_status format a13

col schema_nme format a7
col s_status format a9
col s_today format a7

column TODAY noprint new_value _DATE 
column server noprint new_value _SERVER 
column dbname    noprint new_value _SID

select name dbname, to_char(SYSDATE, 'fmMonth DD, YYYY') TODAY
from sys.v_$database;

SELECT DECODE(UPPER(MACHINE), 'FMSQL707', 'Kepler', 
'NEWTON', 'Newton', 'FMSQL512', 'Lowell', UPPER(MACHINE)) server
from v$session 
where program like '%PMON%';

spool chk_schema.lst

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'T_STAT_DB_STATUS Info' -
 RIGHT 'SID: ' _SID SKIP 1 
select schema_nme schema, schema_status s_status, schema_today s_today, database_status db_status,
to_char(database_dte, 'mm/dd hh24:mi') db_date, eod_dt_tm eod_time, last_reset_dt_tm reset_dte 
from t_stat_db_status
where server_name = (select machine
from v$session
WHERE program like '%(PMON)%');

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Synonym Info' -
 RIGHT 'SID: ' _SID SKIP 1 
SELECT OWNER, table_owner, COUNT(*) FROM DBA_SYNONYMS
where owner not  in ('SYS', 'SYSTEM')
GROUP BY OWNER, table_owner;

Ttitle center 'Sub Roles Granted to roles/users'
col oltp heading 'OLTP' format 9999
col int1 heading 'INT1' format 9999
col int2 heading 'INT2' format 9999
col int3 heading 'INT3' format 9999
col int4 heading 'INT4' format 9999
col int5 heading 'INT5' format 9999
select grantee role, 
sum(decode(substr(granted_role, -1, 1), 'O', 1, 0)) OLTP,
sum(decode(substr(granted_role, -1, 1), '1', 1, 0)) INT1,
sum(decode(substr(granted_role, -1, 1), '2', 1, 0)) INT2,
sum(decode(substr(granted_role, -1, 1), '3', 1, 0)) INT3,
sum(decode(substr(granted_role, -1, 1), '4', 1, 0)) INT4,
sum(decode(substr(granted_role, -1, 1), '5', 1, 0)) INT5
from dba_role_privs
where granted_role like '%O' 
or granted_role like '%1'
or granted_role like '%2'
or granted_role like '%3'
or granted_role like '%4'
or granted_role like '%5'
group by grantee;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Number of privileges granted to each Role' -
 RIGHT 'SID: ' _SID SKIP 1 
col role format a16
col oltp format 9999
col oltp format 9999
col int1 format 9999
col int2 format 9999
col int3 format 9999
col int4 format 9999
col int5 format 9999
select substr(grantee, 1, length(grantee)-1) role,
sum(decode(grantor, 'OLTP', 1, 0)) OLTP,
sum(decode(grantor, 'INT1', 1, 0)) INT1,
sum(decode(grantor, 'INT2', 1, 0)) INT2,
sum(decode(grantor, 'INT3', 1, 0)) INT3,
sum(decode(grantor, 'INT4', 1, 0)) INT4,
sum(decode(grantor, 'INT5', 1, 0)) INT5
from dba_tab_privs
where grantor in ('OLTP','INT1', 'INT2', 'INT3', 'INT4', 'INT5')
and grantee in (select role from dba_roles)
group by substr(grantee, 1, length(grantee)-1);

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Number of objects in each schema by object type' -
 RIGHT 'SID: ' _SID SKIP 1 
select object_type,
sum(decode(owner, 'OLTP', 1, 0)) OLTP,
sum(decode(owner, 'INT1', 1, 0)) INT1,
sum(decode(owner, 'INT2', 1, 0)) INT2,
sum(decode(owner, 'INT3', 1, 0)) INT3,
sum(decode(owner, 'INT4', 1, 0)) INT4,
sum(decode(owner, 'INT5', 1, 0)) INT5
from dba_objects
where owner in ('OLTP','INT1', 'INT2', 'INT3', 'INT4', 'INT5')
GROUP BY OBJECT_TYPE;

col constraint_class heading constraint_type format a12
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Constraint count by schema' -
 RIGHT 'SID: ' _SID SKIP 1 
select decode(constraint_type, 'P', 'PRIMARY KEY',
'U', 'UNIQUE KEY',
'C', 'CHECK',
'R', 'REFERENTIAL',
'V', 'CHECK OPTION') constraint_class, 
sum(decode(owner, 'OLTP', 1, 0)) OLTP,
sum(decode(owner, 'INT1', 1, 0)) INT1,
sum(decode(owner, 'INT2', 1, 0)) INT2,
sum(decode(owner, 'INT3', 1, 0)) INT3,
sum(decode(owner, 'INT4', 1, 0)) INT4,
sum(decode(owner, 'INT5', 1, 0)) INT5
from dba_constraints
group by decode(constraint_type, 'P', 'PRIMARY KEY',
'U', 'UNIQUE KEY',
'C', 'CHECK',
'R', 'REFERENTIAL',
'V', 'CHECK OPTION');
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 -
left 'Server: ' _SERVER  -
center 'Database Freespace Summary Report' -
RIGHT 'SID: ' _SID SKIP 1 

col tsname  format         a16 justify c heading 'Tablespace'
col nfrags  format     999,990 justify c heading 'Free|Frags'
col mxfrag  format 999,999,990 justify c heading 'Largest|Frag (KB)'
col totsiz  format 999,999,990 justify c heading 'Total|(KB)'
col avasiz  format 999,999,990 justify c heading 'Available|(KB)'
col pctusd  format         990 justify c heading 'Pct|Used'

select
  total.tablespace_name                       tsname,
  count(free.bytes)                           nfrags,
  nvl(max(free.bytes)/1024,0)                 mxfrag,
  total.sbytes/1024                           totsiz,
  nvl(sum(free.bytes)/1024,0)                 avasiz,
  (1-nvl(sum(free.bytes),0)/total.sbytes)*100  pctusd
from
  (select tablespace_name, sum(bytes) sbytes
  from dba_data_files
  group by tablespace_name) total,
  sys.dba_free_space  free
where
  total.tablespace_name = free.tablespace_name(+)
group by
  total.tablespace_name,
  total.sbytes;

-- Select the default tablespace and temporary tablespace
col username format a10
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Default and Temporary tablespace info' -
 RIGHT 'SID: ' _SID SKIP 1 
select username, default_tablespace, temporary_tablespace
from dba_users
where username in ('OLTP', 'INT1', 'INT2', 'INT3','INT4', 'INT5');

select default_tablespace, temporary_tablespace,count(*)
from dba_users
group by default_tablespace, temporary_tablespace;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Info about Database links'  -
 RIGHT 'SID: ' _SID SKIP 1 
col owner format a8
col db_link format a20  
col host format a20
select * from dba_db_links;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Objects in one schema, but not in other(s)' -
 RIGHT 'SID: ' _SID SKIP 1 
col int1 format a4
col int2 format a4
col int3 format a4
col int4 format a4
col int5 format a4
select object_name, object_type,
max(decode(owner, 'INT1', 'Y', 'N')) INT1,
max(decode(owner, 'INT2', 'Y', 'N')) INT2,
max(decode(owner, 'INT3', 'Y', 'N')) INT3,
max(decode(owner, 'INT4', 'Y', 'N')) INT4,
max(decode(owner, 'INT5', 'Y', 'N')) INT5
from dba_objects
where object_name in (select object_name from dba_objects
		      where owner in ('INT1', 'INT2', 'INT3', 'INT4', 'INT5')
		      group by object_name having count(*) < 5)
and owner in ('INT1', 'INT2', 'INT3', 'INT4', 'INT5')
GROUP BY OBJECT_type, object_name;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Invalid Objects' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, object_name, object_type from dba_objects
where status = 'INVALID'
order by owner;

-- There should be no triggers in Batch schema
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Triggers in Batch Schema' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, table_name, trigger_name
from dba_triggers
where owner like 'INT_';

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Disabled Triggers' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, table_name,trigger_name
from dba_triggers
where status = 'DISABLED'
order by owner;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Disabled Constraints' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, table_name,constraint_name, constraint_type
from dba_constraints
where status = 'DISABLED'
minus
select owner, table_name,constraint_name, constraint_type
from dba_constraints
where status = 'DISABLED'
and owner like 'INT_'
and constraint_type = 'R'
order by owner;

-- List all objects that have PUBLIC privilege
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Objects with PUBLIC privilege' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, table_name, privilege
from dba_tab_privs
where grantee = 'PUBLIC' 
and owner not in ('SYS', 'SYSTEM')
order by owner, table_name;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'System Privileges granted to Public' -
 RIGHT 'SID: ' _SID SKIP 1 
select * from dba_sys_privs
where grantee = 'PUBLIC';

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Roles granted to Public' -
 RIGHT 'SID: ' _SID SKIP 1 
select * from dba_role_privs
where grantee = 'PUBLIC';

-- Make sure there are no non-oltp tables in OLTP
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Non-OLTP tables in OLTP' -
 RIGHT 'SID: ' _SID SKIP 1 
select table_name from dba_tables
where owner = 'OLTP' 
and table_name in (select table_nme 
		   from t_table_list 
		   where oltp_tbl_flg = 'N');

-- List any missing OLTP tables
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Missing OLTP tables' -
 RIGHT 'SID: ' _SID SKIP 1 
select table_nme from t_table_list
where oltp_tbl_flg = 'Y'
minus
select table_name from dba_tables
where owner = 'OLTP';

-- List all T_PRC tables in OLTP tables 
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'T_PRC tables in OLTP tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, table_name, tablespace_name from dba_tables
where table_name like 'T_PRC%'
and tablespace_name like 'OLTP%';

-- List all TR tables owned by OLTP
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'TR tables in OLTP' -
 RIGHT 'SID: ' _SID SKIP 1 
select table_name from dba_tables
where owner = 'OLTP' 
and table_name like 'TR%';

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Indexes on someone elses table' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, index_name, table_owner, table_name
from dba_indexes
where owner <> table_owner;

-- List all indexex in Table tablespaces (%_TTS)
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Indexes in Table tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, index_name, tablespace_name, table_name from dba_indexes
where tablespace_name like '%_TTS';

-- List all tables in index tablespace (%_ITS)
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Tables in Index tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, table_name from dba_tables
where tablespace_name like '%_ITS';

-- List tables and its indexes in the same tablespace
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Tables and Indexes in the same tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select i.owner || '.' || i.index_name index_name, 
i.tablespace_name index_tbs, 
i.table_owner || '.' || i.table_name table_name, 
t.tablespace_name table_tbs
from dba_indexes i, dba_tables t
where t.owner not in ('SYS', 'SYSTEM') 
and i.table_owner = t.owner
and i.table_name = t.table_name
and i.tablespace_name = t.tablespace_name
order by i.index_name;

-- List any objects in the wrong tablespace
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Tables and Indexes in the Wrong tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, segment_name, segment_type, tablespace_name
from dba_segments
where (owner like 'INT_' and tablespace_name like 'OLTP%') 
or (owner like 'INT_' and tablespace_name like 'INTERFACE%') 
or (owner = 'OLTP' and tablespace_name like 'BATCH_%');

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Users with SYSTEM as their default/temporary tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select username, default_tablespace, temporary_tablespace
from dba_users
where default_tablespace = 'SYSTEM' 
OR temporary_tablespace = 'SYSTEM';

-- List objects in SYSTEM tablespace
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Non-System Objects in SYSTEM tablespace' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, segment_type, count(*) 
from dba_segments
where owner not in ('SYS', 'SYSTEM')
and tablespace_name = 'SYSTEM'
group by owner, segment_type;

-- List the chained rows
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Chained Rows' -
 RIGHT 'SID: ' _SID SKIP 1 
select table_name, owner, num_rows, chain_cnt, pct_free
from dba_tables
where chain_cnt > 0
order by table_name;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Private Synonyms pointing to OLTP objects' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, synonym_name
from dba_synonyms
where owner <> 'PUBLIC'
and table_owner = 'OLTP';

-- ** List any grants between batch schemas (int1 to int2 etc.)
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Grants between batch objects' -
 RIGHT 'SID: ' _SID SKIP 1 

select grantee, owner, table_name, privilege
from dba_tab_privs
where grantee like 'INT_'
AND GRANTOR LIKE 'INT_';

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Segments within 10 Extents of Effective Max' -
 RIGHT 'SID: ' _SID SKIP 1 

col segname format   a42 justify c trunc heading 'Segment'
col segtype format   a10 justify c trunc heading 'Type'
col excount format 9,990 justify c trunc heading 'Current|Extents'
col maxexts format 9,990 justify c trunc heading 'Max|Extents'
col extdiff format 9,990 justify c trunc heading 'Extents|Remaining'

select
  owner||'.'||segment_name              segname,
  segment_type                          segtype,
  extents                               excount,
  least(max_extents,505)          maxexts,
  least(max_extents,505)-extents  extdiff
from
  dba_segments
where
  (least(max_extents,505)-extents <= 10)
order by
  extents/(least(max_extents,505)+0.00001)  desc,
  least(max_extents,505)-extents    desc;

-- ** List all synonyms without the base objects
ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Synonyms without the base objects' -
 RIGHT 'SID: ' _SID SKIP 1 

select owner,  synonym_name, table_owner, table_name
from dba_synonyms
where (table_owner, table_name) not in (select owner, object_name from dba_objects);

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Public Synonyms without the grants ' -
 RIGHT 'SID: ' _SID SKIP 1 
select table_owner, table_name
from dba_synonyms
where owner = 'PUBLIC'
and table_owner not in ('SYS', 'SYSTEM')
minus
 select owner, table_name
from dba_tab_privs;

ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Privileges granted by non-owners' -
 RIGHT 'SID: ' _SID SKIP 1 
select grantee, owner, table_name, grantor, privilege
from dba_tab_privs
where owner <> grantor;


ttitle left _DATE right 'Page: ' format 99 SQL.PNO skip 1 - 
 left 'Server: ' _SERVER  -
 center 'Objects owned by others' -
 RIGHT 'SID: ' _SID SKIP 1 
select owner, object_name, object_type
from dba_objects
where owner not in ('SYS', 'SYSTEM', 'OLTP', 'INT1', 'INT2', 'INT3', 'INT4', 'INT5', 'DBCHNG1', 'TRANS_OLTP')
and object_type <> 'SYNONYM'
order by owner;

-- Objects in BATCH and OLTP with public synonyms pointing to OLTP 
-- select owner, object_name, object_type
-- from dba_objects
-- where owner in ('INT1', 'INT2', 'INT3', 'INT4', 'INT5', 'OLTP', 'PUBLIC') 
-- and OBJECT_NAME IN (select table_name from dba_synonyms
-- where owner = 'PUBLIC'
-- AND table_owner = 'OLTP')
-- order by object_name, owner
-- /
ttitle off
SPOOL off

