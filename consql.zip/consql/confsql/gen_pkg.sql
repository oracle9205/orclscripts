set echo off verify off feedback off pagesize 0
set term on 
select 'Creating package build script...' from DUAL; 

accept package_name prompt "Enter the name of the package: " 
accept package_owner prompt "Enter package owner: "
set term off  
  
drop   table PACK_TEMP
/

create table PACK_TEMP (  
        Lineno NUMBER, 
        Id_Owner VARCHAR2(30),
        Id_Name VARCHAR2(30),  
        text VARCHAR2(2000)) 
/ 
 
declare 
   cursor PACK_CURSOR is 
         select Owner,  
                Name,
                Type, 
                Line,
                Text
           from DBA_SOURCE
          where Type in ('PACKAGE','PACKAGE BODY')   
            and Owner = UPPER('&&package_owner')    
            and Name like UPPER('&&package_name')
          order by Owner, Name, Type, Line;

   Lv_Owner             DBA_SOURCE.Owner%TYPE; 
   Lv_Name              DBA_SOURCE.Name%TYPE; 
   Lv_Type              DBA_SOURCE.Type%TYPE; 
   Lv_Text              DBA_SOURCE.Text%TYPE; 
   Lv_Line              DBA_SOURCE.Line%TYPE; 
   Lv_String            VARCHAR2(2100); 
   Lv_String2           VARCHAR2(2100); 
   Lv_Lineno            NUMBER := 0; 
  
   procedure WRITE_OUT(P_Line INTEGER, P_Owner VARCHAR2, P_Name VARCHAR2,  
                       P_String VARCHAR2) is 
   begin 
      insert into PACK_TEMP (Lineno, Id_Owner, Id_Name, Text)  
             values (P_Line,P_Owner,P_Name,P_String); 
    end; 
  
begin 
   open PACK_CURSOR; 
   Lv_Lineno  := 1; 
   loop 
      fetch PACK_CURSOR into Lv_Owner,
                             Lv_Name,
                             Lv_Type,
                             Lv_Line,
                             Lv_Text;
      exit when PACK_CURSOR%NOTFOUND; 
 
      if (Lv_Line = 1)
      then
          if (Lv_Type = 'PACKAGE BODY')
          then
               WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_Name, '/'); 
               Lv_Lineno  := Lv_Lineno + 1; 
          end if;

          Lv_String  := 'CREATE OR REPLACE ' || UPPER(Lv_Type)  || ' ';
          WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_Name, Lv_String); 
          Lv_Lineno  := Lv_Lineno + 1; 

          Lv_String  := SUBSTR(Lv_Text,LENGTH(Lv_Type)+1,
                        (LENGTH(Lv_Text) - LENGTH(Lv_Type)));
          Lv_String  := Lv_Owner || '.' || LTRIM(Lv_String);
          WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_Name, Lv_String); 
          Lv_Lineno  := Lv_Lineno + 1; 
      else
          WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_Name, Lv_Text); 
          Lv_Lineno := Lv_Lineno + 1; 
      end if;
   end loop; 

   WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_Name, '/'); 
   close PACK_CURSOR; 
end; 
/
spool cre_pkg.sql 
select Text 
  from PACK_TEMP
 order by Id_Owner, Id_Name, Lineno
/
spool off 

