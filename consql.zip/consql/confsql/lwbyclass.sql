REM Lightwaits report by wait class.
REM All time metrics are in seconds except where mentioned explicitly
REM Sai => 06/14/11

set lines 199
set pages 40
set ver off
alter session set nls_date_format = 'MM/DD HH24:MI:SS';

col event for a20
col top_sql for a13
col cnt for 99999
col "TIME" for 9999
col avg_time_ms for 99999
col max_time_ms for 99999
col p1 for 99999999999999
col p1_cnt for 999
col p2_cnt for 999
col p3_cnt for 999
col obj_cnt for 999
col obj_id for 999999
col locks for 999

select
 event, top_sql, cnt, total_time "TIME", max_time_ms,avg_time_ms, p1, p1_cnt, p2_cnt, p3_cnt,
 obj_cnt, obj_id, locks
from
(
select
 substr(event,1,20) event,
 first_value(sql_id ) over (partition by (case when sql_id is not null then event end) order by cnt desc) top_sql,
 row_number() over (partition by (case when sql_id is not null then event end) order by cnt desc) rn,
 sum(cnt) over (partition by event) cnt,
 sum(total_time) over(partition by event) total_time,
 max(max_time_ms) over(partition by event) max_time_ms,
 round(avg(avg_time_ms) over(partition by event)) avg_time_ms,
 max(p1) over (partition by event) p1,
 count(distinct p1) over (partition by event) p1_cnt,
 count(distinct p2) over (partition by event) p2_cnt,
 count(distinct p3) over (partition by event) p3_cnt,
 count(distinct ROW_WAIT_OBJ#) over (partition by event) obj_cnt,
 max(ROW_WAIT_OBJ#) over (partition by event) obj_id,
 sum(blockers) over (partition by event) as locks
from
(
select 
 wait_class#||':'||wait_class event,
 sql_id,
 p1,p2,p3,row_wait_obj#,
 count(*) as cnt,
 round(sum(wait_time_micro)/1000000) as total_time,
 round(max(wait_time_micro)/1000) as max_time_ms,
 round(avg(wait_time_micro)/1000) as avg_time_ms,
 count(blocking_session) blockers
from v$session
where
status = 'ACTIVE' and
((event not in ('rdbms ipc message', 'pmon timer', 'smon timer', 'jobq slave wait') and type <> 'BACKGROUND') or
 (wait_class <> 'Idle' and type = 'BACKGROUND'))
group by
 wait_class#||':'||wait_class, sql_id, p1,p2,p3,row_wait_obj#
))
where rn=1 and top_sql is not null
order by event
/

