 select sql2u(to_date(to_char('&date_to_check'),'dd-mon-yy hh24:mi:ss')) from dual;
