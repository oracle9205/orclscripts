select s.sid,to_char((consistent_gets+block_gets)/decode((consistent_gets+block_gets+physical_reads),0,1,(consistent_gets+block_gets+physical_reads)),'999.99') hit_ratio,s.module,i.block_gets,i.consistent_gets,
	i.physical_reads,i.block_changes,i.consistent_changes from v$sess_io i,
	v$session s
	where i.sid in (&sidlist)
	and i.sid=s.sid
/
