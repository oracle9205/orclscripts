
column db_link format a20
column host format a30
select db_link, username, host from dba_db_links; 
