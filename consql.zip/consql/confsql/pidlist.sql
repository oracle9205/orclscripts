
accept pidlist prompt 'Enter the list of PIDs,:'
