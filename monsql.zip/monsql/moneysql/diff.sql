accept s1 prompt 'Suffix1: '
accept s2 prompt 'Suffix2: '

drop table diffs ;

create table diffs as select distinct statement_id from
(
select statement_id,id,level,operation,options,object_name,object_node,object_name
from splain_&s1 minus
select statement_id,id,level,operation,options,object_name,object_node,object_name
from splain_&s2)
/

