host iostat -xM 5 | egrep 'device|md1'
