select s.sid,substr(machine,1,10) machine,s.sql_address sqladdr,w.event,io.block_gets+io.consistent_gets gets,
		s.module,
		    seconds_in_wait seconds
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where  s.sid = w.sid and io.sid=w.sid and
	s.status='ACTIVE'
	and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
/
