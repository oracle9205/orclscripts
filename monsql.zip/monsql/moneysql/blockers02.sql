-- Written by Sai on 12/08/2005
set trimspool on
set lines 150
col command for a18
col module for a18

select s.sid, sql_hash_value hash_value, 
       decode(command, 3, 'SELECT FOR UPDATE', 2, 'INSERT', 6, 'UPDATE', 7, 'DELETE', 189, 'MERGE', command) command,
       machine, module, status, cnt-1 waiters, ctime block_time from
 (select sid, block, max(decode(block, 1, ctime, 0)) over (partition by type, id1, id2 order by block desc) ctime,
         count(*) over (partition by type, id1, id2 ) cnt
  from v$lock
  where (block <> 0 or request <> 0)
 ) l,
 v$session s
where
s.sid = l.sid and
l.block <> 0
order by cnt desc
/
