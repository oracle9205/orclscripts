select * from
(select substr(df.file_name,1,4),
	sum(fs.phyrds) phyrds,
	sum(fs.phywrts) phywrts,
	sum(fs.phyblkrd) phyblkrd,
	sum(fs.phyblkwrt) phyblkwrt,
	avg(fs.avgiotim) avgiotim
from
	dba_data_files df,
	v$filestat fs
where
	fs.file#=df.file_id
group by
	substr(df.file_name,1,4)
)
order by phyblkrd asc
/
