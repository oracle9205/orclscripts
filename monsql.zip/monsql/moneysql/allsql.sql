select loads,parse_calls,executions,buffer_gets,disk_reads ,sql_text from  allsql
where  address=hextoraw('&address')
/
