REM you need to run dbms_stats.unlock_table_stats to regather table stats, but please backup the stats first.

set ver off
exec dbms_stats.lock_table_stats(ownname => '&owner', tabname => '&table_name');
