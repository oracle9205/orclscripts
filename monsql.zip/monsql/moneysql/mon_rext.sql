REM  mon_rext.sql
REM   Rollback Segment Wraps Check
REM
column Name format A20
select Name, OptSize, Shrinks, AveShrink, Wraps, Extends
  from V$ROLLSTAT, V$ROLLNAME
 where V$ROLLSTAT.USN=V$ROLLNAME.USN;

