col module format a20
col machine format a26
col 1 format 9999
col 2 format 9999
col 3 format 9999
col 4 format 9999
col 5 format 9999
col 6 format 9999
col 7 format 9999
col 8 format 9999
col 9 format 9999
col 10 format 9999
col 11 format 9999
col 12 format 9999
col 13 format 9999
col 14 format 9999
col 15 format 9999
col 16 format 9999
col 17 format 9999
col 18 format 9999
col 19 format 9999
col 20 format 9999
col tot format 9999

select machine, count(*) "Session Count" from v$session group by machine order by machine
/

select module,
--        count(decode(machine,'occ1',1))   "1" ,
--        count(decode(machine,'occ2',1))   "2" ,
--        count(decode(machine,'occ3',1))   "3" ,
--        count(decode(machine,'occ4',1))   "4" ,
--        count(decode(machine,'occ5',1))   "5" ,
--        count(decode(machine,'occ6',1))   "6" ,
        count(decode(machine,'occ7',1))   "7" ,
        count(decode(machine,'occ8',1))   "8" ,
        count(decode(machine,'occ9',1))   "9" ,
        count(decode(machine,'occ10',1)) "10",
        count(decode(machine,'occ11',1)) "11" ,
        count(decode(machine,'occ12',1)) "12" ,
        count(decode(machine,'occ13',1)) "13" ,
        count(decode(machine,'occ14',1)) "14" ,
        count(decode(machine,'occ15',1)) "15" ,
        count(decode(machine,'occ16',1)) "16" ,
        count(decode(machine,'occ17',1)) "17" ,
        count(decode(machine,'occ18',1)) "18" ,
	count(decode(machine,'occ19',1)) "19" ,
        count(decode(machine,'occ20',1)) "20" ,
count(*) tot from v$session
group by module
/

select count(*), status from v$session group by status 
/
