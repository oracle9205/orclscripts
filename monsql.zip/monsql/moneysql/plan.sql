column query_plan format a65
column other format a50
column other_tag format a14
column object_name format a30
select bytes,lpad(' ',2*level)||operation||' '||options
       ||' '||object_name||' '||object_node query_plan,other_tag,object_name
from   plan_table
connect by prior id = parent_id 
start with id = 0
/
