create table &tabname as
    select * from v$session_event where sid in
   ( select sid from v$session where machine like 'BOMBAY%WWW4%')
/
