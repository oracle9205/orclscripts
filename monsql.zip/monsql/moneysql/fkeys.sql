col Parent_table format a20
col column_name format a20
col constraint_name format a40

select B.Table_Name Parent_Table, 
       A.Table_Name Child_Table, 
       C.Column_Name,
       A.Constraint_name
  from DBA_CONSTRAINTS A, 
       DBA_CONSTRAINTS B, 
       DBA_CONS_COLUMNS C
 where A.R_Constraint_Name = B.Constraint_Name
   and A.Constraint_Type='R'
   and B.Constraint_Type ='P'
   and A.Constraint_Name=C.Constraint_Name
   and A.Table_Name=C.Table_Name
   and B.Table_Name=upper('&table_name')
 order by B.Table_Name, A.Table_Name, C.Position
/

