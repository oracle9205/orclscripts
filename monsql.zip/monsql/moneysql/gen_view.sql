set echo off verify off term on feedback off pagesize 0 long 20000
select 'Creating view build script...' from DUAL; 

accept view_name prompt "Enter the name of the View: " 
accept view_owner prompt "Enter view owner: "
set term off   

drop   table VIEW_TEMP
/

create table VIEW_TEMP (  
        Lineno NUMBER, 
        Id_Owner VARCHAR2(30),
        Id_Name VARCHAR2(30),  
        Text LONG) 
/ 
    
declare 
   cursor VIEW_CURSOR is 
         select Owner,  
                View_Name, 
                Text_Length,
                Text
           from DBA_VIEWS
          where Owner = UPPER('&&view_owner') 
            and View_Name like UPPER('&&view_name')
          order by Owner, View_Name; 

   Cursor VIEW_COLS_CURSOR (V_Name VARCHAR2, V_Owner VARCHAR2) is
         select Column_Name
           from DBA_TAB_COLUMNS
          where Table_Name = V_Name
            and Owner = V_Owner
          order by Column_ID;
                  
   Lv_Owner             DBA_VIEWS.Owner%TYPE; 
   Lv_View_Name         DBA_VIEWS.View_Name%TYPE; 
   Lv_Text_Length       DBA_VIEWS.Text_Length%TYPE; 
   Lv_Text              DBA_VIEWS.Text%TYPE;    
   Lv_Column_Name       DBA_TAB_COLUMNS.Column_Name%TYPE;
   Lv_Separator         VARCHAR2(1);
   Lv_Substr_Start      NUMBER;
   Lv_Substr_Len        NUMBER;
   Lv_String            VARCHAR2(32760); 
   Lv_Lineno            NUMBER := 0; 
  
   procedure WRITE_OUT(P_Line INTEGER, P_Owner varchar2, P_Name VARCHAR2,  
                       P_String VARCHAR2) is 
   begin 
      insert into VIEW_TEMP (Lineno, Id_Owner, Id_Name, Text)  
             values (P_Line,P_Owner,P_Name,P_String); 
    end; 
  
begin 
   open VIEW_CURSOR; 
   loop 
      fetch VIEW_CURSOR into Lv_Owner, 
                             Lv_View_Name,
                             Lv_Text_Length,      
                             Lv_Text;       
      exit when VIEW_CURSOR%NOTFOUND; 

      Lv_Lineno := 1; 

      Lv_String:= 'CREATE OR REPLACE VIEW ' || LOWER(Lv_Owner) 
                                            || '.' 
                                            || LOWER(Lv_View_Name);
      WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_View_Name, Lv_String); 
      Lv_Lineno := Lv_Lineno + 1; 

      Lv_String := '';
      Lv_Separator := '(';
      open VIEW_COLS_CURSOR (Lv_View_Name, Lv_Owner);

      loop
          fetch VIEW_COLS_CURSOR into Lv_Column_Name;
          exit when VIEW_COLS_CURSOR%NOTFOUND;

          Lv_String := Lv_Separator
                       || Lv_Column_Name;
          Lv_Separator := ',';
          WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_View_Name, Lv_String);
          Lv_Lineno := Lv_Lineno + 1;

      end loop;
      
      Lv_String := ')';
      WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_View_Name, Lv_String);
      Lv_Lineno := Lv_Lineno + 1;
      close VIEW_COLS_CURSOR;
                 
      Lv_string := 'AS';
      WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_View_Name, Lv_String); 
      Lv_Lineno := Lv_Lineno + 1; 

      Lv_Substr_Start := 1;
      Lv_Substr_Len   := Lv_Text_Length;
      if Lv_Substr_Len > 32760
      then 
          Lv_Substr_Len := 32760;
      end if;

      loop
          Lv_String := SUBSTR(Lv_Text,Lv_Substr_Start, Lv_Substr_Len);
          WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_View_Name, Lv_String); 
          Lv_Lineno := Lv_Lineno + 1; 

          Lv_Substr_Start := Lv_Substr_Start + Lv_Substr_Len;
          if (Lv_Substr_Start + Lv_Substr_Len) > Lv_Text_Length
          then 
              Lv_Substr_Len := Lv_Text_Length - 
                               (Lv_Substr_Start + Lv_Substr_Len);
          end if;
          exit when Lv_Substr_Start > Lv_Text_Length;
     end loop;      

      Lv_String  := '/';
      WRITE_OUT(Lv_Lineno, Lv_Owner, Lv_View_Name, Lv_String); 
      Lv_Lineno := Lv_Lineno + 1; 

   end loop; 
   close VIEW_CURSOR; 
end; 
/  
spool cre_view.sql  
select Text 
  from VIEW_TEMP
 order by Id_Owner, Id_Name, Lineno
/
spool off
/

