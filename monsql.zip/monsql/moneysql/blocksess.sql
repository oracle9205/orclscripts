select  substr(a.username,1,8) USERNAME, substr(a.osuser,1,8) OSUSER,
	substr(b.spid,1,6) SRVPID, substr(to_char(a.sid),1,3) SID,
	a.serial# ser#,
	substr(a.module,1,12) Module, substr(a.module,1,12) Action,
	substr(a.status,1,1) stat, substr(a.program,1,25) PROGRAM,
	row_wait_obj#,row_wait_block#,row_wait_file#
	from v$process b, v$session a
	where a.paddr = b.addr
and row_wait_obj# != -1
	order by a.username,b.spid
/
