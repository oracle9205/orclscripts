select name,bytes/1024/1024 "Size in MB" from v$sgastat where name='free memory'
/
