@nlsdate
variable x number;
begin
	:x := sql2u(trunc(sysdate));
end;
/
select batch_id,count(*) r,u2sql(nvl(min(decode(status,'S',time_created)),0)) start_time,
		  u2sql(nvl(max(decode(status,'C',time_created)),2000000000)) complete
from wbatch_log where time_created > :x 
group by batch_id
order by start_time



/
