select name,ow
