col column_name format a22
col constraint_name format a24
select cons.constraint_name,cons.constraint_type type,cols.column_name,cons.r_constraint_name,cons2.table_name r_table_name
	from dba_cons_columns cols,
	dba_constraints cons,
	dba_constraints cons2
	where cons.table_name= upper(rtrim(ltrim('&table_name')))
	      and cols.constraint_name=cons.constraint_name
	      and cons.r_constraint_name=cons2.constraint_name(+)
	order by constraint_name,position
/
