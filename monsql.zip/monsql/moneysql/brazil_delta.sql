create table x3 as select a.sid,a.event,b.total_waits - a.total_waits total_waits
from x1 a, x2 b
where a.sid=b.sid and a.event=b.event
/
