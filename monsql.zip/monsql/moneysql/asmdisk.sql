column name format a25
select name, MOUNT_STATUS, HEADER_STATUS, MODE_STATUS, STATE, PATH, TOTAL_MB, FREE_MB from v$asm_disk
order by group_number;
