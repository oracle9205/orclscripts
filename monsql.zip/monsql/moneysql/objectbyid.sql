select object_name,object_type from dba_objects where object_id=&id
