column sid format 999
column osuser format a10
column wait format a10
column info format a40
column action format a10
column sec format 99
column module format a10
column username format a12
column event format a22
column info format a33
select username,osuser,s.sid,s.sql_address sqladdr,s.logon_time,w.event,module,action,
                    seconds_in_wait sec,
        decode(w.event,'db file sequential read' ,waitinfo.segbyblock(w.p1,w.p2),
                        'direct path write' ,waitinfo.segbyblock(w.p1,w.p2),
                        'direct path read' ,waitinfo.segbyblock(w.p1,w.p2),
                        'free buffer waits' ,waitinfo.segbyblock(w.p1,w.p2),
                        'db file scattered read' ,waitinfo.segbyblock(w.p1,w.p2),
                        'buffer busy waits' ,waitinfo.segbyblock(w.p1,w.p2),
                        'write complete waits' ,waitinfo.segbyblock(w.p1,w.p2),
                        'enqueue' ,waitinfo.segbyblock(s.row_wait_file#,s.row_wait_block#),
                        'latch free',waitinfo.latchbynum(w.p2)||': tries='||to_char(w.p3),
                        'latch activity',waitinfo.latchbynum(w.p2),
                         decode(w.p1text,'','',w.p1text||':'||to_char(w.p1)) ||
                         decode(w.p2text,'','',','||w.p2text||':'||to_char(w.p2)))  info
from v$session_wait w,
     v$sess_io     io,
     v$session      s
        where  s.sid = w.sid and io.sid=w.sid 
        and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
        and username = (select username from v$session where sid=(select distinct sid from v$mystat)) 
        order by event,info
/

prompt enter the SID to terminate. 
prompt (only sessions owned by the same user you are logged into can be killed) 

set serveroutput on ;

exec kill_my_session(&sid2kill);
