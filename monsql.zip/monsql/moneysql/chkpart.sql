column high_value format a15;
column partition_name format a10;
column tablespace_name format a15;
select partition_name, buffer_pool,tablespace_name,high_value, partition_position, num_rows,last_analyzed from dba_tab_partitions
where table_name=upper('&table_name') order by partition_position;
