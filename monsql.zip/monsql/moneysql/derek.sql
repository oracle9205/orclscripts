delete from plan_table ;

explain plan for
create table ken_special3 nologging as
select
        /*+ index(wt,WTRANSACTION_ACCOUNT) */
        ks.counterparty,  
        sum(wt.amount/100) amt_recd
from
        wtransaction wt,
        crystal.ken_special1 ks
where
        wt.account_number = ks.counterparty
        and        
        status = 'S'
        and
        wt.type = 'U'
        and
        wt.amount > 0 
        and
        time_created >= dt_ux
group by
        ks.counterparty;

@plan

rollback ;
