REM Sai => 09/30/09 Written for PPDBA repository live objects.

set ver off
undef table_name
undef dbid
column index_name format a30
column columns format a50
column index_type format a10 heading type
column index_owner for a15
column owner format a10
column tablespace_name format a15
break on index_owner

select c.dbname, b.uniqueness,b.index_type,a.*
from
(select dbid, index_name,index_owner,
        max(decode(column_position,1,column_name,null))||
        max(decode(column_position,2,', '||column_name,null))||
        max(decode(column_position,3,', '||column_name,null))||
        max(decode(column_position,4,', '||column_name,null))||
        max(decode(column_position,5,', '||column_name,null)) columns from 
        (select distinct dbid, table_name, index_name, index_owner, column_name, column_position from pypl_ind_columns 
        where  table_name = upper('&&table_name'))
group by dbid,index_name,index_owner) a,
(select distinct dbid, table_name, owner, index_name, uniqueness, index_type from pypl_indexes 
 where table_name = upper('&&table_name')) b, pypl_databases c
where a.dbid = b.dbid and a.index_name = b.index_name and
a.index_owner=b.owner and b.dbid = c.dbid
order by c.dbname, a.index_owner, a.index_name
/

undef table_name
clear break
