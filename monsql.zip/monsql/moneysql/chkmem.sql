col value format 9999999999999999
col name format a44
select value, n.name|| '('||s.statistic#||')' name, sid   from v$sesstat s , v$statname n    where s.statistic# = n.statistic#    and n.name like '%ga memory%'    order by value; 

select sum(value), sid   from v$sesstat s , v$statname n    where s.statistic# = n.statistic#    and n.name like '%ga memory%'   group by sid order by 1;


select avg(value) from v$sesstat s , v$statname n    where s.statistic# = n.statistic#    and n.name like '%ga memory%';

select sum(value)  from v$sesstat s , v$statname n    where s.statistic# = n.statistic#    and n.name like '%ga memory%';
