set echo on

alter tablespace temp default storage (pctincrease 0 ) ;

set echo off

@tempseg
