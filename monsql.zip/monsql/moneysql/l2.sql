set ver off
set long 50000
select sql_text from pypl_sqltext where sql_id='&sql_id' and rownum=1;
