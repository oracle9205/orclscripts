set doc off
/*=======================================================================
|     Filename : appsess.sql
|     Desc:
|          Displays session information
|          for Oracle Applications                                            
|             !! Will only work if AUDIT is set for USER Level !!     
|             To do this set:                                         
|             navigator(Sys Admin Resp)                               
|              -Profile                                               
|               -System                                               
|                -Find System Profile Values (FORM)                   
|                <enter:(Sign-On:Audit Level) --> search>             
|                 -System Profile Values (FORM)                       
|                 <update SITE column with USER --> save>             
|     Revision
|     --------
|     1.0.0.0     Dhanaji More             Original Release     07/14/99
=======================================================================*/

set pages 0
set feedback off
set verify off
col fnd_name noprint new_value _owner.

--
-- display all sessions within Oracle applications ONLY
--
set pagesize 9999
set linesize 95
set feedback on

clear col
clear breaks

col sid               format 999999      heading "-Sid-"
col serial            format 999999      heading "Serial #"
col o_user            format a10         heading "-Oracle-|User Name"
col os_user           format a10         heading "-  OS  -|User Name"
col logon             format a15         heading "Login Time"
col lastcall          format a15         heading "Last Call"
col status            format a10         heading "Status"
col apps_user         format a10         heading "- Apps -|User Name"

ttitle  "Current Sessions In Oracle Applications"

select     s.sid                                                         sid
,          s.serial#                                                     serial
,          to_char(s.logon_time,'DDth - HH24:MI:SS')                     logon
,          to_char(sysdate - s.last_call_et / 86400,'DDth - HH24:MI:SS') lastcall
,          s.username                                                    o_user
,          s.osuser                                                      os_user
,          s.status                                                      status
,          u.user_name                                                   apps_user
from      v$session  s
,         v$process  p
,         apps.fnd_logins n
,         apps.fnd_user   u
where  s.paddr      = p.addr
and    n.pid        IS NOT NULL
-- and    s.process    = n.spid -- so we don't get hung sessions with old SID and SERIAL
and    p.pid        = n.pid
and    n.user_id    = u.user_id
order by  u.user_name
,         to_char(s.logon_time,'DDth - HH24:MI:SS')
/
ttitle off
