alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
column cctrans_per_sec format 99.99
column avg_delay       format 99.99
column max_delay       format 99.99

select
        u2sql(trunc(time_created/300)*300),
	count(*)/300 cctrans_per_sec,
        avg(decode(time_processed,0,null,time_processed)-time_created) avg_delay,
        max(decode(time_processed,0,null,time_processed)-time_created) max_delay,
	count(*) total_trans,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-5),-1,1,0,1))  under_5_sec,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-5),1,1))  gt_5_sec,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-15),1,1)) gt_15_sec,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-30),1,1)) gt_30sec,
        count(decode(time_processed,0,1,null)) pending
from wcctrans
where id > (select max(id)-30000 from wcctrans)
group by trunc(time_created/300)*300
/

select
        u2sql(trunc(time_created/10)*10),
	count(*)/10 cctrans_per_sec,
        avg(decode(time_processed,0,null,time_processed)-time_created) avg_delay,
        max(decode(time_processed,0,null,time_processed)-time_created) max_delay,
	count(*) total_trans,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-5),-1,1,0,1))  under_5_sec,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-5),1,1))  gt_5_sec,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-15),1,1)) gt_15_sec,
        count(decode(sign(decode(time_processed,0,null,time_processed)-time_created-30),1,1)) gt_30sec,
        count(decode(time_processed,0,1,null)) pending
from wcctrans
where id > (select max(id)-1000 from wcctrans)
group by trunc(time_created/10)*10
/

