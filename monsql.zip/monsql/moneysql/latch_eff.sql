select 'cached cursor efficiency',(1-(l.gets/s.value))*100,9
  from v$librarycache l,
       v$sysstat s,
       v$parameter p
 where l.namespace='SQL AREA'
   and s.name in ('parse count','parse count (total)')
   and p.name='session_cached_cursors'
   and p.value != '0'
/
