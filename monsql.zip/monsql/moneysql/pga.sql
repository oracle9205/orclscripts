select se.sid, se.username, se.terminal, se.program, st.value/1000 as "PGA in KB"
from v$session se, v$sesstat st
where st.statistic#=20 and
st.sid=se.sid and se.username is not null order by se.username
/
