column name format a30
select n.name , c.* from
	(select ts#,count(*) blocks , sum(dirty_queue) dirty from bh group by ts#) c,
	sys.ts$ n
where n.ts#=c.ts#
order by blocks
/
