select wuser.first_name, wuser.last_name, totals.* from
wuser,
(select counterparty,count(*) count, sum(amount)
 from wtransaction 
group by counterparty
having count(*) > 100
) totals
where wuser.account_number=totals.counterparty
/

