select s.sql_address, s.prev_sql_addr,u.name||'.'||o.name locked_object,username locker,s.sid,l.type,
    decode(lmode,1,NULL,2,'Row Share',3,
           'Row Exc',4,'Share',5,
           'Shr Row Exc',6,
           'Exc') "LOCK TYPE",
    request request_ty
    from v$lock l, v$session s, sys.obj$ o,sys.user$ u
    where s.sid = l.sid
      and s.username <> 'SYS'
      and o.obj# = id1
      and o.owner#=u.user#
    order by username ,o.owner#,o.name
/
