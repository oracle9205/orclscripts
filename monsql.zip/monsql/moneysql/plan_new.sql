select bytes,lpad(' ',2*level)||operation||' '||options
       ||' '||object_name||' '||object_node query_plan,object_name
from (select * from  plan_table where statement_id='&hash_value')
where statement_id='&hash_value'
connect by prior id = parent_id
start with id = 0
/
