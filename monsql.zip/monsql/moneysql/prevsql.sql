select ses.sid,sql.sql_text from v$sqltext_with_newlines sql,v$session ses
	where sql.address =  ses.prev_sql_addr
	and ses.sid in ( &SIDLIST )
	order by sid, sql.piece
/
