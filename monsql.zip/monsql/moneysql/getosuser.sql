set termout on
column osuser format a20
column username format a10
column program format a8
column spid format a7
column sql_text format a35
SELECT a.osuser, a.username, a.program, c.spid "OS PID", b.sql_text
from v$session a, v$sqltext b, v$process c
where a.sql_address =b.address
and a.paddr = c.addr
and a.username =upper('&username') 
order by a.osuser, c.spid, b.address, b.hash_value, b.piece
;
set termout off
