---------------
-- QUERY TO LIST CURRENTLY RUNNING BATCHES
-- Use batch_id from this query in @batch_hist to find history of that particular batch.
-- 12/3/01  SJ
--
---------------

col Batch_Name format a40

select a.id, a.batch_id, a.batch_num, a.status, to_char(u2sql(a.time_created),'MM/DD/YY HH24:MI') Start_Time , sql2u(sysdate)-a.time_created "Time_Running(Secs)" , a.parent_id, a.command_line Batch_Name from wbatch_log a 
where a.time_created <= sql2u(sysdate)
and a.time_created >= sql2u(trunc(sysdate-1))
and a.status='S'
and not exists ( 
select 'x' from wbatch_log inner 
where 
 inner.parent_id = a.id );

