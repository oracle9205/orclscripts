col object   for A34
col owner    for A16  trunc
col type     for A12  head  Obj|type
col accessed for 9999 head "Accessed|by # users"

select A.owner,A.object,A.TYPE,count(*) accessed
from   v$ACCESS  A
where  A.owner not in ('SYS','SYSTEM')
and    A.TYPE = 'TABLE'
group by A.owner,A.object,A.TYPE
order by accessed
/

