--select  * from dba_segments where header_File=&file_number and header_block=&block_no 

select decode(segment_type,'TABLE',segment_name,
                           'TABLE PARTITION','part:' || partition_name) obj_name
        from dba_segments
        where header_file = &file_no and
              header_block= &block_no
/
