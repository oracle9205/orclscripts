select ' drop table '|| owner || '.' || segment_name || ' ; ' from dba_segments where segment_name like upper('&segname') order by segment_name
/
