
set serveroutput on ;

DECLARE

owner     varchar2(30);
name      varchar2(30);
seg_type  varchar2(30);
tblock    number;
tbyte     number;
uBlock    number;
ubyte     number;
lue_fid   number;
lue_bid   number;
lublock   number;

BEGIN


     dbms_space.unused_space (upper('&Owner'),upper('&Index_name'),'INDEX',tblock,tbyte,ublock,ubyte,lue_fid,lue_bid,lublock) ;

     dbms_output.put_line('------------------------------------------------------------') ;

     dbms_output.put_line(' Total Blocks allocated to the index    = ' || to_char (tblock) ) ;

     
     dbms_output.put_line(' Total Bytes allocated to the index     = ' || to_char (tbyte) ) ;

     
     dbms_output.put_line(' Unused Blocks (above High Water Mark)  = ' || to_char (ublock) ) ;


     dbms_output.put_line(' Unused Bytes (above High Water Mark)   = ' || to_char (ubyte) ) ;


     dbms_output.put_line(' Last Extent used file id               = ' || to_char (lue_fid) ) ;


     dbms_output.put_line(' Last Extent used begining block id     = ' || to_char (lue_bid) ) ;


     dbms_output.put_line(' Last used block in last extent         = ' || to_char (lublock) ) ;


     dbms_output.put_line('------------------------------------------------------------') ;


END ;
/

