col MAXTIME format a15
col SAMPLE_TIME format a26
col BLOCKING_SESSION format 99999999
col event format a25
col AVGTIME format a15
select a.sample_time, a.BLOCKING_SESSION,b.event,a.BLOCKING_SESSION_STATUS,a.BLOCKING_HANGCHAIN_INFO, a.event, count(*), round(max(a.TIME_WAITED)/1000,2)||' ms' maxtime,round(avg(a.TIME_WAITED)/1000,2)||' ms' avgtime
from &ash a, &ash b 
where a.sample_time=b.sample_time and b.SESSION_ID=a.BLOCKING_SESSION 
group by a.sample_time,a.BLOCKING_SESSION,a.BLOCKING_SESSION_STATUS,b.event,
a.BLOCKING_HANGCHAIN_INFO,a.event order by a.sample_time ;
