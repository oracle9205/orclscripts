REM Sai => print_table pl/sql procedure to display sqlplus resultset in column to row format.
set ver off
set serverout on

exec print_table('select * from &table_name where &col_where=&pred and &col2=&pred2');
