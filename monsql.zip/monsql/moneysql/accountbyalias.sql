column alias format a40
select wu.account_number,wu.first_name,wu.last_name,wua.alias
	 from wuser wu, wuser_alias wua
where wu.account_number=wua.account_number
and bitand(wua.flags,1)=1
and wua.alias_upper=upper('&name')
/
