--
-- script to identify who is holding a library cache lock
-- and thus blocking another session.  prompts for the sid of the
-- session being blocked (find it using waits.sql)
-- informatin from metalink article: 122793.1
--
-- 2002 kcg
--

SELECT SID,USERNAME,TERMINAL,PROGRAM FROM V$SESSION
WHERE SADDR in
(SELECT KGLLKSES FROM X$KGLLK LOCK_A
WHERE KGLLKREQ = 0
AND EXISTS (SELECT LOCK_B.KGLLKHDL FROM X$KGLLK LOCK_B
WHERE KGLLKSES = (SELECT saddr FROM v$session WHERE sid = &sid)
AND LOCK_A.KGLLKHDL = LOCK_B.KGLLKHDL
AND KGLLKREQ > 0)
)
/

