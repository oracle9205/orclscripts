REM Rewrote the lw script for 10g and above.
REM Sai -> 04/17/2008
REM Added blocking session info for 11g
REM Sai -> 06/14/2011

set trimspool on
set lines 199
set pages 1000
set arraysize 100
col "SID:BOX" for a18
col blk_sid for 99999
col "SQL_ID" for a13
col "EVENT#:P1:P2:P3:WAITING_STATUS" for a57
col "MODULE:CALL_TIME_SEC" for a19


select
s.sid||':'||s.machine "SID:BOX",
s.final_blocking_session blk_sid,
nvl(s.sql_id, s.prev_sql_id) "SQL_ID",
i.block_gets+i.consistent_gets gets,
s.event#||':'||substr(s.event, 1, 16)||': '||s.p1||':'||s.p2||':'||s.p3||':'||
decode(wait_time, 0, 'WAIT:'||(round(wait_time_micro/1000)), 
'CPU:'||(round(wait_time_micro/1000))) "EVENT#:P1:P2:P3:WAITING_STATUS",
case when length(module) > 11 then substr(module, -11) else module end||':'||
case when s.last_call_et < 86400 then round(s.last_call_et/60) else null end||':'||command "MODULE:CALL_TIME_SEC"
from
v$session s, v$sess_io i
where
s.sid = i.sid and
s.status = 'ACTIVE' and
((s.event not in ('rdbms ipc message', 'pmon timer', 'smon timer', 'jobq slave wait') and s.type <> 'BACKGROUND') or
 (s.wait_class <> 'Idle' and s.type = 'BACKGROUND'))
order by s.event#, nvl(s.sql_id, s.prev_sql_id)
/
