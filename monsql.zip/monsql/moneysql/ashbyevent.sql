REM Ash report about active session count per every wait event for a given time range.
REM All time metrics are in seconds except where mentioned explicitly
REM Sai => 06/14/11

set lines 199
set pages 40
set ver off
alter session set nls_date_format = 'MM/DD HH24:MI:SS';

col cnt for 9999999
col max_time_ms for 99999
col avg_time_ms for 99999
col p1 for 99999999999999
col p1_cnt for 999
col p2_cnt for 999
col p3_cnt for 999
col obj_cnt for 999
col obj_id for 999999
col locks for 999

select
 stime, top_sql, cnt, total_time, max_time_ms,avg_time_ms, p1, p1_cnt, p2_cnt, p3_cnt,
 obj_cnt, obj_id, locks
from
(
select
 stime,
 first_value(sql_id ) over (partition by (case when sql_id is not null then stime end) order by cnt desc) top_sql,
 row_number() over (partition by (case when sql_id is not null then stime end) order by cnt desc) rn,
 sum(cnt) over (partition by stime) cnt,
 sum(total_time) over(partition by stime) total_time,
 max(max_time_ms) over(partition by stime) max_time_ms,
 round(avg(avg_time_ms) over(partition by stime)) avg_time_ms,
 max(p1) over (partition by stime) p1,
 count(distinct p1) over (partition by stime) p1_cnt,
 count(distinct p2) over (partition by stime) p2_cnt,
 count(distinct p3) over (partition by stime) p3_cnt,
 count(distinct CURRENT_OBJ#) over (partition by stime) obj_cnt,
 max(CURRENT_OBJ#) over (partition by stime) obj_id,
 sum(blockers) over (partition by stime) as locks
from
(
select 
 to_date(to_char(sample_time, 'MM/DD')||' '||to_char(sample_time, 'HH24')||':'||
 to_char(sample_time, 'MI')||':'||
 to_char(sample_time, 'SS'), 'MM/DD HH24:MI:SS') as stime,
 sql_id,
 p1,p2,p3,CURRENT_OBJ#,
 count(*) as cnt,
 round(sum(time_waited)/1000000) as total_time,
 round(max(time_waited)/1000) as max_time_ms,
 round(avg(time_waited)/1000) as avg_time_ms,
 count(BLOCKING_SESSION) blockers
from &&ash_table
where
sample_time between
 to_date(to_char(&&sysdate_value, 'MM/DD')||' '||('&&HH24_MI_SS_1'), 'MM/DD HH24_MI_SS')
 and
 to_date(to_char(&&sysdate_value, 'MM/DD')||' '||('&&HH24_MI_SS_2'), 'MM/DD HH24_MI_SS')
and lower(event) like lower('%&&event_name%')
group by
 to_date(to_char(sample_time, 'MM/DD')||' '||to_char(sample_time, 'HH24')||':'||
 to_char(sample_time, 'MI')||':'||
 to_char(sample_time, 'SS'), 'MM/DD HH24:MI:SS'),
 sql_id, p1,p2,p3,CURRENT_OBJ#
))
where rn=1 and top_sql is not null
order by stime
/

