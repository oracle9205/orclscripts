rem ********************************************************************
rem * Filename		: apstitle.sql - Version 1.7
rem * Author		: Cary Millsap and Willis Ranney
rem * Original		: 1991
rem * Last Update	: 1/16/96 - 08:27:24
rem * Description	: Standard APS title header
rem * Usage		: start apstitle.sql
rem ********************************************************************

set termout off
break on today
col today new_value now
select to_char(sysdate, 'YYYY Mon DD HH:MIam') today 
from   dual;

col val1 new_value db noprint
select value val1 
from   v$parameter 
where  name = 'db_name';

clear breaks
set termout on
set heading on

ttitle -
    left 'Database: &db'        right now              skip 0 -
    left 'Report:   &aps_prog'  right 'Page ' sql.pno  skip 2 -
    center '&aps_title'                                skip 3

