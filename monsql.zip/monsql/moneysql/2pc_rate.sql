prompt "recoman"
select executions/((sysdate-to_date(first_load_time,'yyyy-mm-dd/hh24:mi:ss'))*86400)
from v$sqlarea where hash_value =2943463743
/
prompt "2pc"
select executions/((sysdate-to_date(first_load_time,'yyyy-mm-dd/hh24:mi:ss'))*86400)
from v$sqlarea where hash_value =1547085363
/
