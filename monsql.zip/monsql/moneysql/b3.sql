select segment_name,segment_type,partition_name
from dba_extents
where
file_id=526
and
1 between block_id and (block_id+blocks-1)
/
