------ Before you run the script, please make sure that /x/home/oracle/bin directory exists and 
------ freecon log files are named in uppercase as FREE_CON.log, FREE_CON_EX.log, etc
------- otherwise you may need to edit the following script accordingly


set echo on

spool ppdba.log

create user ppdba identified by values 'B43F55B3FCEE16A7';
grant select any dictionary to ppdba;
grant dba to ppdba;

create or replace directory ppdba_dir as '/x/home/oracle/bin';

create table ppdba.pypl_freecon (
date1 varchar2(1000)
)
organization external
(type oracle_loader
 default directory ppdba_dir
 access parameters
  (
   records delimited by newline
   nobadfile
   nologfile
   nodiscardfile
   fields terminated by '\n'
   missing field values are null
 (DATE1)
  )
 location ('FREE_CON.log')
)
reject limit unlimited;


create table ppdba.pypl_freecon_ex (
date1 varchar2(1000)
)
organization external
(type oracle_loader
 default directory ppdba_dir
 access parameters
  (
   records delimited by newline
   nobadfile
   nologfile
   nodiscardfile
   fields terminated by '\n'
   missing field values are null
 (DATE1)
  )
 location ('FREE_CON_EX.log')
)
reject limit unlimited;

create table ppdba.pypl_os_info(date1 varchar2(1000))
organization external 
(type oracle_loader 
default directory ppdba_dir 
access parameters 
( 
records delimited by newline 
nobadfile 
nologfile 
nodiscardfile 
fields terminated by '\n' 
missing field values are null 
(DATE1) 
) 
location ('pypl_os_info.txt') 
) 
reject limit unlimited;

create table ppdba.pypl_freecon_sql (
date1 varchar2(1000)
)
organization external
(type oracle_loader
 default directory ppdba_dir
 access parameters
  (
   records delimited by newline
   nobadfile
   nologfile
   nodiscardfile
   fields terminated by '\n'
   missing field values are null
 (DATE1)
  )
 location ('FREE_CON_SQL.log')
)
reject limit unlimited;

create table ppdba.pypl_freecon_wait (
date1 varchar2(1000)
)
organization external
(type oracle_loader
 default directory ppdba_dir
 access parameters
  (
   records delimited by newline
   nobadfile
   nologfile
   nodiscardfile
   fields terminated by '\n'
   missing field values are null
 (DATE1)
  )
 location ('FREE_CON_WAIT.log')
)
reject limit unlimited;

create table ppdba.pypl_freecon_latch (
date1 varchar2(1000)
)
organization external
(type oracle_loader
 default directory ppdba_dir
 access parameters
  (
   records delimited by newline
   nobadfile
   nologfile
   nodiscardfile
   fields terminated by '\n'
   missing field values are null
 (DATE1)
  )
 location ('FREE_CON_LATCH.log')
)
reject limit unlimited;

create table ppdba.pypl_dba_alerts (
date1 varchar2(1000)
)
organization external
(type oracle_loader
 default directory ppdba_dir
 access parameters
  (
   records delimited by newline
   nobadfile
   nologfile
   nodiscardfile
   fields terminated by '\n'
   missing field values are null
 (DATE1)
  )
 location ('dba_alerts.txt')
)
reject limit unlimited;

spool off
