select s.sid,s.username,s.module,i.block_gets,i.consistent_gets cons_get,
	i.physical_reads phy_read,i.block_changes blk_chng,
	i.consistent_changes cons_chng  from v$sess_io i,
	v$session s
	where i.sid=s.sid
	and s.username = 'IVR_INTERFACE'
/
