-- if request_failures > 0 and last_failure_size is > shared_pool_reserved_min_alloc, there is 
-- a lack of contigious space in the shared pool reserved space and so consider increasing shared_pool_reserved_min_alloc
-- to lower the number of objects cached into the shared pool reserved space & increase the shared_pool_reserved_size and shared_po--- size to increase the available memory in the shared pool reserved space.


-- if request_failures > 0 and last_failure_size is < shared_pool_reserved_min_alloc, consider lowering
-- shared_pool_min_alloc to put more objects into the shared pool reserved space and increase shared_pool_size


select free_space, avg_free_size, used_space, avg_used_size, request_failures, last_failure_size from v$shared_pool_reserved 
/
