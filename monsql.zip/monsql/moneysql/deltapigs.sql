select address,executions,disk_reads,
      (buffer_gets-disk_reads)/(buffer_gets+1) hit_ratio,
      buffer_gets /decode(executions,0,1,executions) avg_gets,
      disk_reads  /decode(executions,0,1,executions) avg_disk_reads,
      substr(sql_text ,1,60)
   from
      (select a.address,a.executions - b.executions executions, a.disk_reads-b.disk_reads disk_reads, a.buffer_gets-b.buffer_gets buffer_gets,
              a.sql_text sql_text from sqlarea_b b, sqlarea_a a
              where a.address=b.address)
where executions > 1000
  order by executions asc
/
