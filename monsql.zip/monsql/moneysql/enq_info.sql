col enq_info format a45
col waiting_for format a66
select s.sid, 
       waitinfo.segbyblock(s.row_wait_file#,s.row_wait_block#) waiting_for, 
       dbms_rowid.rowid_create(1,s.row_wait_obj#,s.row_wait_file#,s.row_wait_block#,ROW_WAIT_ROW#) object__rowid
from v$session s, 
     v$session_wait w
where
    s.status='ACTIVE'
and s.sid   =w.sid
and w.event ='enqueue'
/
