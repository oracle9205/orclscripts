----------------------
-- Script to find out Tables/Indexes created within the 
-- input No of days.  
-- (1/29/02) - SJ
----------------------

set echo off
col object_name format a34
col object_type format a10
col owner format a14

select d.object_name, d.object_type, d.owner, s.tablespace_name, s.bytes, to_char(d.created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects d, dba_segments s  
where 
d.created > ( sysdate - &No_of_days_old ) 
and d.object_type in ('TABLE', 'INDEX') 
and d.owner not in ('SYSTEM','SYS') 
and d.object_name=s.segment_name
order by d.created, d.owner, d.object_type
/
