select status, count(*) from v$backup group by status ;
