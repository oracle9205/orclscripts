set lines 160
col obj for a70
col cmd for a18
col module for a28
select obj, cmd, count(*) as ses_cnt, min(sql_hash_value) hash, module
from (select
       decode(ROW_WAIT_OBJ#,241258,'WUSER',358359,'WTRANSACTION',2236,'WUOME',2065,'WUSER_CC',1998,'WADMIN',76038,
              'WUSER_STATS',2053,'WUSER_ACH',36689,'WUSER_PASSWORD',2057,'WUSER_ADDRESS',2030,'WCCTRANS',
              315451,'WTRANSACTION',358201,'WTRANSACTION',-1,null,row_wait_obj#)||':'||w.event||':'||w.p1raw||':'||w.p2||':'||w.p3||
              ':'||chr(bitand(p1,-16777216)/16777215)||chr(bitand(p1,16711680)/65535) as obj,
       decode(command,2,'INSERT',6,'UPDATE',7,'DELETE',182,'UPDATE INDEXES',3,'SELECT FOR UPDATE',command) as cmd,
       sql_hash_value,
       module
       from v$session s, v$session_wait w
       where status='ACTIVE' and lockwait is not null and s.sid=w.sid)
group by obj, cmd, module
order by 3,1
/
