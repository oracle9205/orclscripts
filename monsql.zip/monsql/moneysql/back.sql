update wcommercial_entity_reg set status_code=9999 where account_number in (1360860920470674561, 2206471224188547321,1963141535950524031);
commit;

