delete from plan_table  ;
explain plan for
select
        trunc(time_created/15)*15        time_created,
        u2sql(trunc(time_created/15)*15)        oracle_time,
        nvl(count(decode(type,'U',1)),0)  PAYMENTS,
        round(nvl(count(decode(type,'U',1)),0)/15)  "PAYMENTS/SEC",
        nvl(count(decode(type,'R',1)),0)  CHARGES
        from wtransaction wt where
        base_id=id
        and    ((type  = 'U' and status in ('S','P')  and amount<0)
                or
                (type  = 'R' and status = 'S'))
        and base_id > (select max(base_id)-30000 from wtransaction)
        group by trunc(time_created/15)*15
/
@plan
