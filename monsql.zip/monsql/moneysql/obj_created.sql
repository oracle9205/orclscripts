-- LIST THE OBJECTS CREATED WITHIN THE LAST --(INPUT NUMBER) OF DAYS.


col object_name format a34
col object_type format a18
col owner format a22 
set echo off

select object_name, object_type, owner, status, to_char(created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects  where created > ( sysdate - &No_of_days_old ) order by created, owner, object_type ;
