select obj.name from sys.obj$ obj, sys.tab$ tab
        where obj.obj# = tab.obj#
        and tab.file# = &f 
        and tab.block# = &b
/
