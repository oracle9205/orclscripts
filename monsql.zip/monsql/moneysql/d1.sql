alter session set sort_area_size=300000000;

create table temp_special nologging as
select
        /*+ index(wt,WTRANSACTION_ACCOUNT) */
        count(ks.counterparty) count_1  
from
        wtransaction wt,
        crystal.ken_special1 ks
where
        wt.account_number = ks.counterparty
        and        
        status = 'S'
        and
        wt.type = 'U'
        and
        wt.amount > 0 
        and
        time_created >= dt_ux
/

exit
