col osuser format a10
col machine format a10
col module format a10
select username,s.sid,s.sql_hash_value, w.event,module,io.block_gets+io.consistent_gets gets,
                    w.seconds_in_wait sec,
                    w.p1, w.p2, w.p3
from v$session_wait w,
     v$sess_io     io,
     v$session      s
        where  s.sid = w.sid and io.sid=w.sid and
        s.status='ACTIVE'
        and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
        order by event
/

