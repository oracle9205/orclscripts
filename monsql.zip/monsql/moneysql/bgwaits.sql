column sid format 999
column program format a22
column event format a25
column wait format a9
column seq# format 999999

select s.sid,s.program,w.event,
	decode(w.state,'WAITING','WAIT'
		    ,'WAITED KNOWN TIME',to_char(w.wait_time/100)
		    ,'WAITED SHORT TIME','SHORT'
		    ,'WAITED UNKNOWN TIME','?'
		    ,w.state) wait,
			w.seq#,
		    seconds_in_wait seconds,
			 w.p1text||':'||to_char(w.p1) ||
			 w.p2text||':'||to_char(w.p2) ||
			 w.p3text||':'||to_char(w.p3) info
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where  s.sid = w.sid and io.sid=w.sid and
	s.status='ACTIVE'
	and s.username is null
	order by program 
/
