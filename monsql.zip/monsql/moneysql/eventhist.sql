column startval format 999,999,999,999
column endval format 999,999,999,999
column delta format 999,999,999
column name format a30
column per_second format 999,999.99
column average_ms format 999.99
select to_char(snap.SNAP_TIME,'HH24:MI:SS'), stat1.snap_id,stat1.event,
	stat1.total_waits-stat2.total_waits waits,
	stat1.time_waited -stat2.time_waited time_waited,
	10* (stat1.time_waited -stat2.time_waited)/decode((stat1.total_waits-stat2.total_waits),0,1,(stat1.total_waits-stat2.total_waits)) average_ms
  from 
	stats$system_event stat1,
	stats$system_event stat2,
	stats$snapshot snap 
where stat1.event like '%&statname%'
	and stat1.snap_id > (select max(snap_id)-30 from stats$snapshot ) 
	and stat2.snap_id=stat1.snap_id-1
	and stat2.event=stat1.event
	and stat1.snap_id=snap.snap_id
order by stat1.event, stat1.snap_id asc
/

