host perl -e 'print 0x&value . "\n";'
