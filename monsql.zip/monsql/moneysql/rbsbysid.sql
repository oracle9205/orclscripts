select r.name,s.username, s.sid,s.serial#,p.spid "Os/pid",io.block_gets+io.consistent_gets reads,s.status
    from v$transaction t, v$rollname r, v$session s,v$process p,v$sess_io io
    where t.addr = s.taddr
    and s.sid = io.sid
    and p.addr = s.paddr
    and t.xidusn = r.usn
	and s.sid in (&sidlist)
    order by r.name,s.username
/
