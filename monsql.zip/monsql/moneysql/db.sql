col global_name format a22

select * from global_name ;
