col object_name format a24
col Obj_Type format a10
col oracle_username format a18
col os_user_name format a14


select  l.xidusn rbs_seg, 
	l.object_id, 
	o.object_name,
	o.object_type Obj_Type,
	l.session_id SID, 
	l.oracle_username, 
	l.os_user_name,
	l.process os_pid,
	decode(locked_mode,
                0, 'None',           /* Mon Lock equivalent */
                1, 'Null',           /* N */
                2, 'Row-S (SS)',     /* L */
                3, 'Row-X (SX)',     /* R */
                4, 'Share',          /* S */
                5, 'S/Row-X (SSX)',  /* C */
                6, 'Exclusive'      /* X */) Lock_Mode
   from   v$Locked_object l, 
	  dba_objects o 
   where l.object_id=o.object_id 
   order by object_name, oracle_username
/
