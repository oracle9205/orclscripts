column concurrent_program_name format a20 
column user_concurrent_program_name format a55
column phase_code format a10
column status_code format a10
column avg_time format 9999.99
column longest_time format 9999.99
column shortest_time format 9999.99

select period, sum(delta)/count(*) Avg_time, max(delta) longest_time, min(delta) shortest_time, count(success) success, count(errors) errors,count(other) other_status from 
(
select to_char(fcr.requested_start_date,'MM/DD Day')||decode(to_char(fcr.requested_start_date,'HH24') ,
	'00',' early', '01',' early', '02',' early', '03',' early', '04',' early', '05',' early',
	'06',' morning', '07',' morning', '08',' morning', '09',' morning', '10',' morning', '11',' morning',
	'12','Afternoon', '13','Afternoon', '14','Afternoon', '15','Afternoon', '16','Afternoon', '17','Afternoon',
	'18','Evening', '19','Evening', '20','Evening', '21','Evening', '22','Evening', '23','Evening') period,
    (fcr.actual_completion_date-fcr.actual_start_date)*24*60*60 delta,
    decode(fcr.status_code,'C',1,null) success,
    decode(fcr.status_code,'E',1,null) errors,
    decode(fcr.status_code,'E',null,'C',null,1) other
      from
            apps.fnd_concurrent_programs fcp,
            apps.fnd_concurrent_requests fcr
      where
            fcp.concurrent_program_id = fcr.concurrent_program_id
     and
    fcp.application_id = fcr.program_application_id
     and
    fcp.user_concurrent_program_name='NetFlix Order Import'
)
group by period
/
