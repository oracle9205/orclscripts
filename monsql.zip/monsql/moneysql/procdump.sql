undef sid
undef spid
select spid from v$session a, v$process b
where a.sid=&&sid and a.paddr=b.addr;

oradebug setospid &&spid
oradebug dump processstate 10
oradebug tracefile_name

