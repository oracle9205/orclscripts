accept suffix prompt 'suffix: ';
create table bh_&suffix as select dbarfil,dbablk,dirty_queue from bh
/

drop synonym bh_prev
/

create synonym bh_prev for  bh_&suffix
/
