 select s.sid
 from v$session_wait w,
    v$sess_io     io,
    v$session         s
    where  s.sid = w.sid and io.sid=w.sid and
    w.event='enqueue'
    and username = 'CONFAPP'
  and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer') ;
