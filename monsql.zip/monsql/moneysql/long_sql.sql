select sql_text from v$sqltext_with_newlines where hash_value = 3236165231 order by piece 
/
