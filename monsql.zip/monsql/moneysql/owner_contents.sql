col object_name format a30
select d.object_name, d.object_type, d.owner, s.tablespace_name, s.bytes, to_char(d.created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects d, dba_segments s
where
d.object_name=s.segment_name
and d.object_type != 'SYNONYM'
and s.tablespace_name=upper('&tspace_name')
and d.owner in upper('&owner')
order by d.created desc , d.owner, d.object_type
/
