column segment_name format a15

select ext.segment_name, ext.tablespace_name,count(*) tot_ext,sum(bytes) tot_byte
	from dba_extents ext
	where segment_type = 'ROLLBACK'
	group by segment_name,tablespace_name;

select tablespace_name,sum(bytes) "total free space",max(bytes) "largest extent"
	from dba_free_space where tablespace_name in 
	(select distinct tablespace_name from dba_rollback_segs)
	group by tablespace_name ;
