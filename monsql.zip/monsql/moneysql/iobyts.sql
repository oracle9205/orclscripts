column file_name format a50
select 	df.file_name,
	df.bytes/(1024*1024*1024) filesize,
	fs.phyrds phyrds,
	fs.phywrts phywrts,
	fs.phyblkrd phyblkrd,
	fs.phyblkwrt phyblkwrt,
	fs.avgiotim avgiotim
from
	dba_data_files df,
	v$filestat fs
where
	fs.file#=df.file_id
	and tablespace_name = upper('&tablespace')
order by phyblkrd asc
/
