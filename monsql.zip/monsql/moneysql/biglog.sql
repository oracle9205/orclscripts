column megabytes format 999,999,999
select to_char(first_time,'MM/DD HH24')||':00' hour,
count(*) num_logs,sum(next_change#-first_change#) changes,
sum(next_change#-first_change#)*1.0/count(*)*1.0 changes_per_log,
min(sequence#) first_log_id,
max(sequence#) last_log_id,
sum(block_size*blocks)/(1024*1024) Megabytes
from v$archived_log
group by to_char(first_time,'MM/DD HH24')
having  sum(block_size*blocks) > 1000000000
/
