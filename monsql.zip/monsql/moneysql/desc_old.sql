col file_name format a44
col "Resize_Command" format a96

accept tspace_name prompt 'Enter the Tablespace Name:'

column used_space format 99,999,999,999
column free_space format 99,999,999,999
column total_space format 99,999,999,999
column largest_extent format 99,999,999,999
column tablespace_name format a25
column pctfull format 999
select t.tablespace_name,t.total_space,
        nvl(f.free_space,0) free_space, 
        nvl(f.largest_extent,0) largest_extent,
        total_space-nvl(f.free_space,0) used_space,
        (total_space-nvl(f.free_space,0))*100/total_space pctfull
  from
   (select tablespace_name, sum(bytes)/(1024*1024) total_space  
        from dba_data_files group by tablespace_name ) t,
   (select tablespace_name, sum(bytes)/(1024*1024) free_space,
        max(bytes)/(1024*1024) largest_extent
        from dba_free_space group by tablespace_name)  f
        where t.tablespace_name=f.tablespace_name (+)
              and t.tablespace_name=upper('&tspace_name')
/

select
       DB.Tablespace_name,
       sum(FS.Phyblkrd) Blocks_Read,
       sum(FS.Phyblkwrt) Blocks_Written,
       sum(FS.Phyblkrd+FS.Phyblkwrt) Total_IOs,
       sum(((FS.Phyblkrd+FS.Phyblkwrt)/ab.tot)*100) "Percent of Total D/B I/O"
  from V$FILESTAT FS, V$DATAFILE DF, dba_data_files DB,
       ( Select sum(f.phyblkrd + f.phyblkwrt) tot
         from v$filestat f, v$datafile d
         where f.file#=d.file# ) ab
 where DF.File#=FS.File#
       and DF.file# = DB.file_id
       and DB.Tablespace_name like upper('&tspace_name')
 group by DB.Tablespace_name
/

select a.file_name,a.bytes "Allocated Bytes" , mx.new_size "Used Bytes", a.bytes-mx.new_size "Unused Bytes", (a.bytes-mx.new_size)/(1024*1024) "Free_space in megs"
  from
  dba_data_files a,
  (select file_id,max(block_id+blocks)*8*1024 new_size from dba_extents where tablespace_name=upper('&tspace_name')
  group by file_id) mx
  where a.file_id=mx.file_id
/

select ' Alter database datafile ''' || a.file_name || ''' resize '|| mx.new_size || ' ; ' as "Resize_Command"
  from
  dba_data_files a,
  (select file_id,max(block_id+blocks)*8*1024 new_size from dba_extents where tablespace_name=upper('&tspace_name')
  group by file_id) mx
  where a.file_id=mx.file_id
/

set verify off
