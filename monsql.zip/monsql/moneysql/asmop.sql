select * from v$asm_operation;
