alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';

select SAMPLE_TIME, event, count(*) from v$active_session_history where sample_time>to_timestamp(sysdate-(&min*(1/1440)), 'DD-MON-YYYY HH24:MI:SS') group by SAMPLE_TIME, event having count(*)>200 order by 1,3;

