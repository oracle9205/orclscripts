column used_space format 99,999,999,999
column free_space format 99,999,999,999
column total_space format 99,999,999,999
column largest_extent format 99,999,999,999
column tablespace_name format a25
column pctfull format 999
set pagesize 110

select t.tablespace_name,t.total_space,
	nvl(f.free_space,0) free_space, 
	nvl(f.largest_extent,0) largest_extent,
	total_space-nvl(f.free_space,0) used_space,
	(total_space-nvl(f.free_space,0))*100/total_space pctfull
  from
   (select tablespace_name, sum(bytes)/(1024*1024) total_space  
	from dba_data_files group by tablespace_name ) t,
   (select tablespace_name, sum(bytes)/(1024*1024) free_space,
	max(bytes)/(1024*1024) largest_extent
	from dba_free_space group by tablespace_name)  f
	where t.tablespace_name=f.tablespace_name (+)
/

select sum(t.total_space) total_space ,
        sum(nvl(f.free_space,0)) free_space,
        sum(total_space-nvl(f.free_space,0)) used_space
  from
   (select tablespace_name, sum(bytes)/(1024*1024) total_space
        from dba_data_files group by tablespace_name ) t,
   (select tablespace_name, sum(bytes)/(1024*1024) free_space,
        max(bytes)/(1024*1024) largest_extent
        from dba_free_space group by tablespace_name)  f
        where t.tablespace_name=f.tablespace_name (+)
/
