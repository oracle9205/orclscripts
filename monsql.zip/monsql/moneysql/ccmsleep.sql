select  substr( s.program,1,25) program,s.sid,seq#,substr(module,instr(module,'/',-1)+1) module,w.event,
	decode(w.state,'WAITING','WAIT'
		    ,'WAITED KNOWN TIME',to_char(w.wait_time/100)
		    ,'WAITED SHORT TIME','SHORT'
		    ,'WAITED UNKNOWN TIME','?'
		    ,w.state) wait,
		    seconds_in_wait seconds,
	decode(w.p1text,'file#' ,waitinfo.segbyblock(w.p1,w.p2),
			'latch#',waitinfo.latchbynum(w.p1),
			         w.p1text||' '||to_char(w.p1)) info
from v$session_wait w,
     v$session	    s
	where s.sid = w.sid
	and w.event = 'PL/SQL lock timer'
	order by module
/
