REM  obj_spac.sql
REM  Space Usage for shared SQL objects
REM If running MTS uncomment the mts calculation and output   
REM commands.   
REM
set echo off   
set termout on
set serveroutput on;   

declare   
        object_mem number;   
        shared_sql number;   
        cursor_mem number;   
        mts_mem number;   
        used_pool_size number;   
        free_mem number;   
        pool_size varchar2(512); 
begin   

-- Stored objects (packages, views)   
select SUM(Sharable_Mem) into object_mem 
  from V$DB_OBJECT_CACHE;   

-- Shared SQL -- need to have additional memory if dynamic SQL used   
select SUM(Sharable_Mem) into shared_sql 
  from V$SQLAREA;   

-- User Cursor Usage -- run this during peak usage.   
--  assumes 250 bytes per open cursor, for each concurrent user.   
select SUM(250*Users_Opening) into cursor_mem 
  from V$SQLAREA;   
   
-- For a test system -- get usage for one user, multiply by # users   
-- select (250 * Value) bytes_per_user   
-- from V$SESSTAT S, V$STATNAME N   
-- where S.Statistic# = N.Statistic#   
-- and N.Name = 'opened cursors current'   
-- and S.SID = 25;  -- where 25 is the sid of the process   

-- MTS memory needed to hold session information for shared server users   
-- This query computes a total for all currently logged on users (run   
--  during peak period). Alternatively calculate for a single user and   
--  multiply by # users.   
select SUM(Value) into mts_mem 
  from V$SESSTAT S, V$STATNAME N   
 where S.Statistic#=N.Statistic#   
   and N.Name='session uga memory max';   

-- Free (unused) memory in the SGA: gives an indication of how much memory   
-- is being wasted out of the total allocated.   
select Bytes into free_mem 
  from V$SGASTAT   
 where Name = 'free memory';   

-- For non-MTS add up object, shared sql, cursors and 20% overhead. 
used_pool_size := ROUND(1.2*(object_mem+shared_sql+cursor_mem));   

-- For MTS mts contribution needs to be included (comment out previous line)   
-- used_pool_size := ROUND(1.2*(object_mem+shared_sql+cursor_mem+mts_mem)); 
select Value into pool_size 
  from V$PARAMETER 
 where Name='shared_pool_size';   

-- Display results   
DBMS_OUTPUT.PUT_LINE ('Object mem:    '||TO_CHAR (object_mem) || ' bytes');
DBMS_OUTPUT.PUT_LINE ('Shared SQL:    '||TO_CHAR (shared_sql) || ' bytes');   
DBMS_OUTPUT.PUT_LINE ('Cursors:       '||TO_CHAR (cursor_mem) || ' bytes');   
-- DBMS_OUTPUT.PUT_LINE ('MTS session:   '||TO_CHAR (mts_mem) || ' bytes');   
DBMS_OUTPUT.PUT_LINE ('Free memory:   '||TO_CHAR (free_mem) || ' bytes ' ||   
'('   || TO_CHAR(ROUND(free_mem/1024/1024,2)) || 'MB)');   
DBMS_OUTPUT.PUT_LINE ('Shared pool utilization (total):  '||   
TO_CHAR(used_pool_size) || ' bytes ' || '(' ||   
TO_CHAR(round(used_pool_size/1024/1024,2)) || 'MB)');   
DBMS_OUTPUT.PUT_LINE ('Shared pool allocation (actual):  '|| pool_size 
||' bytes ' || '(' || TO_CHAR(ROUND(pool_size/1024/1024,2)) || 'MB)'); 
DBMS_OUTPUT.PUT_LINE ('Percentage Utilized:  '||to_char   
(ROUND(used_pool_size/pool_size*100)) || '%');   
end;   
/   


