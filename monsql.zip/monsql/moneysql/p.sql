set pagesize 0
col refresh_story for a85
select 'HOW MANY TABLES ARE REFRESHED' from dual;
select '-----------------------------' from dual;
select count(*)||'/43 Done ' Tables_Completed from status where current_date > trunc(sysdate) ;
select '                             ' from dual;
select 'Details of the Refresh' from dual;
select '-----------------------------' from dual;
select rpad(table_name,26,' ') ||  '  ' || 
to_char(current_date, 'mm-dd-yyyy hh24:mi:ss') || '  ' || 
case when completion_target_time-current_date > 0 then '     Taking longer than yesterday'  else 
case when completion_target_time-current_date < 0 then '     Done faster than yesterday' else
case when completion_target_time-current_date=0   then '     In Progress' end end end  
||' ' ||  refresh_status refresh_story from status 
order by current_date desc
/
