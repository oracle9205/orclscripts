--
-- this package allows users to kill their own sessions.  Ordinarilyl, users cannot 
-- do an 'alter system kill session ... ' command to kill their own runaway sessions.
-- this package takes a SID argument, and kill the specified session ONLY IF 
-- the username is the same for the calling session and the targeted session.  
-- 
	procedure kill_session (target_sid in number);
end kill;
/	


create or replace package body kill is 
procedure kill_session (target_sid in number)

is
cursor sid_info(s in number) is
	select sid,username,serial# from v$session where sid=s;

sidrec sid_info%ROWTYPE;
stmt	varchar2(100);
cursor_handle	number;
i		integer;
SID_NOT_FOUND 	exception;
SID_NOT_OWNED_BY_YOU 	exception;
BEGIN
			/* lets hope only one row is returned . .*/
	open sid_info(target_sid);
	fetch sid_info into sidrec;
	if sid_info%NOTFOUND then
		raise_application_error(-20989,'-- ERROR: Sid '||to_char(target_sid)||' is not a valid sid.');
		dbms_output.put_line(' ');
		dbms_output.put_line('-- ERROR: Sid '||to_char(target_sid)||' is not a valid sid.');

	elsif sidrec.username != user then
		raise_application_error(20989,'The SID '||to_char(target_sid)||' is not owned by you');
		dbms_output.put_line('-- ERROR sid is owned by username '||sidrec.username||' but you are logged in as  '||user);

	else
		stmt:='alter system kill session '''||to_char(sidrec.sid)||','||to_char(sidrec.serial#)||'''' ;

		dbms_output.put_line(stmt);
		cursor_handle:=dbms_sql.open_cursor;
		dbms_sql.parse(cursor_handle,stmt,dbms_sql.v7);
		i:=dbms_sql.execute(cursor_handle);
		dbms_sql.close_cursor(cursor_handle);
	end if;

	close sid_info;
END;

end kill;
/

show errors


