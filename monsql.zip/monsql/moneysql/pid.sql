qlol username format a15 
col osuser format a10 
col program format a20 
set verify off 
select a.username, a.osuser, a.program, spid, sid, a.serial# 
from v$session a, v$process b 
where a.paddr = b.addr 
and spid = '&pid';
