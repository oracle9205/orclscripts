select to_char(sysdate,'dd-mon-yyyy hh24:mi:ss') from dual;      

select value, n.name|| '('||s.statistic#||')'       from v$sesstat s , v$statname n       where s.statistic# = n.statistic#       and n.name like '%ga memory%'       and sid=&SID ;
