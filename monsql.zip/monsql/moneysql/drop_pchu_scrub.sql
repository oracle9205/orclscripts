set echo on
set feedback on
spool drop_pchu_scrub.lst;
select 'drop ' || object_type || ' ' || owner ||'.' || object_name || ' ;'
from dba_objects x
where owner = 'PCHU'
and object_name in (
 'PAYPAL_ACCT_EMAIL_ID' ,
 'PAYPAL_ACCT_INFO_PRIME'          ,
 'PAYPAL_ACCT_INFO_P_PK'           ,
 'PAYPAL_ACCOUNT_INDX'             ,
 'PAYPAL_ACCT_ID_INDX'             ,
 'ENC_ACCTS'                       ,
 'PAYPAL_ACCT_EMAIL_INDX'          ,
 'PAYPAL_ACCT_EMAIL'               ,
 'PAYPAL_ACCT_INFO'                ,
 'IP_LOGIN_FAILED'                 ,
 'PAYPAL_ACCT_OLD'                 ,
 'LOGIN_ATTEMPTS'                  
)
and exists (select 'x' from dba_segments y
   where y.owner = x.owner
    and y.segment_name = x.object_name
    and y.tablespace_name = 'SCRUB');
spool off;

