select count(*) "Number of waiters" 
from v$session_wait w, v$latch l
where w.wait_time = 0 
and w.event ='latch free'
and w.p2 = l.latch#
and l.name like 'library%' 
/
