select seg.type#,seg.user#,seg.file#,seg.block#,seg.blocks,ext.ext#
                from sys.seg$ seg, sys.uet$ ext
                where seg.file# = ext.segfile#
                and seg.block# = ext.segblock#
                and ext.file#=&file_no
		and &block_no between ext.block# and ext.block#+ext.length-1
/
