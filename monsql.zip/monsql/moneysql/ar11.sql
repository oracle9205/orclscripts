rem 
delete plan_table;
explain plan for 
SELECT wuser.account_number 
FROM wuser 
WHERE wuser.first_name_upper = :f_name 
   AND wuser.last_name_upper = :l_name 
   AND wuser.account_number IN 
      (SELECT /*+ INDEX (WUSER_ALIAS WUSER_ALIAS_ALIAS_UPPER) */ wuser_alias.account_number 
       FROM wuser_alias 
       WHERE wuser_alias.alias_upper LIKE :email_upper) 
   AND ROWNUM <= :max_res
/
@plan
rollback ;
