accept x prompt 'index name: '
select table_name,index_name,owner,index_type,distinct_keys,num_rows
	from dba_indexes where index_name = upper('&x');

select table_name,table_owner,column_name from dba_ind_columns where 
	index_name=upper('&x')
	order by table_owner,column_position asc;
