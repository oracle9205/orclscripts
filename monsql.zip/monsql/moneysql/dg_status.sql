REM Script to report status of dataguard from v$dataguard_status
REM Sai => 12/13/2011

set lines 199
col timestamp for a20
col severity for a5
col message for a101

select * from
 (select timestamp, substr(severity, 1, 5) severity, message from v$dataguard_status order by timestamp desc)
where rownum <= 50 order by timestamp
/
