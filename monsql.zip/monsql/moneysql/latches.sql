column name format a25
column latch# format 9999
select latch#,substr(name,1,25) name ,round(100.0*gets/decode(gets+misses,0,1,gets+misses)) hit_ratio,gets,spin_gets,misses,sleeps,sleep1,sleep2,waits_holding_latch
from v$latch where sleeps > 0
order by sleeps asc
/

select * from v$latchholder ;
