col value format 99999999999999

select name, value from v$sysstat where name like 'parse count%' 
/
