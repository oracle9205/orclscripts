REM Script to report cpu/pio/lio/memory/parse info by module over the last 15 seconds
REM Sai => 11/19/2008

set trimspool on
col module for a19

select
 substr(nvl(a.module, 'BACKGROUND'), 1, 19) module,
 round(sum(b.cpu_pct)) as cpu_pct, round(sum(pio_pct)) as pio_pct,
 round(sum(lio_pct)) as lio_pct, round(sum(pga_pct)) as pga_pct,
 round(sum(hp)) as hp_pct, round(sum(sp)) as sp_pct
from
v$session a,
(select session_id,
        (cpu/(sum(cpu) over ())*100) as cpu_pct,
         physical_read_pct as pio_pct,
         logical_read_pct as lio_pct,
         (pga_memory/(sum(pga_memory) over ())*100) as pga_pct,
         (hard_parses/((sum(hard_parses) over ())+0.0001)*100) as hp,
         (soft_parses/((sum(soft_parses) over ())+0.0001)*100) as sp
 from v$sessmetric ) b
where
a.sid = b.session_id
group by substr(nvl(a.module, 'BACKGROUND'), 1, 19)
order by cpu_pct desc, lio_pct desc, pio_pct desc, hp_pct desc, sp_pct desc, pga_pct desc
/
