 select
 to_char(last_analyzed,'MM/DD HH24') ts,count(*)
 from dba_tables
 group by
to_char(last_analyzed,'MM/DD HH24')
/
