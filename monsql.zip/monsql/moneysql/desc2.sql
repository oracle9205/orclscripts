REM Sai => 09/30/09 Written for PPDBA repository live objects.

set ver off
set trimspool on
col owner for a13
col column_name for a30
col data_type for a15
col nullable for a8
col dbname for a8
break on owner

select /*+ index(b, pypl_tab_columns_idx1) */
c.dbname, b.owner, b.column_name, b.data_type, b.data_length length, b.nullable, b.num_distinct
from pypl_tab_columns b, pypl_databases c where 
b.dbid = c.dbid and
(b.table_name,b.dbid,b.pypl_date) in 
 (select /*+ index(a, pypl_tab_columns_idx1) */ table_name, dbid, max(pypl_date) from pypl_tab_columns a 
  where table_name like upper('&tabname') group by table_name, dbid)
order by b.dbid, b.owner, b.column_id
/

clear break
