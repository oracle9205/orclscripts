column occ1 format 999
column occ2 format 999
column occ3 format 999
column occ4 format 999
column occ5 format 999
column occ6 format 999
column occ7 format 999
column occ8 format 999
column occ9 format 999
column occ10 format 999
column occ11 format 999
column occ12 format 999
column occ13 format 999
column occ14 format 999
column occ15 format 999
column occ16 format 999
column occ17 format 999
column occ18 format 999
column occ19 format 999
column occ20 format 999
column occ21 format 999
column occ22 format 999


select module,
	count(decode(machine,'occ1',1)) occ1 ,
	count(decode(machine,'occ2',1)) occ2 ,
	count(decode(machine,'occ3',1)) occ3 ,
	count(decode(machine,'occ4',1)) occ4 ,
	count(decode(machine,'occ5',1)) occ5 ,
	count(decode(machine,'occ6',1)) occ6 ,
	count(decode(machine,'occ7',1)) occ7 ,
	count(decode(machine,'occ8',1)) occ8 ,
	count(decode(machine,'occ9',1)) occ9 ,
	count(decode(machine,'occ10',1)) occ10,
	count(decode(machine,'occ11',1)) occ11 ,
        count(decode(machine,'occ12',1)) occ12,
        count(decode(machine,'occ13',1)) occ13,
        count(decode(machine,'occ14',1)) occ14,
        count(decode(machine,'occ15',1)) occ15,
        count(decode(machine,'occ16',1)) occ16,
        count(decode(machine,'occ17',1)) occ17,
        count(decode(machine,'occ18',1)) occ18,
        count(decode(machine,'occ19',1)) occ19,
        count(decode(machine,'occ20',1)) occ20,
        count(decode(machine,'occ21',1)) occ21,
count(*) from v$session
group by module
/
