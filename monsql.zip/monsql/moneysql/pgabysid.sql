select n.name, s.value
from v$statname n,V$sesstat s
where n.statistic# = s.statistic#
and s.value > 0
and sid in ( &SIDLIST )
and n.name like '%mem%'
and n.statistic# = s.statistic#  
/
