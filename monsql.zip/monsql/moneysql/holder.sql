select ses.sid, ses.sql_address sqladdr, lh.* from v$latchholder lh, v$session ses
where lh.sid=ses.sid
/
