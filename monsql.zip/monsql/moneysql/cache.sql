column mbytes format 99,999,999.0
column object_name format a30
column subobject_name format a10
select b.obj,a.object_name,a.subobject_name,a.object_type,b.tot*8/1024 mbytes
from dba_objects a,
(select obj,count(*) tot from bh group by obj having count(*) > 1000 ) b
where b.obj=a.data_object_id (+)
order by mbytes asc
/
