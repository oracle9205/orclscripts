--start id detail
set serveroutput on size 1000000
declare
    l_high_value                NUMBER ;
    prev_cnt NUMBER;
    this_cnt NUMBER; 
    min_id NUMBER;
    min_time_crt VARCHAR2(40);
    cursor c2 (in_high_value NUMBER) is 
    select max(id) id, to_char(u2sql(max(time_created)),'MON-dd-yy hh24:mi:ss') time_created
    , to_char(u2sql(max(time_updated)),'MON-dd-yy hh24:mi:ss') time_updated from (
    select id,  
    time_created, 
    time_updated
    from wtransaction where id in (in_high_value, (in_high_value - 1), (in_high_value - 2), (in_high_value - 3), (in_high_value - 4) ) )
    ;
 
begin
    prev_cnt := 0;
    dbms_output.put_line ('Sq'|| ': ' || 'Partition Name'|| ': ' ||'Minimum ID ' || ' : ' || ' High Value' || ' ; '|| 'Time_Created Min   ' || ': ' || 'Time_Created MAX  ' || ' : '|| ' Time_Updated MAX   ' );
 
    for c1_rec in (select partition_name,partition_position,high_value from 
                   dba_tab_partitions where table_name='WTRANSACTION'
                   and partition_name <> 'WT_OVER2' order by partition_position)
    loop
         l_high_value := to_number(c1_rec.high_value);
         --dbms_output.put_line (l_high_value);
 
         for c2_rec in c2 ((l_high_value - 200000000 + 1))
         loop
             min_id := c2_rec.id;
             min_time_crt := c2_rec.time_created;
--             dbms_output.put_line ((c1_rec.partition_position)|| ' : ' || c1_rec.partition_name || '       : ' || (c2_rec.id) || ' ; '|| (c2_rec.time_created) || ' ; '|| (c2_rec.time_updated) );
         end loop;
 
 
         for c2_rec in c2 (l_high_value)
         loop
             dbms_output.put_line ((c1_rec.partition_position)|| ' : ' || c1_rec.partition_name || '       : ' || (min_id) || ' : ' || (c2_rec.id) || ' ; '|| (min_time_crt) || ' : ' || (c2_rec.time_created) || ' : '|| (c2_rec.time_updated) );
         end loop;
 
 
 
 
--         dbms_output.put_line ('partition_position: '||(c1_rec.partition_position));
--         dbms_output.put_line ('range difference: '||(l_high_value - prev_cnt));
--       dbms_output.put_line (l_high_value);
       prev_cnt := l_high_value;
    end loop;
end;
/
