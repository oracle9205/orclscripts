col MAXTIME format a15
col SAMPLE_TIME format a26
col BLOCKING_SESSION format 99999999
col event format a25
col AVGTIME format a15
select sample_time,BLOCKING_SESSION,BLOCKING_SESSION_STATUS,BLOCKING_HANGCHAIN_INFO,session_id,program,p1,p2,event from &ash
where session_id=&session_id order by sample_time;
