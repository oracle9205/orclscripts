column tablespace_name format a30
column filesize format 999,999,999.9


select * from 
(select df.tablespace_name,
	sum(df.bytes)/(1024*1024*1024) filesize,
	sum(fs.phyrds) phyrds,
	sum(fs.phywrts) phywrts,
	sum(fs.phyblkrd) phyblkrd,
	sum(fs.phyblkwrt) phyblkwrt,
	avg(fs.avgiotim) avgiotim
from 
	dba_data_files df,
	v$filestat fs
where 
	fs.file#=df.file_id
group by
	tablespace_name
)
order by phyblkrd asc
/
