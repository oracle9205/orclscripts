select sum(decode(sign(extent_id-&ext-1),-1,bytes))/sum(bytes) from dba_extents where segment_name='&segment_name'
/
