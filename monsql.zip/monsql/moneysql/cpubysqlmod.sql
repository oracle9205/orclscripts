select
module , round(sum(cpu1)*100) as sql_cpu_pct from
 (select module, cpu_time/(sum(cpu_time) over ()) as cpu1 from V$sql)
where module not like '%@%'
group by module
order by 2 desc
/
