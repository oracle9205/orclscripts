select * from v$lock where sid in (&sidlist)
/
