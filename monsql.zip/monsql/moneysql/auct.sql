select object_name, object_type, object_id, owner from dba_objects where object_name like '%AUCTION%' 
/
