--------------------------------------------
--
--  fileio.sql
--  Datafile I/O distribution, across all datafiles
--  12/18/01 SJ
--------------------------------------------
column File_Name format A72
col Tablespace_name format a25
Break on Tablespace_Name skip 1

select 
       DB.Tablespace_name,
       DF.Name File_Name,
       FS.Phyblkrd Blocks_Read,
       FS.Phyblkwrt Blocks_Written,
       FS.Phyblkrd+FS.Phyblkwrt Total_IOs,
       ((FS.Phyblkrd+FS.Phyblkwrt)/ab.tot)*100 Percent_IO
  from V$FILESTAT FS, V$DATAFILE DF, dba_data_files DB,
       ( Select sum(f.phyblkrd + f.phyblkwrt) tot
         from v$filestat f, v$datafile d
         where f.file#=d.file# ) ab 
 where DF.File#=FS.File# 
       and DF.file# = DB.file_id
 order by 
       (FS.Phyblkrd+FS.Phyblkwrt)/ab.tot ;

