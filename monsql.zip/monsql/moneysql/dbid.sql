REM Sai => Script to display metadata from pypl_databases 
set ver offQ
col dbname for a10
col tns_alias for a15

select 
dbid, dbid_adjust, dbname, tns_alias, awr_flag, awr_last_snap, freecon_flag, freecon_last_time, monitor_flag, monitor_last_time
from pypl_databases
where dbname like upper('%&&dbname%')
order by dbname
/
