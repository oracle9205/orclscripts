select object_name,object_type,created from dba_objects where object_name like upper('&object_name') order by created asc
/
