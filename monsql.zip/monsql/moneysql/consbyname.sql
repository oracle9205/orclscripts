rem
rem given a constraint_name, show it 
rem 
select cons.constraint_name,cons.constraint_type type,cols.column_name
	from dba_cons_columns cols,
	dba_constraints cons
	where cons.constraint_name= upper(rtrim(ltrim('&constraint_name')))
	      and cols.constraint_name=cons.constraint_name
	order by constraint_name,position
/
