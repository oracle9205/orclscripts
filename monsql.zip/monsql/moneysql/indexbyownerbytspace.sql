  select owner,
     count(decode(tablespace_name,'ISPACE0',1,null)) ISPACE0,
     count(decode(tablespace_name,'ISPACE1',1,null)) ISPACE1,
     count(decode(tablespace_name,'ISPACE2',1,null)) ISPACE2,
     count(decode(tablespace_name,'ISPACE3',1,null)) ISPACE3,
     count(decode(tablespace_name,'ISPACE4',1,null)) ISPACE4,
     count(decode(tablespace_name,'ISPACE5',1,null)) ISPACE5
 from dba_indexes
group by owner
/
