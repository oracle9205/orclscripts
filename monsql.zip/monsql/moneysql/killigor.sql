select 'alter system kill session '''||to_char(sid)||','||to_char(serial#)||''';' from v$session where username = 'IGOR'
