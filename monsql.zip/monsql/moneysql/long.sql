select sid, serial#, message, to_char(start_time,'MM:DD:YYYY:hh:ss') start_time , ELAPSED_SECONDS,  time_remaining, (sofar/totalwork)*100 percent_complete from v$session_longops where sid=&enter_sid 
/
