col account_status format a10
col username format a22
col default_tablespace format a20
col temporary_tablespace format a20

select username, account_status, default_tablespace, temporary_tablespace, to_char(created,'MM/DD/YYYY HH24:MI:SS') created from dba_users 
/
