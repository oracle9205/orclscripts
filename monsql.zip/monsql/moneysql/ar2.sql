rem 
explain plan for 
select account_number
from
(
SELECT a.account_number
FROM wuser a, wuser_alias b
WHERE a.account_number = b.account_number
and b.alias_upper LiKE :email_upper
)
where rownum <= :mas_res
/
@plan
rollback ;
