select c.snap_time,a.snap_id,
	(a.executions - b.executions)/3600   executions_sec,
	(a.buffer_gets - b.buffer_gets)/3600 buffer_gets_sec,
	(a.disk_reads  - b.disk_reads)/3600  disk_reads_sec,
	a.text_subset
from stats$sql_summary a,
     stats$sql_summary b,
     stats$snapshot    c
where
      a.hash_value=2338799139
and   b.hash_value=a.hash_value
and   b.snap_id = a.snap_id -12
and   mod(a.snap_id,12)=0
and a.snap_id > (select max(snap_id) - &num_rows from stats$snapshot)
and a.snap_id=c.snap_id
/
