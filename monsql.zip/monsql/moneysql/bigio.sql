select s.sid,logon_time,s.program,i.block_gets,i.consistent_gets,
	i.physical_reads,i.block_changes,i.consistent_changes from v$sess_io i,
	v$session s
	where 
	(i.block_gets+i.consistent_gets > 1000000 or
	i.block_changes > 50000 or
	i.consistent_changes > 50000)
	and i.sid=s.sid
/
