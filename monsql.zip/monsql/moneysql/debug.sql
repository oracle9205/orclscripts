select object_name, object_type, owner, status, to_char(created,'DD/Mon/YYYY - HH:SS') "Created On" from dba_objects  where created
> trunc(sysdate) - &No_of_days_old and 
owner='FACT' 
and object_name like upper('&tab_name%')
and object_type in ('TABLE', 'INDEX') order by created, owner, object_type 
/
