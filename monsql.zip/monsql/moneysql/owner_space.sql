col owner format a18
select d.owner , trunc(sum(bytes)/(1024*1024), 2 ) "Used space(M)"
from dba_segments s, dba_objects d
where 
d.object_name=s.segment_name and
d.object_type != 'SYNONYM' and
s.tablespace_name=upper('&tablespace_name') 
group by d.owner
order by sum(bytes)/(1024*1024) desc
/
