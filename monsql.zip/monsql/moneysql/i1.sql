select count(distinct dbid), count(*), max(length(object_name)) from sai1 where operation='INSERT' 
/
