set heading off
set pagesize 0

spool killocc.lst
set heading off
set pagesize 0
select 'alter system kill session '''||to_char(sid)||','||to_char(serial#)||''';'
from v$session where MACHINE LIKE 'occ%' and status='ACTIVE'
/
spool off
/
spool off
