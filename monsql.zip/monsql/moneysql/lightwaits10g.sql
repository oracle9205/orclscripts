col osuser format a10
col machine format a10
col module format a10

select machine,
       s.sid,
       sql_hash_value,
       event,
       module,
       io.block_gets+io.consistent_gets gets,
       seconds_in_wait sec
  from 
       v$sess_io     io,
       v$session      s
 where io.sid = s.sid 
   and s.status = 'ACTIVE'
   and event not in ('rdbms ipc message', 'pmon timer', 'smon timer')
 order by event
/
