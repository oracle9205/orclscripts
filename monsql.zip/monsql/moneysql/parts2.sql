REM Sai => 09/30/09 Written for PPDBA repository live objects.

set lines 199
col dbname for a8
col table_owner format a10
col table_name format a28
col buffer_pool format a7
col high_value for a25
col pos for 99999
col spart for 9999
break on table_owner

select /*+ ordered index(a, pypl_tab_partitions_idx1) */
c.dbname, a.table_owner, a.partition_name, a.buffer_pool, a.high_value, 
a.partition_position pos, a.subpartition_count spart, a.num_rows, a.blocks 
from pypl_tab_partitions a, pypl_databases c where 
a.dbid = c.dbid and
(a.table_name, a.dbid, a.pypl_date) in 
(select /*+ index(b, pypl_tab_partitions_idx1) */ table_name, dbid, max(pypl_date) from pypl_tab_partitions b where
 table_name=upper('&table_name') group by table_name, dbid)
order by c.dbname, a.table_owner, partition_position ;

clear break
