select * from v$session_wait where event != 'client message' and event not like '%NET%' and wait_time=0 and sid > 5 
/
