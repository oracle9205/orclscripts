rem
rem report for space usage per owner
rem

select owner,sum(bytes) from dba_segments 
group by owner

