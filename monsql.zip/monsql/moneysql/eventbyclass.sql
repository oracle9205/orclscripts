REM Script to report event name, p1text, p2text, p3text from v$event_name for a given wait class.
REM Sai -> 06/14/2011

set ver off
set trimspool on
set lines 199
col "NAME:P1:P2:P3" for a100

select 
event#, 
name||': P1-> '||PARAMETER1||': P2-> '||PARAMETER2||': P3-> '||PARAMETER3 "NAME:P1:P2:P3"
from v$event_name 
where 
lower(wait_class) like lower('%&wait_class%')
order by event#
/
