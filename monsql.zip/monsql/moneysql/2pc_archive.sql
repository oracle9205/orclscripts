column xid format a50
column time_created    format 99999999999999999
column time_to_process format 99999999999999999
column last_retry_time format 99999999999999999
column reco_comment format a35 
select * from w2pc_reco_archive 
order by time_created asc
/
