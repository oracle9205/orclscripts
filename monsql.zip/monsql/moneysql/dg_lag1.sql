REM Script to report lag of physical standby
REM Sai => 12/13/2011

set numwidth 20
col scn_time for a35
col la1 for a30

@mydate

select checkpoint_time from v$datafile where file#=1;
