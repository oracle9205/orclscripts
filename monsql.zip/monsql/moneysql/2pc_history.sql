select a.snap_id, snap_time, a.executions
from stats$sql_summary a, stats$snapshot c
where a.hash_value = '1547085363' and c.snap_id > 107600
and a.snap_id = c.snap_id
/
