REM Script to report status of real time apply on physical standby
REM Sai => 12/13/2011

select dest_id, DATABASE_MODE, RECOVERY_MODE, PROTECTION_MODE from v$archive_dest_status  
where (type='LOCAL' and recovery_mode like '%MANAGED%') or dest_id=1
/
