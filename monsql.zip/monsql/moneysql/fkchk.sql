select constraint_name,table_name,r_constraint_name
from user_constraints
where constraint_type='R'
and r_constraint_name ='WUSER_PRIME'
/
