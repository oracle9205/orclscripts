col megabytes format 99,99,999

select to_char(first_time,'MM/DD') Day,
trunc(sum(block_size*blocks) /(1024*1024)) megabytes,
count(*) num_logs,
sum(block_size*blocks) /((1024*1024)*count(*)) megabytes_per_log,
sum(next_change#-first_change#) changes,
sum(next_change#-first_change#)*1.0/count(*)*1.0 changes_per_log,
min(sequence#) first_log_id,
max(sequence#) last_log_id
from v$archived_log
where first_time > trunc(sysdate-30)
group by to_char(first_time,'MM/DD')
/
