 SELECT
  COUNT(CASE WHEN (type = 'B' AND status IN ('S','P')) THEN 1 ELSE NULL END) DEBIT,
  COUNT(CASE WHEN (type = 'R' AND status = 'S') THEN 1 ELSE NULL END) CC,
  COUNT(CASE WHEN (type = 'R' AND status !='S') THEN 1 ELSE NULL END) CCDNY,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P')) THEN 1 ELSE NULL END) PAYMT,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND CURRENCY_CODE !='USD') THEN 1 ELSE NULL END) NONUSD,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags ,16) !=0) THEN 1 ELSE NULL END) AUCTN,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags , 16) = 16) THEN 1 ELSE NULL END) AUCTN,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags ,4194320) = 4194304) THEN 1 ELSE NULL END) WBXPT,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags2,512) !=0) THEN 1 ELSE NULL END) SCHD,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags3,65536) !=0 AND bitand(flags4,34)=0) THEN 1 ELSE NULL END) WAX,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags3,8388608)!=0) THEN 1 ELSE NULL END) MPULL,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags3,65536) !=0 AND bitand(flags4,34)=34) THEN 1 ELSE NULL END) VTERM,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags3,65536) !=0 AND bitand(flags4,34)=32) THEN 1 ELSE NULL END) DCC,
  COUNT(CASE WHEN (type IN ('U','@') AND amount <= 0 AND status IN ('S','P') AND BITAND(flags4,4096) != 0) THEN 1 ELSE NULL END) SIALL,
  COUNT(CASE WHEN (type IN ('U','@') AND amount <= 0 AND status IN ('S','P') AND BITAND(flags4,256) =0 AND bitand(flags3,65536) !=0 AND bitand(flags4,34)=0 AND bitand(flags4,4096) != 0) THEN 1 ELSE NULL END) SIWAX,
  COUNT(CASE WHEN (type IN ('U','@') AND amount <= 0 AND status IN ('S','P') AND bitand(flags3,65536) !=0 AND bitand(flags4,34)  =32 AND bitand(flags4,4096) != 0) THEN 1 ELSE NULL END) SIDCC,
  COUNT(CASE WHEN (type IN ('U','@') AND amount <= 0 AND status IN ('S','P') AND BITAND(flags3,65536)  =0 AND bitand(flags4,256) !=0 AND bitand(flags4,4096) != 0) THEN 1 ELSE NULL END) SIWALLET,
  COUNT(CASE WHEN (type IN ('U','@') AND amount <= 0 AND status IN ('S','P') AND BITAND(flags3,65536) !=0 AND BITAND(flags4,256) !=0 AND BITAND(flags4,4096) != 0) THEN 1 ELSE NULL END) SIEXPRESSO,
  COUNT(CASE WHEN (type IN ('U','@') AND amount < -1 AND status IN ('S','P') AND BITAND(flags3,65536)  =0 AND BITAND(flags4,256) !=0 AND BITAND(flags4,4096) != 0) THEN 1 ELSE NULL END) SIWALLET_TRICKLESS,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags4,8192) != 0) THEN 1 ELSE NULL END) EBEXP,
  COUNT(CASE WHEN (type = 'U' AND subtype = 'U' AND amount <= 0 AND status IN ('S', 'P') ) THEN 1 ELSE NULL END ) SHIP,
  COUNT(CASE WHEN (type = 'U' AND amount > 0 AND subtype = 'P') THEN 1 ELSE NULL END) OFFEBGIFTPURCH,
  COUNT(CASE WHEN (type = 'C' AND amount < 0 AND type = 'C' AND subtype = 'G') THEN 1 ELSE NULL END) OFFEBGIFTREDEMP,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags,131072) !=0) THEN 1 ELSE NULL END) MOBILE_INIT,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND counterparty_alias_type = 'P') THEN 1 ELSE NULL END) MOBILE_TERM,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags,131072)=131072 AND subtype='I') THEN 1 ELSE NULL END) M_EMC,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S','P') AND bitand(flags,131072)!=0 AND bitand(flags4, 256)!=0) THEN 1 ELSE NULL END) M_MEC,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags4,262144) != 0) THEN 1 ELSE NULL END) PPFE,
  COUNT(CASE WHEN ((type='@' AND subtype='D' AND status='P') OR (type='B' AND status='P')) THEN 1 ELSE NULL END ) DEBITAUTH,
  COUNT(CASE WHEN (type = 'B' AND status='S') THEN 1 ELSE NULL END) DEBITSETTLE,
  COUNT(CASE WHEN (type = 'U' AND subtype = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags4,262144) != 0 ) THEN 1 ELSE NULL END ) SHIP_PPFE,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags,512) != 0 ) THEN 1 ELSE NULL END ) UNILATERAL,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags,512) != 0 AND BITAND(flags4,262144) != 0 ) THEN 1 ELSE NULL END ) UNILATERAL_PPFE,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags2,1024) != 0 ) THEN 1 ELSE NULL END ) SUBSCRIPTION,
  COUNT(CASE WHEN (type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags2,1024) != 0 AND BITAND(flags4,262144) != 0) THEN 1 ELSE NULL END ) SUBSCRIPTION_PPFE,
  COUNT(CASE WHEN (type ='@' AND status = 'P' and bitand(flags2,16384)=16384 AND (not (bitand(flags2, 1073741824)=1073741824))) THEN 1 ELSE NULL END) CPN_PENDING_AUTHS,
  COUNT(CASE WHEN (type ='B' AND status = 'S' and bitand(flags2,16384)=16384 AND (not (bitand(flags2, 1073741824)=1073741824))) THEN 1 ELSE NULL END) CPN_SETTLED_TRANS,
  COUNT(CASE WHEN (type ='B' AND status = 'D' and bitand(flags2,16384)=16384 AND (not (bitand(flags2, 1073741824)=1073741824))) THEN 1 ELSE NULL END) CPN_DECLINED_TRANS,
  COUNT(CASE WHEN (type = 'U' AND amount >= 0 AND status IN ('S', 'P') AND BITAND(flags4,262144) != 0 ) THEN 1 ELSE NULL END ) PPFE_ASYNC,
  COUNT(CASE WHEN (type = 'U' AND status IN ('C') AND BITAND(flags3,33554432) != 0 AND BITAND(flags4,16384) != 0 ) THEN 1 ELSE NULL END) IEFT_INITIATED,
  COUNT(CASE WHEN (type = 'U' AND amount > 0 AND status IN ('S') AND BITAND(flags3, 33554432) != 0 AND BITAND(flags4,16384) != 0 ) THEN 1 ELSE NULL END) IEFT_RESPONDED,
  COUNT(CASE WHEN ( type = 'U' AND amount <= 0 AND status IN ('S', 'P') AND BITAND(flags,4) != 0 ) THEN 1 ELSE NULL END ) PAYMENTSERV,
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='EUR') THEN 1 ELSE NULL END) CIP_EUR, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='HKD') THEN 1 ELSE NULL END) CIP_HKD, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='CZK') THEN 1 ELSE NULL END) CIP_CZK, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='DKK') THEN 1 ELSE NULL END) CIP_DKK, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='MXN') THEN 1 ELSE NULL END) CIP_MXN, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='PLN') THEN 1 ELSE NULL END) CIP_PLN, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='HUF') THEN 1 ELSE NULL END) CIP_HUF, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='SGD') THEN 1 ELSE NULL END) CIP_SGD,
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='GBP') THEN 1 ELSE NULL END) CIP_GBP, 
  COUNT(CASE WHEN (type = 'G' AND status = 'S' AND CURRENCY_CODE ='AUD') THEN 1 ELSE NULL END) CIP_AUD, 
  COUNT(CASE WHEN ( type = 'V' AND amount >= 0 AND status IN ('S', 'P','D')) THEN 1 ELSE NULL END ) RnR,
  COUNT(CASE WHEN ( type = 'V' AND amount >= 0 AND status IN ('S', 'P','D') AND BITAND(flags,4) != 0 ) THEN 1 ELSE NULL END ) PAYMENTSERV_RnR,
  COUNT(CASE WHEN ( status = 'C' and (bitand(flags3, 16777216)= 16777216 or bitand(flags4, 16384)= 16384) and (bitand(flags5, 1) = 1) ) THEN 1 ELSE NULL END) ECC,
  COUNT(CASE WHEN ( (status = 'P' or status = 'R') and (bitand(flags3, 16777216)= 16777216 or bitand(flags4, 16384)= 16384) and (bitand(flags5, 1) = 1) ) THEN 1 ELSE NULL END) ECPR,
  COUNT(CASE WHEN (  status = 'S' and (bitand(flags3, 16777216)= 16777216 or bitand(flags4, 16384)= 16384) and (bitand(flags5, 1) = 1) ) THEN 1 ELSE NULL END) ECS,
  COUNT(CASE WHEN (type = 'R' AND parent_id IS NULL AND BITAND(flags, 4) = 0 ) THEN 1 ELSE NULL END ) RDEP,
  COUNT(CASE WHEN (type = 'H' AND parent_id IS NULL AND status = 'P' AND BITAND(flags, 4) = 0 ) THEN 1 ELSE NULL END ) HDEP,
  COUNT(CASE WHEN (type = 'R' AND parent_id IS NULL AND BITAND(flags, 4) != 0 ) THEN 1 ELSE NULL END ) P_RDEP,
  COUNT(CASE WHEN (type = 'H' AND parent_id IS NULL AND status = 'P' AND BITAND(flags, 4) != 0 ) THEN 1 ELSE NULL END ) P_HDEP,
  COUNT(*) scanned,
  MIN(time_created) OLDEST
FROM
(
SELECT * FROM WTRANSACTION WHERE
  mod(base_id,5)=0
  AND base_id = id AND base_id > (SELECT last_number-cache_size-60000 FROM all_sequences where sequence_name='WTRANSACTION_SEQ') AND time_created BETWEEN
        ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) - 60  --1min ago
    AND ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) --now
UNION ALL
SELECT * FROM WTRANSACTION WHERE
  mod(base_id,5)=1
  AND base_id = id AND base_id > (SELECT last_number-cache_size-60000 FROM all_sequences where sequence_name='WTRANSACTION_SEQ') AND time_created BETWEEN
        ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) - 60  --1min ago
    AND ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) --now
UNION ALL
SELECT * FROM WTRANSACTION WHERE
  mod(base_id,5)=2
  AND base_id = id AND base_id > (SELECT last_number-cache_size-60000 FROM all_sequences where sequence_name='WTRANSACTION_SEQ') AND time_created BETWEEN
        ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) - 60  --1min ago
    AND ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) --now
UNION ALL
SELECT * FROM WTRANSACTION WHERE
  mod(base_id,5)=3
  AND base_id = id AND base_id > (SELECT last_number-cache_size-60000 FROM all_sequences where sequence_name='WTRANSACTION_SEQ') AND time_created BETWEEN
        ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) - 60  --1min ago
    AND ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) --now
UNION ALL
SELECT * FROM WTRANSACTION WHERE
  mod(base_id,5)=4
  AND base_id = id AND base_id > (SELECT last_number-cache_size-60000 FROM all_sequences where sequence_name='WTRANSACTION_SEQ') AND time_created BETWEEN
        ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) - 60  --1min ago
    AND ( 86400 * ( ( sysdate + ( to_number ( substr ( ( SELECT sessiontimezone FROM dual), 2, 2))/24)) - to_date ( '01-jan-1970', 'dd-mon-yyyy'))) --now
)
