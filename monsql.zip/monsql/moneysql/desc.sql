REM Script to describe table columns with column level stats
REM Sai => 12/13/2011

col column_name for a30
col data_type for a15
col owner for a15

select owner, column_name, data_type||'('||data_length||')' data_type, num_distinct, num_buckets, last_analyzed, sample_size
from dba_tab_columns
where table_name like upper('&table_name') and
 column_name like upper('%&column_name%')
order by owner, column_id
/
