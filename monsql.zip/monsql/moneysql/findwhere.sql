select 
substr(sql_text,instr(upper(sql_text),'WHERE')) from sqlarea_prev
where module in ('SITE','AUCTION','FINSERV','BATCH')
and
upper(substr(sql_text,instr(upper(sql_text),'WHERE'))) like '&column'
from sqlarea_prev
/
