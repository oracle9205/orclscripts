select a.PROC_DTL_NM,a.RSRC_NM,a.RSRC_ACC_CD,b.avl_flg,a.acc_qty,
	b.CNTNT_VAL,b.AS_OF_TM,b.READ_CNT,b.LST_ACC_TM, b.PROC_PRI_NBR
	from t_proc_rsrc a,
	t_rsrc_dtl b
	where a.rsrc_nm=b.rsrc_nm (+) and  b.CNTNT_VAL like '%DAEMON'
	order by a.proc_dtl_nm,rsrc_nm
/
