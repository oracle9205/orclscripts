
no rows selected

SP2-0734: unknown command beginning "extents, t..." - rest of line ignored.
SP2-0734: unknown command beginning "b.blocks a..." - rest of line ignored.
SP2-0734: unknown command beginning "FROM sys.d..." - rest of line ignored.
SP2-0734: unknown command beginning "WHERE segm..." - rest of line ignored.
SP2-0044: For a list of known commands enter HELP
and to leave enter EXIT.
SP2-0734: unknown command beginning "and a.owne..." - rest of line ignored.

Table dropped.

