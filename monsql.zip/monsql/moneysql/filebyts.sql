column file_name format a50
column tablespace_name format a25
select vdf.creation_time,df.file_name,df.file_id,df.tablespace_name,df.bytes,df.autoextensible 
	from dba_data_files df,
	     v$datafile vdf 
where tablespace_name like upper('&tsname')
and df.file_id=vdf.file#
order by vdf.creation_time
/
