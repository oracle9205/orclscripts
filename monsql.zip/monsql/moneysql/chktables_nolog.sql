select a.owner,a.table_name,a.tablespace_name,b.created from dba_tables a, dba_objects b where a.logging='NO' and a.table_name=b.object_name and b.created > (sysdate-3) order by b.created
/
