select n.name,s.value
	from v$sesstat s, v$statname n
	where s.value > 0
	and s.sid in (select sid from v$session where username='IVR_INTERFACE')
	and n.statistic#=s.statistic#
	and n.name like '%execute%'
/
