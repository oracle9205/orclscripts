REM  hitrpool.sql
REM  Shared SQL Area Hit Ratio 
REM  Target:  Hit Ratio > 99 percent.
REM
column Miss_Ratio format 999.99
column Hit_Ratio format 999.99
select 
   SUM(Pins) Execs,
   SUM(Reloads) Cache_Misses,
   DECODE(SUM(Pins),0,0,(SUM(Reloads)/SUM(Pins))*100) 
      Miss_Ratio,
   DECODE(SUM(Pins),0,0,((SUM(Pins)-SUM(Reloads))/SUM(Pins))*100) 
      Hit_Ratio
from V$LIBRARYCACHE;

