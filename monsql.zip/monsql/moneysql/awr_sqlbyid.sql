REM Script to get sql text for a given sql id from awr.
REM Sai => 12/13/2011

set long 50000

select sql_text from dba_hist_sqltext where sql_id='&sql_id';
