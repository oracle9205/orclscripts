rem 
explain plan for 
SELECT wtransaction.id,wtransaction.parent_id,wtransaction.type,wtransaction.time_created,
	wtransaction.time_processed,wtransaction.flags,wtransaction.account_number,
	wtransaction.shared_id,wtransaction.counterparty,wtransaction.amount,
	wtransaction.status,wtransaction.memo,wtransaction.message_id,wtransaction.reason,
	wtransaction.time_user,wtransaction.counterparty_alias,wtransaction.
	counterparty_alias_type,wtransaction.cctrans_id,wtransaction.sync_group,
	wtransaction.ach_id,wtransaction.address_id 
FROM wtransaction,wuser 
WHERE wtransaction.counterparty=:account_number 
AND wtransaction.amount<=-1 
AND wtransaction.counterparty!=wtransaction.account_number 
AND wtransaction.status=:status 
AND wuser.account_number=wtransaction.account_number 
AND BITAND(wuser.flags,3)=0 
AND wtransaction.time_created= 
	(SELECT MIN(wtransaction.time_created) 
		FROM wtransaction,wuser 
		WHERE wtransaction.counterparty=:account_number 
		AND wtransaction.amount<=-1 AND wtransaction.time_created<:time_created 
		AND wtransaction.counterparty!=wtransaction.account_number 
		AND wtransaction.status=:status AND wuser.account_number=wtransaction.account_number 
		AND BITAND(wuser.flags,3)=0) 
ORDER BY wtransaction.time_user
/
@plan
rollback ;
