select 'alter system kill session '''||to_char(a.sid)||','||to_char(a.serial#)||''';' kil
        from v$session a
	where a.sid in (select sid from v$session where sql_address='&sql_addrees')
        order by a.sid
/
