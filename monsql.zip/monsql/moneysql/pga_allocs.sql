-- Pga Allocations Summed up by username

col username format a30

select se.username, sum(st.value/1000) as "Total PGA in KB"
from v$session se, v$sesstat st
where st.statistic#=20 and
st.sid=se.sid and se.username is not null group by se.username order by se.username
/
