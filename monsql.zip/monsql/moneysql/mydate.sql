alter session set nls_date_format='MM/DD/YYYY HH24:MI:SS'
/
