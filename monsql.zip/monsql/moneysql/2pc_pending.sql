select * from db_2pc_pending
/
