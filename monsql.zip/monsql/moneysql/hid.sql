set pages 0
set trimspool on
set lines 199
col name1 for a40
col value for a25
col description for a59

select nam.ksppinm name1, val.ksppstvl value, nam.KSPPDESC description 
from
x$ksppi nam, x$ksppsv val
where
nam.indx = val.indx
/
