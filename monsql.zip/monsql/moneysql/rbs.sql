rem  desc: Show rollback stats and optsize in Kbyte.

set numwidth 9
set feed     10
col rssize  for 99999999 head 'Size|Kbyte'
col optsize for 99999999 head 'Optimal'
col hwmsize for 99999999 head 'Size|Hwmark'
col name    for A6
col XACTS   for 999
col shrinks for 999
col waits   for 999
col wraps   for 99999
col extends for 99999
col status  for A8
select N.name
      ,rssize/1024    rssize
      ,S.optsize/1024 optsize
      ,S.hwmsize/1024 hwmsize
      ,shrinks
      ,extends
      ,wraps
      ,Xacts
      ,writes
      ,waits
--    ,aveactive
      ,status
from   v$rollname N
      ,v$rollstat S
where  N.usn = S.usn
order by 1
/
