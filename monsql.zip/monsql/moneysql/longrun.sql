col message format a48

select sid, serial#, message, to_char(start_time,'MM:DD:YYYY:hh:ss') start_time , ELAPSED_SECONDS,  time_remaining, (sofar/totalwork
)*100 percent_complete from v$session_longops where sid=&sid and START_TIME > ( sysdate - 0.02 ) ;
