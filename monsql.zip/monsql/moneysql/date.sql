select u2sql(&unix_time) from dual
/
