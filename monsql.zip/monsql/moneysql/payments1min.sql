spool payments.txt
alter session set nls_date_format='MM/DD/YYYY HH24:MI:SS' ;

select
        trunc(time_created/60)*60        time_created,
        u2sql(trunc(time_created/60)*60)        oracle_time,
        nvl(count(decode(type,'U',1)),0)  PAYMENTS,
        round(nvl(count(decode(type,'U',1)),0)/60)  "PAYMENTS/SEC",
        nvl(count(decode(type,'R',1)),0)  CHARGES
        from wtransaction wt where
        base_id=id
        and    ((type  = 'U' and status in ('S','P')  and amount<0)
                or
                (type  = 'R' and status = 'S'))
        and base_id > (select max(base_id)-100000 from wtransaction)
        group by trunc(time_created/60)*60
/
