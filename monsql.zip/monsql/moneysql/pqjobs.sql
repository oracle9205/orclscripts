col username for a12 
col "QC SID" for A6 
col SID for A6 
col "QC/Slave" for A10 
col Requested_DOP for 99 
col Actual_DOP for 99 
col "Slave set" for  A10 
col Program for a35
set pages  100 
set head off
select 'Slave set means the parallel job is doing sorts also. ' from dual;
select 'Hence it shows no.of. sessions = double the degree of actual parallelism' from dual;
set head on
select
  decode(px.qcinst_id,NULL,username,
        ' - '||lower(substr(s.program,length(s.program)-4,4) ) ) "Username",
  decode(px.qcinst_id,NULL, 'QC', '(Slave)') "QC/Slave" ,
  to_char( px.server_set) "Slave Set",
  to_char(s.sid) "SID",
  decode(px.qcinst_id, NULL ,to_char(s.sid) ,px.qcsid) "QC SID",
  px.req_degree "Req_DOP",
  px.degree DOP,
  s.sql_address ,
  substr(s.program,1,35) Program
from
  v$px_session px,
  v$session s
where
  px.sid=s.sid (+)
 and
  px.serial#=s.serial#
order by 5 , 1 desc
/
