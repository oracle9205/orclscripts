col segment_name format a30

select segment_name,segment_type, owner, tablespace_name,bytes,blocks from dba_segments where tablespace_name like
upper('&segname') and owner not in ('CONFDBA','IGOR' ) order by bytes
/
