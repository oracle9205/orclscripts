column module format a20 
column action format a20

compute sum of physical_reads on report 
compute sum of consistent_changes  on report 

select s.sid,s.module,substr(s.action,1,20) action,i.block_gets,i.consistent_gets cons_get,
	i.physical_reads phy_read,i.block_changes blk_chng,
	i.consistent_changes cons_chng  from v$sess_io i,
	v$session s
	where (s.username like '%OLTP' or s.username like 'INT_')
	and i.sid=s.sid
/
