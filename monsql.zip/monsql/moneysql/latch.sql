col gets format 999999999999999
col name format a26

select name, gets, misses, sleeps, (gets-misses)/gets "Hit Ratio" ,waits_holding_latch , spin_gets from v$latch where name like 'library%' 
/
