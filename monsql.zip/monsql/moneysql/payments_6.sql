set numwidth 20
alter session set nls_date_format='MM/DD/YYYY HH24:MI:SS' ;
column tbi new_value tailbaseid format 999999999999999999999;
select last_number-cache_size-2600000 tbi from all_sequences where sequence_name='WTRANSACTION_SEQ';

select
        trunc(time_created/15)*15        time_created,
        u2sql(trunc(time_created/15)*15)        oracle_time,
        nvl(count(decode(type,'U',1)),0)  PAYMENTS,
        round(nvl(count(decode(type,'U',1)),0)/15)  "PAYMENTS/SEC",
        nvl(count(decode(type,'R',1)),0)  CHARGES
        from 
(select base_id,id,type,status,amount,time_created
from wtransaction wt
where
  base_id=id and mod(base_id,5)=0
  and ((type  = 'U' and status in ('S','P')  and amount<0)  or (type  = 'R' and status = 'S'))
  and base_id > &tailbaseid
union all
select base_id,id,type,status,amount,time_created
from wtransaction wt
where
  base_id=id
  and mod(base_id,5)=1
  and ((type  = 'U' and status in ('S','P')  and amount<0) or (type  = 'R' and status = 'S'))
  and base_id > &tailbaseid
union all
select base_id,id,type,status,amount,time_created
from wtransaction wt
where
  base_id=id
  and mod(base_id,5)=2
  and ((type  = 'U' and status in ('S','P')  and amount<0) or (type  = 'R' and status = 'S'))
  and base_id > &tailbaseid
union all
select base_id,id,type,status,amount,time_created
from wtransaction wt
where
  base_id=id
  and mod(base_id,5)=3
  and ((type  = 'U' and status in ('S','P')  and amount<0) or (type  = 'R' and status = 'S'))
  and base_id > &tailbaseid
union all
select base_id,id,type,status,amount,time_created
from wtransaction wt
where
  base_id=id
  and mod(base_id,5)=4
  and ((type  = 'U' and status in ('S','P')  and amount<0) or (type  = 'R' and status = 'S'))
  and base_id > &tailbaseid
) a
group by trunc(time_created/15)*15
order by trunc(time_created/15)*15
/
