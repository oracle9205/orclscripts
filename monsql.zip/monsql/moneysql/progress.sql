select substr(username,1,3) , count(*) from dba_users
group by  substr(username,1,3)
/
