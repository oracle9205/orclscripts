REM Sai => 09/30/09 Written for PPDBA repository live objects.

set pagesize 110
set ver off
col tablespace_name for a25
undef dbname

set head off
select 'Non locally managed tablespaces are not reported below' from dual;
set head on

select /*+ ordered index(a, PYPL_TBS_USAGE_METRICS_idx1) */  
a.tablespace_name, 
round(a.tablespace_size*c.block_size/1024/1024/1024) size_gb,
round(a.used_space*c.block_size/1024/1024/1024) used_gb,
round(a.used_percent) pct_used
from PYPL_TABLESPACE_USAGE_METRICS a,
(select distinct tsname, block_size from pypl_datafile where dbid = 
 (select dbid from pypl_databases where dbname=upper('&&dbname'))
) c
where (dbid, pypl_date) =
(select * from (select /*+ ordered index_desc(b. PYPL_TBS_USAGE_METRICS) */ dbid, pypl_date from
 PYPL_TABLESPACE_USAGE_METRICS b where dbid = (select dbid from pypl_databases where dbname=upper('&&dbname')))
 where rownum=1)
and a.tablespace_name = c.tsname
order by a.tablespace_size
/

select /*+ ordered index(a, PYPL_TBS_USAGE_METRICS_idx1) */ 
round(sum((tablespace_size*c.block_size)/1024/1024/1024),1) total_gb,
round(sum(((tablespace_size-used_space)*c.block_size)/1024/1024/1024), 1) free_gb
 from PYPL_TABLESPACE_USAGE_METRICS a,
(select distinct tsname, block_size from pypl_datafile where dbid = 
 (select dbid from pypl_databases where dbname=upper('&&dbname'))
) c
where (dbid, pypl_date) =
 (select * from (select /*+ ordered index_desc(b. PYPL_TBS_USAGE_METRICS) */ dbid, pypl_date from
  PYPL_TABLESPACE_USAGE_METRICS b where dbid = (select dbid from pypl_databases where dbname=upper('&&dbname')))
  where rownum=1) 
and a.tablespace_name = c.tsname
order by tablespace_name
/

select round(free_space/1024/1024) DISK_OS_FREE_GB from pypl_volume_info where (dbid, pypl_date) in
(select * from (select /*+ index_desc(a. pypl_volume_info_idx) */ dbid, pypl_date from pypl_volume_info
                where dbid = (select dbid from pypl_databases where dbname=upper('&&dbname')))
 where rownum = 1)
/

undef dbname
