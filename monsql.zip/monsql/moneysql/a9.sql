set trimspool on
col sample_time for a25
col blks for 99999
col avgtime for a13

select * from
(select sample_id, sample_time, count(*) cnt, round(max(TIME_WAITED)/1000,2) maxtime,
       round(avg(TIME_WAITED)/1000,2)||' ms' avgtime , avg(p2) blks
from v$active_session_history
where
event# in (106, 115)
group by sample_id, sample_time, event#
order by maxtime desc, sample_id)
where
maxtime > 50 and rownum <= 500
order by 2, 3
/
