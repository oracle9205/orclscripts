set echo on
create or replace package udate is
	function u2sql(n in number) return date;
	PRAGMA RESTRICT_REFERENCES(u2sql,WNDS,WNPS);
	function sql2u(d in date) return number;
	PRAGMA RESTRICT_REFERENCES(sql2u,WNDS,WNPS);
end;
/

create or replace package body udate is
------------------------------------------------------------------------
function u2sql(n in number) return date 
IS
BEGIN
        return to_date('12/31/69:17:00','MM/DD/YY:HH24:MI')+(n/(24*60*60));
END;
------------------------------------------------------------------------
function sql2u(d in date) return number 
IS
BEGIN
	return (d-to_date('12/31/1969 17','MM/DD/YYYY HH24')) * (24*60*60);
END;
------------------------------------------------------------------------
end udate;
/

show errors

@set echo off
