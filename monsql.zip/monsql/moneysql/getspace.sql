select sum(bytes) bytes from dba_data_files 
/


column used_space format 99,999,999,999
column free_space format 99,999,999,999
column total_space format 99,999,999,999
column largest_extent format 99,999,999,999
column tablespace_name format a15
column pctfull format 999
select t.tablespace_name,t.total_space,
	nvl(f.free_space,0) free_space, 
	nvl(f.largest_extent,0) largest_extent,
	total_space-nvl(f.free_space,0) used_space,
	(total_space-nvl(f.free_space,0))*100/total_space pctfull
  from
   (select tablespace_name, sum(bytes)/(1024*1024) total_space  
	from dba_data_files group by tablespace_name ) t,
   (select tablespace_name, sum(bytes)/(1024*1024) free_space,
	max(bytes)/(1024*1024) largest_extent
	from dba_free_space group by tablespace_name)  f
	where t.tablespace_name=f.tablespace_name (+)
/


column "Total MB" format 999,999 
column "Free MB" format  999,999 
column "name" format a10
column "# frags" format 9999
column "<1" format 9999
column ">1" format 9999
column ">10" format 9999
column ">50" format 9999
column ">100" format 9999
column ">1G" format 9999
select tablespace_name "name",
	SUM(decode(a,'size',tot,0))/(1024*1024) "Total MB",
	SUM(decode(a,'free',tot,0))/(1024*1024) "Free MB",
	SUM(decode(a,'total',tot,0)) "# frags",
	SUM(decode(a,'tiny',tot,0)) "<1",
	SUM(decode(a,'one',tot,0)) ">1",
	SUM(decode(a,'ten',tot,0)) ">10",
	SUM(decode(a,'fifty',tot,0)) ">50",
	SUM(decode(a,'hundred',tot,0)) ">100",
	SUM(decode(a,'500M',tot,0)) ">500",
	SUM(decode(a,'gig',tot,0)) ">1G"
from
(select tablespace_name , count(*) tot,'total'    a from dba_free_space group by tablespace_name
	union all
select tablespace_name , sum(bytes) tot,'size'    a from dba_data_files group by tablespace_name
	union all
select tablespace_name , sum(bytes) tot,'free'    a from dba_free_space group by tablespace_name
	union all
select tablespace_name , count(*) tot,'tiny'    a from dba_free_space where bytes <= 1024*1024     	group by tablespace_name
	union all
select tablespace_name , count(*) tot,'one'    a from dba_free_space where bytes > 1024*1024     	group by tablespace_name
	union all
select tablespace_name , count(*) tot,'ten'     a from dba_free_space where bytes > 10*1024*1024 	group by tablespace_name
	union all
select tablespace_name , count(*) tot,'fifty'   a from dba_free_space where bytes > 50*1024*1024  	group by tablespace_name
	union all
select tablespace_name , count(*) tot,'500M' a from dba_free_space where bytes > 500*1024*1024 	group by tablespace_name
	union all
select tablespace_name , count(*) tot,'hundred' a from dba_free_space where bytes > 100*1024*1024 	group by tablespace_name
	union all
select tablespace_name , count(*) tot,'gig'     a from dba_free_space where bytes > 1024*1024*1024 	group by tablespace_name
)
group by tablespace_name
/
