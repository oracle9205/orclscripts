set trimspool on
set linesize 199
set pagesize 100
define _editor=vi

col tablespace_name format a15
col object_name format a30
col table_name  format a30
col index_name  format a30
col segment_name format a30
col object_name format a30
col module format a14

col username    format a10
col owner	format a10
col r_owner	format a10

col constraint_name format a30
col r_constraint_name format a30

col name format a70
col event format a30
col info format a30
set time on

col machine format a15
col account_number format 99999999999999999999999999
col sid for 9999
