set verify off

column parties format a80
column amount format 999,999.00
column account_number format 99999999999999999999
column counterparty format 99999999999999999999


accept alias  prompt 'account alias: '

select
	wua1.alias|| decode(sign(amount),1,'<- ','->')|| nvl(wua2.alias,'#### Type '||xact.type) parties,
        amount / 100 amount,to_char(udate.u2sql(xact.time_created),'MM/DD/YY HH24:MI'),xact.type, xact.id
from  
	wtransaction xact,
        wuser_alias wua1,
        wuser_alias wua2
where
xact.account_number=(select account_number from wuser_alias where alias_upper=upper('&alias') and bitand(flags,1)=1)
and wua1.account_number = xact.account_number      and bitand(wua1.flags,1)=1 
and wua2.account_number (+) = xact.counterparty     and bitand(nvl(wua2.flags,1),1)=1
order by xact.time_created desc
/
