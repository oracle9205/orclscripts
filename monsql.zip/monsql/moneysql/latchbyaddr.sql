select latch#,name,gets,misses,sleeps,sleep1,sleep2,sleep3,sleep4
from v$latch_children
 where addr=hextoraw('&addr')
/
