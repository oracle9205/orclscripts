REM Ash report about active session count per every wait event for a given time range.
REM All time metrics are in seconds except where mentioned explicitly
REM Sai => 06/14/11

set lines 199
set pages 40
set ver off
alter session set nls_date_format = 'MM/DD HH24:MI:SS';

col cnt for 9999999
col event for a20
col max_time_ms for 99999
col avg_time_ms for 99999
col p1 for 99999999999999
col p1_cnt for 999
col p2_cnt for 999
col p3_cnt for 999
col obj_cnt for 999
col obj_id for 999999
col locks for 999

select
 stime, substr(event, 1, 20) event, sql_id, cnt, avg_time_ms, p1, p1_cnt, p2_cnt, p3_cnt,
 obj_cnt, obj_id, locks
from
(
select 
 to_date(to_char(sample_time, 'MM/DD')||' '||to_char(sample_time, 'HH24')||':'||
 to_char(sample_time, 'MI')||':'||
 to_char(sample_time, 'SS'), 'MM/DD HH24:MI:SS') as stime,
 event,
 max(sql_id) sql_id,
 count(*) cnt,
 max(p1) p1,
 count(distinct p1) p1_cnt,
 count(distinct p2) p2_cnt,
 count(distinct p3) p3_cnt,
 count(distinct CURRENT_OBJ#) obj_cnt,
 max(CURRENT_OBJ#) obj_id,
 count(BLOCKING_SESSION) as locks,
 round(avg(time_waited)/1000) as avg_time_ms
from &&ash_table
where
sample_time between
 to_date(to_char(&&sysdate_value, 'MM/DD')||' '||('&&HH24_MI_SS_1'), 'MM/DD HH24_MI_SS')
 and
 to_date(to_char(&&sysdate_value, 'MM/DD')||' '||('&&HH24_MI_SS_2'), 'MM/DD HH24_MI_SS')
group by
 to_date(to_char(sample_time, 'MM/DD')||' '||to_char(sample_time, 'HH24')||':'||
 to_char(sample_time, 'MI')||':'||
 to_char(sample_time, 'SS'), 'MM/DD HH24:MI:SS'),
 event
)
order by stime
/

