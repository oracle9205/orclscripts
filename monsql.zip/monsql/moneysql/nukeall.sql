select
 'alter system kill session '''||to_char(s.sid)||','||to_char(s.serial#)||''';'
  from v$session_wait w,
       v$sess_io     io,
       v$session         s,
       v$transaction  x
     where  s.sid = w.sid and io.sid=w.sid and x.addr=s.taddr
  and seconds_in_wait > 1000
 order by start_time
/
