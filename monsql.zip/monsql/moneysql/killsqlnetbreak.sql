set echo on;
set heading off;
spool k2.sql
select 'alter system kill session '||''''||s.sid||','||s.serial#||''''||';'||'---- coming from '|| machine||'------'
from v$session_wait w,
     v$sess_io     io,
     v$session      s
        where  s.sid = w.sid and io.sid=w.sid and
        s.status='ACTIVE'
        and  w.event in ('SQL*Net break/reset to dblink')
/
spool off;
