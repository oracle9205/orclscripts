var email_upper varchar2(128);
var mas_res varchar2(32);

exec :email_upper := 'S.BARRETT@%';
exec :mas_res := '100';

select account_number
from
(
SELECT a.account_number
FROM wuser a, wuser_alias b
WHERE a.account_number = b.account_number
and b.alias_upper LiKE :email_upper
)
where rownum <= :mas_res
/
