select sess.program, stats.* 
from v$session sess,
(select sid,
	max(decode(statistic#,155,value,null)) "SQLnet to",
	max(decode(statistic#,156,value,null)) "SQLnet from",
	max(decode(statistic#,157,value,null)) "SQLnet trips",
	max(decode(statistic#,158,value,null)) "DBlink to",
	max(decode(statistic#,159,value,null)) "DBlink from",
	max(decode(statistic#,160,value,null)) "DBlink trips"
	from v$sesstat 
	where  sid in (select sid from v$session where program like 'NetFlix Order Import%')
	and statistic# in (155,156,157,158,159,160)
	group by sid) stats
where sess.sid=stats.sid
/
