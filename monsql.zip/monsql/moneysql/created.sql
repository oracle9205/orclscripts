select s.owner, o.created, s.segment_name,s.segment_type, s.bytes 
from dba_segments s, dba_objects o  
where segment_name like upper('&segname') and tablespace_name='SCRUB' 
and o.object_name=s.segment_name order by segment_name
/
