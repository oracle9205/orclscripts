-- shows io rate, and percent full for each FS.  Used to level files based on the 
-- tradeoff off io rate, and capacity.
--
SELECT target_fs, round(percent_io,2) percent_io, round((used/total)*100,2) pct_full from (
SELECT a.target_fs, sum(percent_io) percent_io, max(b.kbytes) TOTAL, sum(a.kbytes) USED
FROM io_9980_df a, io_9980_fs b
WHERE a.target_fs IS NOT NULL
AND a.target_fs = b.target_fs
GROUP BY a.target_fs)
/
