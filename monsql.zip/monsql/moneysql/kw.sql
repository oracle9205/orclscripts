column username format a12 trunc
column machine format a14 trunc
column sid format  9999
column seq# format 099999
column wait format a18 trunc
column seconds format 9,999
column event format a29 wrap
column info format a40 wrap
select to_char(sysdate,'DD-MON HH24:MI:SS') QueryTimeStamp from dual
/
!rup et
select count(*) TotalSessions from  v$session
/
select count(*) WaitingforClient
from v$session_wait w, v$session s
	where s.username is not null
	and s.sid = w.sid
	and w.event ='SQL*Net message from client'
/
select s.username,machine,s.sid,seq#,w.event,
	decode(w.state,'WAITING','WAIT'
		    ,'WAITED KNOWN TIME',to_char(w.wait_time/100)
		    ,'WAITED SHORT TIME','SHORT'
		    ,'WAITED UNKNOWN TIME','?'
		    ,w.state) wait,
		    seconds_in_wait seconds,
	decode(w.p1text,'file#' ,waitinfo.segbyblock(w.p1,w.p2),
			'latch#',waitinfo.latchbynum(w.p1),
			         w.p1text||' '||to_char(w.p1)) info
from v$session_wait w,
     v$session	    s
	where s.username is not null
	and s.sid = w.sid
	and w.event!='SQL*Net message from client'
	order by username, s.sid
/
