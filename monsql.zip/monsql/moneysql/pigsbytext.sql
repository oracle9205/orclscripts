 select address,executions,(buffer_gets-disk_reads)/(buffer_gets+1) hit_ratio, buffer_gets/decode(executions,0,1,executions) avg_read ,
    substr(sql_text ,1,50)
    from sqlarea_prev
 where upper(sql_text) like '%EMAIL_UPPER%'
order by buffer_gets/decode(executions,0,1,executions) asc
	max(decode(column_position,3,', '||column_name,null))||
	max(decode(column_position,4,', '||column_name,null))||
	max(decode(column_position,5,', '||column_name,null)) columns from dba_ind_columns
	where  table_name = upper('&table_name')
group by index_name,index_owner) a,
dba_indexes b
where a.index_name = b.index_name and
a.index_owner=b.owner
/
