accept suffix propmt 'Suffix: '

create table parms_&&suffix storage (initial 1M next 1M ) as
	select * from v$parameter
/

drop synonym parms_prev ;
create synonym parms_prev for parms_&&suffix;

