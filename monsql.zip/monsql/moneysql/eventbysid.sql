select * from v$session_event where sid in (&sidlist)
order by sid, time_waited
/
