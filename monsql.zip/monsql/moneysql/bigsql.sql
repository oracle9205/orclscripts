column avg_gets format 999,999,999.99
column buffer_gets format 999,999,999,999
column disk_reads format 999,999,999,999
select address ,buffer_gets,disk_reads,executions, buffer_gets/decode(executions ,0,1,executions) avg_gets, substr(sql_text,1,80)
from v$sqlarea
where buffer_gets/decode(executions,0,1,executions)> 50000
or executions > 10000
order by buffer_gets desc
/
