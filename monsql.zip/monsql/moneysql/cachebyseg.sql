select count(*) from 
	bh,
	dba_extents ext
where bh.dbarfil=ext.file_id and
	bh.dbablk between ext.block_id and ext.block_id+ext.blocks-1 and
	ext.segment_name = upper('&segment_name');
/
