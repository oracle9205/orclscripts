select * from global_name;
