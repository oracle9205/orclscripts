select ' grant ' || privilege || ' on ' || table_name || ' to select_dw ; ' from  role_tab_privs where role='SELECT_DW' and table_name not like '%DIFF%' 
/
