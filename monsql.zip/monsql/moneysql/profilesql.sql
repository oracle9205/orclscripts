column persistent format 999,999,999 heading 'Persistent Mem'
column sharable   format 999,999,999 heading 'Sharable Mem'
column runtime    format 999,999,999 heading 'Runtime mem'
column text format a50
set verify off

accept x prompt 'table name: '
accept y prompt 'execution count: '

break on x
compute sum of persistent on x
compute sum of sharable on x
compute sum of runtime on x
compute sum of tot_parses on x

select ' ' x,min(first_load_time) first_loaded, count(*) count ,max(address) addr,sum(disk_reads) tot_reads,sum(parse_calls) tot_parses,sum(persistent_mem) persistent,
sum(sharable_mem) sharable,sum(runtime_mem) runtime, substr(sql_text,1,30) text from &x 
where executions < 5  group by substr(sql_text,1,30) having count(*) > &y 
order by count(*) desc
/

select ' ' x, 
decode(executions,0,'non-reuseable',1,'non-reuseable','reuseable') type,
sum(parse_calls) tot_parses,sum(persistent_mem) persistent,
sum(sharable_mem) sharable,sum(runtime_mem) runtime from &x 
group by decode(executions,0,'non-reuseable',1,'non-reuseable','reuseable')
order by count(*) desc
/


select sum(parse_calls) tot_parses,sum(persistent_mem) persistent,sum(sharable_mem) sharable,sum(runtime_mem) runtime from &x
/

select address ,first_load_time,buffer_gets,disk_reads,executions, buffer_gets/decode(executions ,0,1,executions) avg_gets, substr(sql_text,1,80)
from &x
where buffer_gets/decode(executions,0,1,executions)> 5000000
or (executions > &y and buffer_gets/decode(executions,0,1,executions)> 50000)
order by buffer_gets desc
/
