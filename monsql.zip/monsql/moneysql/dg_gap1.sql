REM Script to report status of daaguard redo transport from primary to the standby
REM Sai => 12/13/2011

select * from
 (select thread#, sequence#, blocks, first_time, completion_time, dest_id
  from v$archived_log where dest_id=1
  order by completion_time desc)
where
rownum <= 19
order by thread#, sequence#
/
