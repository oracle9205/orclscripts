column sent format 999,999,999,999,999
column recv format 999,999,999,999,999
column trips format 999,999,999,999,999
select 
	s.sid,
	max(ses.username),
	max(decode(s.statistic#,158,s.value,null)) sent,
	max(decode(s.statistic#,159,s.value,null)) recv,
	max(decode(s.statistic#,160,s.value,null)) trips
	from v$sesstat s, v$session ses
	where s.sid=ses.sid
	and ses.sid in (select sid from dba_jobs_running)
	group by s.sid
/
