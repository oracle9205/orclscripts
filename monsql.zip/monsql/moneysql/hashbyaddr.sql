col sql_text format a60
select address,hash_value, loads,executions,buffer_gets,disk_reads,sql_text from v$sqlarea
where  address=hextoraw('&address')
/
