set lines 199
col sql_id for a13
col sid for a18
col status for a10
col obj_info for a90
col wait_sec for 99999

select
sid, sql_id, seconds_in_wait wait_sec,
decode(sign(row_wait_obj#), 1,
                (select object_name from dba_objects where object_id=row_wait_obj# and data_object_id is not null)
               ,-1, 'Null', 'Null') ||':'|| cmd ||':'|| event#||':'||nvl(substr(event, 1, 15), 'No Event') ||':'||
               nvl(p1,0)||':'||nvl(p2, 0) ||':'|| nvl(p3, 0) ||':'|| info "OBJ_INFO"
from
(
 select
 sid, sql_id, status, seconds_in_wait,
 sid2, sid3,
 max(seconds_in_wait) over (partition by sid2) ctime,
 count(*) over (partition by sid2) cnt,
 row_wait_obj#,
 cmd, event, event#, p1, p2, p3, "INFO"
 from
 (
  select
  lpad(' ', level-1)||sid sid, decode(sql_id, null, prev_sql_id, sql_id) sql_id, status,
  seconds_in_wait,
  blocking_session,
  blocking_session_status,
  connect_by_root sid sid2,
  sys_connect_by_path(sid,':') sid3,
  row_wait_obj#,
  decode(command, 2, 'INSERT', 6, 'UPDATE', 7, 'DELETE', 182, 'UPDATE INDEXES', 3, 'SELECT FOR UPDATE', command) as cmd,
  event, event#,
  p1,
  p2,
  p3,
  status||':'||machine||':'||substr(module, 1, 10) "INFO"
  from v$session
  where taddr is not null or blocking_session  <> 0
  connect by prior sid=blocking_session
  start with blocking_session is null
 )
)
where cnt > 1
order by ctime desc, sid2,  length(sid3), seconds_in_wait desc
/
