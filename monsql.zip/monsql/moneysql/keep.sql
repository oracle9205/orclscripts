exec sys.dbms_shared_pool.keep('&package_name');
