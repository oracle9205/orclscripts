CREATE TABLE confdba.wpayment_flow_log                                                                                                                                              
(                                                                                                                                                                                   
    id                                 NUMBER(38,0)  NOT NULL,                                                                                                                      
    account_number                     NUMBER(38,0),                                                                                                                                
    counterparty                       NUMBER(38,0),                                                                                                                                
    payment_start_time                 NUMBER(38,0),                                                                                                                                
    payment_total_amount               NUMBER(38,0),                                                                                                                                
    payment_funding_amount             NUMBER(38,0),                                                                                                                                
    flags                              NUMBER(38,0),                                                                                                                                
    transaction_id                     NUMBER(38,0),                                                                                                                                
    cc_risk_score                      NUMBER(38,0),                                                                                                                                
    ach_risk_score                     NUMBER(38,0),                                                                                                                                
    echeck_risk_score                  NUMBER(38,0),                                                                                                                                
    test_risk_score                    NUMBER(38,0),                                                                                                                                
    sender_subprime                    NUMBER(38,0),                                                                                                                                
    counterparty_subprime              NUMBER(38,0),                                                                                                                                
    sender_auth                        NUMBER(38,0),                                                                                                                                
    counterparty_auth                  NUMBER(38,0),                                                                                                                                
    sender_fraud_score                 NUMBER(38,0),                                                                                                                                
    counterparty_fraud_score           NUMBER(38,0),                                                                                                                                
    outstanding_iach_count             NUMBER(38,0),                                                                                                                                
    outstanding_iach_amount            NUMBER(38,0),                                                                                                                                
    max_successful_amt                 NUMBER(38,0),                                                                                                                                
    cleared_count                      NUMBER(38,0),                                                                                                                                
    failed_count                       NUMBER(38,0),                                                                                                                                
    failed_count_secondary             NUMBER(38,0),                                                                                                                                
    cleared_sum                        NUMBER(38,0),                                                                                                                                
    failed_sum                         NUMBER(38,0),                                                                                                                                
    failed_sum_secondary               NUMBER(38,0),                                                                                                                                
    distinct_payments_sent             NUMBER(38,0),                                                                                                                                
    distinct_payments_recvd            NUMBER(38,0),                                                                                                                                
    sndr_num_cctr_denied               NUMBER(38,0),                                                                                                                                
    sndr_num_cctr_complete             NUMBER(38,0),                                                                                                                                
    sndr_amt_cctr_denied               NUMBER(38,0),                                                                                                                                
    sndr_amt_cctr_complete             NUMBER(38,0),                                                                                                                                
    sndr_num_intrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    sndr_num_extrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    sndr_amt_intrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    sndr_amt_extrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    recv_num_intrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    recv_num_extrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    recv_amt_intrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    recv_amt_extrnl_cb_agnst           NUMBER(38,0),                                                                                                                                
    sndr_num_payments_received         NUMBER(38,0),                                                                                                                                
    sndr_amt_payments_received         NUMBER(38,0),                                                                                                                                
    sndr_num_payments_sent             NUMBER(38,0),                                                                                                                                
    sndr_amt_payments_sent             NUMBER(38,0)                                                                                                                                 
)                                                                                                                                                                                   
PARALLEL ( DEGREE          1 INSTANCES          1 )                                                                                                                                 
TABLESPACE WMISC                                                                                                                                                                    
PCTFREE 10                                                                                                                                                                          
PCTUSED 40                                                                                                                                                                          
INITRANS 1                                                                                                                                                                          
MAXTRANS 255                                                                                                                                                                        
STORAGE                                                                                                                                                                             
(                                                                                                                                                                                   
   INITIAL 10485760                                                                                                                                                                 
   NEXT 10485760                                                                                                                                                                    
   MINEXTENTS 1                                                                                                                                                                     
   MAXEXTENTS 505                                                                                                                                                                   
   PCTINCREASE 0                                                                                                                                                                    
   FREELISTS 1                                                                                                                                                                      
   FREELIST GROUPS 1                                                                                                                                                                
)                                                                                                                                                                                   
/                                                                                                                                                                                   
ALTER TABLE CONFDBA.WPAYMENT_FLOW_LOG                                                                                                                                               
ADD CONSTRAINT WPAYMENT_PRIME PRIMARY KEY (ID)                                                                                                                                      
/                                                                                                                                                                                   
