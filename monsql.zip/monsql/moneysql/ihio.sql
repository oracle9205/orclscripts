
select s.sid,s.module,i.block_gets,i.consistent_gets,
	i.physical_reads,i.block_changes,i.consistent_changes from v$sess_io i,
	v$session s where 
	i.sid=s.sid 
	and s.machine like 'spwwofih%' 
/
