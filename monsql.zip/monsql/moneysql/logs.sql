column member format a60

select * from v$logfile;

select * from v$log order by first_time
/
