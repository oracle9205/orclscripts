col table_name format a30
col data_type format a14
select table_name, 
column_name, 
data_type, 
column_id, 
num_distinct, 
density, 
last_analyzed 
from dba_tab_columns where table_name=upper('&table_name') 
order by column_id
/
