select i.index_name,s.bytes,s.extents,i.blevel,i.leaf_blocks,i.distinct_keys,
	i.avg_leaf_blocks_per_key avg_lf_blk,i.avg_data_blocks_per_key avg_data_blk,i.clustering_factor
from user_indexes i,user_segments s
where i.index_name=s.segment_name
/
