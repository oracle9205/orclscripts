CREATE OR REPLACE VIEW confdba.verifyach                                                                                                                                            
(ALIAS                                                                                                                                                                              
,BANK_ACCOUNT_NUMBER                                                                                                                                                                
,DEPOSIT_ONE                                                                                                                                                                        
,DEPOSIT_TWO                                                                                                                                                                        
)                                                                                                                                                                                   
AS                                                                                                                                                                                  
SELECT wuser_alias.alias, wuser_ach.bank_account_number, wuser_ach.deposit_one,                                                                                                     
wuser_ach.deposit_two                                                                                                                                                               
  FROM wuser_alias, wuser_ach                                                                                                                                                       
  WHERE wuser_ach.account_number = wuser_alias.account_number                                                                                                                       
  AND BITAND(wuser_alias.flags, 13) = 1                                                                                                                                             
                                                                                                                                                                                    
/                                                                                                                                                                                   
