column interval format a30
column what format a80
SELECT
        jr.job       ,jr.sid
       ,username     username
       ,to_char(jr.this_date,'DD-MON-YY HH24:MI:SS') "start_date"
       ,substr(what         ,1,80) what
  FROM 
        dba_jobs_running   jr
       ,dba_jobs           j
       ,v$session          s
 WHERE
        s.sid  = jr.sid
   AND  jr.job = j.job
ORDER BY jr.this_date;


