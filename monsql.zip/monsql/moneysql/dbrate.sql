col name format a55
select n.name,s.value
	from v$sesstat s, v$statname n
	where s.value > 0
	and s.sid=&sid
	and n.statistic#=s.statistic#
	and n.name like '%link%'
/
