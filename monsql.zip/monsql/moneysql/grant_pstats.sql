18:54:35 SQL> /

'GRANTSELECTON'||TABLE_NAME||'TOBCHORNG;'                                                                                                                                           
----------------------------------------------------------                                                                                                                          
grant select on PLAN_TABLE to bchorng;                                                                                                                                              
grant select on PSTAT_SIZE to bchorng;                                                                                                                                              
grant select on SNAP_DBA_DATA_FILES to bchorng;                                                                                                                                     
grant select on SNAP_DBA_INDEXES to bchorng;                                                                                                                                        
grant select on SNAP_DBA_SEGMENTS to bchorng;                                                                                                                                       
grant select on STATS$BG_EVENT_SUMMARY to bchorng;                                                                                                                                  
grant select on STATS$BUFFER_POOL_STATISTICS to bchorng;                                                                                                                            
grant select on STATS$DATABASE_INSTANCE to bchorng;                                                                                                                                 
grant select on STATS$ENQUEUESTAT to bchorng;                                                                                                                                       
grant select on STATS$FILESTATXS to bchorng;                                                                                                                                        
grant select on STATS$IDLE_EVENT to bchorng;                                                                                                                                        
grant select on STATS$LATCH to bchorng;                                                                                                                                             
grant select on STATS$LATCH_CHILDREN to bchorng;                                                                                                                                    
grant select on STATS$LATCH_MISSES_SUMMARY to bchorng;                                                                                                                              
grant select on STATS$LATCH_PARENT to bchorng;                                                                                                                                      
grant select on STATS$LEVEL_DESCRIPTION to bchorng;                                                                                                                                 
grant select on STATS$LIBRARYCACHE to bchorng;                                                                                                                                      
grant select on STATS$PARAMETER to bchorng;                                                                                                                                         
grant select on STATS$ROLLSTAT to bchorng;                                                                                                                                          
grant select on STATS$ROWCACHE_SUMMARY to bchorng;                                                                                                                                  
grant select on STATS$SESSION_EVENT to bchorng;                                                                                                                                     
grant select on STATS$SESSTAT to bchorng;                                                                                                                                           
grant select on STATS$SGA to bchorng;                                                                                                                                               
grant select on STATS$SGASTAT to bchorng;                                                                                                                                           
grant select on STATS$SNAPSHOT to bchorng;                                                                                                                                          
grant select on STATS$SQLTEXT to bchorng;                                                                                                                                           
grant select on STATS$SQL_STATISTICS to bchorng;                                                                                                                                    
grant select on STATS$SQL_SUMMARY to bchorng;                                                                                                                                       
grant select on STATS$STATSPACK_PARAMETER to bchorng;                                                                                                                               
grant select on STATS$SYSSTAT to bchorng;                                                                                                                                           
grant select on STATS$SYSTEM_EVENT to bchorng;                                                                                                                                      
grant select on STATS$TEMPSTATXS to bchorng;                                                                                                                                        
grant select on STATS$WAITSTAT to bchorng;                                                                                                                                          

33 rows selected.

18:54:36 SQL> spool off;
