 select event,sum(time_waited) time, count(*) nsids
     from v$session_event where sid in (&sidlist)
    group by event
   order by sum(time_waited) asc
/
