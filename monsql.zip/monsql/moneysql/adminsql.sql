break on sql.sid
select ses.sid,sql.sql_text
from v$sqltext_with_newlines sql,v$session ses
        where sql.address =  ses.sql_address
        and ses.action='ADMIN'
        and ses.status='ACTIVE'
        order by sid, sql.piece
/
clear breaks
