set pagesize 150 
set linesize 200 
set verify off
set feedback off 
set pause off;
--define obj_owner = '&1'
--define inst_1 = '&2'
--define inst_2 = '&3'
accept obj_owner prompt 'Object Owner: '
accept inst_1 prompt 'First instance DB Link (Include @):'
-- accept inst_2 prompt 'Second instance DB Link (Include @):'

clear breaks
ttitle off 
set heading off

column datetime noprint new_value datetime
column inst_code1 noprint new_value inst_code1
column inst_code2 noprint new_value inst_code2

select to_char(sysdate,'MM/DD/YY') datetime
  from dual
/
select value inst_code1
  from v$parameter&inst_1
where name = 'db_name'
/
select value inst_code2
  from v$parameter
where name = 'db_name'
/
set feedback on
set heading on
set newpage 0


ttitle  left 'OBJDIFF'-
	col 25 'OBJECT DIFFERENCE REPORT' -
        col 53 'Report Date: ' datetime -
 skip 1 col 60 'Page: ' sql.pno -
 skip 1 col 10 'OWNER:  ' obj_owner   -
 skip 1 center 'Objects in &inst_code1 but not &inst_code2' -
 skip 2 

set null=0

column object_type format a8 heading 'Type';
column object_name format a38 heading 'Index Name';
column status format a6 heading 'Status';
column inst_code format a10 heading 'Instance';
column table_name format a28 heading 'Table Name';
column column_name format a28 heading 'Indexed Column';
-- column column_position format number(5) heading 'POS';


select a.object_name, a.object_type, a.status, b.table_name, b.column_name,b.column_position POS
from all_objects&inst_1 a, user_ind_columns b
where a.owner = UPPER('&obj_owner')
and a.object_type = 'INDEX'
and a.object_name = b.index_name
MINUS
select a.object_name, a.object_type, a.status, b.table_name, b.column_name,b.column_position POS
from all_objects a, user_ind_columns b
where a.owner = UPPER('&obj_owner')
and a.object_type = 'INDEX'
and a.object_name = b.index_name
order by 2,3
/
set heading off;
set feedback off;
select '' from dual
/
set heading on;
set feedback on;
ttitle  left 'OBJDIFF'-
	col 25 'OBJECT DIFFERENCE REPORT' -
        col 53 'Report Date: ' datetime -
 skip 1 col 60 'Page: ' sql.pno -
 skip 1 col 10 'OWNER:  ' obj_owner   -
 skip 1 center 'Objects in &inst_code2 but not &inst_code1' -
 skip 2 

select a.object_name, a.object_type, a.status, b.table_name,b.column_name,b.column_position POS
from all_objects a,user_ind_columns b
where a.owner = UPPER('&obj_owner')
and a.object_type = 'INDEX'
and a.object_name = b.index_name
MINUS
select a.object_name, a.object_type, a.status, b.table_name,b.column_name,b.column_position POS
from all_objects&inst_1 a, user_ind_columns&inst_1 b
where a.owner = UPPER('&obj_owner')
and a.object_type = 'INDEX'
and a.object_name = b.index_name
order by 2,3
/
