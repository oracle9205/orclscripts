select username,osuser,s.sid,s.sql_address sqladdr,w.event,module,io.block_gets+io.consistent_gets gets,
		    seconds_in_wait sec
from v$session_wait w,
     v$sess_io     io,
     v$session	    s
	where  s.sid = w.sid and io.sid=w.sid and
	s.status='ACTIVE'
	and  w.event not in ('rdbms ipc message', 'pmon timer', 'smon timer','PL/SQL lock timer')
        and username='FACT'
	order by event
/
