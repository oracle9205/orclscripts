select seg.tablespace_name,seg.segment_name,seg.next_extent,free.largest_avail
	from dba_segments seg,
	(select tablespace_name,max(bytes) largest_avail
		from dba_free_space group by tablespace_name ) free
	where seg.tablespace_name=free.tablespace_name (+)
	and seg.next_extent > nvl(free.largest_avail,-1)
	order by tablespace_name,segment_name 
/
