host /usr/proc/bin/ptree &PID
