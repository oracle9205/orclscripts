REM Script to report managed recover process status on physical standby
REM Sai => 12/13/2011

select inst_id, pid, status, thread#, sequence#, block#, blocks, delay_mins, active_agents from gv$managed_standby
where process='MRP0'
/
