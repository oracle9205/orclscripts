
set heading off pagesize 0
spool dropallobj.sql

SELECT 'DROP VIEW '||view_name||';'
	FROM user_views;

SELECT 'DROP INDEX '||index_name||';' FROM user_indexes;

SELECT 'DROP TABLE '||table_name||' CASCADE CONSTRAINTS;' FROM user_tables ;

spool off

rem spool /tmp/dropallobj.log
rem start dropallobj.sql
rem spool off
