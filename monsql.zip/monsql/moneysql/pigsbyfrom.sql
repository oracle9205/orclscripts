select address,executions,
	(buffer_gets-disk_reads)/(buffer_gets+1) hit_ratio,
	buffer_gets /decode(executions,0,1,executions) avg_gets,
	disk_reads  /decode(executions,0,1,executions) avg_disk_reads,
	substr(sql_text ,1,40)
	from sqlarea_prev
where upper(sql_text) like upper('%from%&string%where%')
order by executions asc
/
