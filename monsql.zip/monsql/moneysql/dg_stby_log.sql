REM Script to report lag of physical standby
REM Sai => 12/13/2011

col thread# for 99
col group# for 99

select thread#, group#, sequence#, bytes, status, first_time, last_time from v$standby_log
order by thread#, sequence#
/
