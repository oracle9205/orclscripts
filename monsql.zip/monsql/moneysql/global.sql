-- This script only gets global transactions that have actually done some DML (not select). 
-- See global2.sql for a script that also gets transactions that have just been started but have done no work.
column module format a15
column loose format a5
select /*+ ordered use_merge(trans,sess) */sid,serial#,module,
case when bitand(flag,power(2,30))>0 then 'Yes' else 'No' end loose,
sql_hash_value,sess.status,prev_hash_value from v$session sess, v$transaction trans
where taddr=trans.addr and
bitand(flag,power(2,22))>0
order by loose
/
