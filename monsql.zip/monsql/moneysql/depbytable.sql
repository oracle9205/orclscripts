col referenced_owner format a25
col referenced_link_name format a8
col referenced_name format a12
col owner format a16
col object_name format a30

select * from dba_dependencies where referenced_name=upper('&&table_name');

select o.object_name, o.object_type, o.owner, o.status from dba_objects o, dba_dependencies d where o.object_name=d.name and d.referenced_name=upper('&&table_name') order by o.owner ;
