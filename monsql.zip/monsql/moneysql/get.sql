 select c.hash_value, d.hash_value phash_value, c.delta, d.delta pdelta, c.delta-d.delta thedelta from 
  (select a.hash_value, a.snap_id, a.executions , b.hash_value phash_value, b.snap_id psnap_id, b.executions, a.executions-b.executions delta
   from 
     (select hash_value, snap_id, executions
      from stats$sql_summary where snap_id = 184363) a,
     (select hash_value, snap_id, executions
      from stats$sql_summary where snap_id = 184362) b
     where a.snap_id = b.snap_id+1
     and a.hash_value = b.hash_value
  ) c,
  (select a.hash_value, a.snap_id, a.executions , b.hash_value phash_value, b.snap_id psnap_id, b.executions, a.executions-b.executions delta
   from
     (select hash_value, snap_id, executions
      from stats$sql_summary where snap_id = 184363-675) a,
     (select hash_value, snap_id, executions
      from stats$sql_summary where snap_id = 184362-675) b
      where a.snap_id = b.snap_id+1                
      and a.hash_value = b.hash_value
   ) d
 where c.snap_id = d.snap_id+675
 and c.hash_value = d.hash_value
 order by 5 desc
/

